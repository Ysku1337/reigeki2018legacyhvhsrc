#pragma once

class c_hook_handler {
public:
	void initialize();

public:
	// forward declarations
	class i_recipient_filter;

	// prototypes.
	using paint_traverse_t = void(__thiscall*)(void*, VPANEL, bool, bool);
	using do_post_screen_space_effects_t = bool(__thiscall*)(void*, c_view_setup*);
	using createmove_t = bool(__thiscall*)(void*, float, c_user_cmd*);
	using level_init_post_entity_t = void(__thiscall*)(void*);
	using level_shutdown_t = void(__thiscall*)(void*);
	using level_init_pre_entity_t = void(__thiscall*)(void*, const char*);
	using in_key_event_t = int(__thiscall*)(void*, int, int, const char*);
	using frame_stage_notify_t = void(__thiscall*)(void*, stage_t);
	using update_clientside_animation_t = void(__thiscall*)(void*);
	using get_active_weapon_t = weapon_t * (__thiscall*)(void*);
	using do_extra_bone_processing_t = void(__thiscall*)(void*, int, int, int, int, int, int);
	using build_transformations_t = void(__thiscall*)(void*, int, int, int, int, int, int);
	using calc_viewmodel_view_t = void(__thiscall*)(void*, vec3_t&, ang_t&);
	using in_prediction_t = bool(__thiscall*)(void*);
	using override_view_t = void(__thiscall*)(void*, c_view_setup*);
	using lock_cursor_t = void(__thiscall*)(void*);
	using run_command_t = void(__thiscall*)(void*, entity_t*, c_user_cmd*, i_move_helper*);
	using process_packet_t = void(__thiscall*)(void*, void*, bool);
	using send_datagram_t = int(__thiscall*)(void*, void*);
	using play_sound_t = void(__thiscall*)(void*, const char*);
	using get_screen_size_t = void(__thiscall*)(void*, int&, int&);
	using push_3d_view_t = void(__thiscall*)(void*, c_view_setup&, int, void*, void*);
	using sceneend_t = void(__thiscall*)(void*);
	using draw_model_execute_t = void(__thiscall*)(void*, uintptr_t, const draw_model_state_t&, const model_render_info_t&, matrix3x4_t*);
	using compute_shadow_depth_textures_t = void(__thiscall*)(void*, const c_view_setup&, bool);
	using get_int_t = int(__thiscall*)(void*);
	using get_bool_t = bool(__thiscall*)(void*);
	using is_connected_t = bool(__thiscall*)(void*);
	using is_paused_t = bool(__thiscall*)(void*);
	using is_hltv_t = bool(__thiscall*)(void*);
	using on_entity_created_t = void(__thiscall*)(void*, entity_t*);
	using on_entity_deleted_t = void(__thiscall*)(void*, entity_t*);
	using render_smoke_overlay_t = void(__thiscall*)(void*, bool);
	using should_draw_fog_t = bool(__thiscall*)(void*);
	using should_draw_particles_t = bool(__thiscall*)(void*);
	using render_2d_effects_post_hud_t = void(__thiscall*)(void*, const c_view_setup&);
	using on_render_start_t = void(__thiscall*)(void*);
	using render_view_t = void(__thiscall*)(void*, const c_view_setup&, const c_view_setup&, int, int);
	using get_match_session_t = c_match_session_online_host * (__thiscall*)(void*);
	using on_screen_size_changed_t = void(__thiscall*)(void*, int, int);
	using override_config_t = bool(__thiscall*)(void*, material_system_config_t*, bool);
	using post_data_update_t = void(__thiscall*)(void*, data_update_type_t);
	using temp_entities_t = bool(__thiscall*)(void*, void*);
	using emit_sound_t = void(__thiscall*)(void*, i_recipient_filter&, int, int, const char*, unsigned int, const char*, float, float, int, int, int, const vec3_t*, const vec3_t*, void*, bool, float, int);
	using standard_blending_rules_t = void(__thiscall*)(void*, int, int, int, int, int);

public:
	bool                     hk_temp_entities(void* msg);
	void                     hk_paint_traverse(VPANEL panel, bool repaint, bool force);
	bool                     hk_do_post_screen_space_effects(c_view_setup* setup);
	bool                     hk_create_move(float input_sample_time, c_user_cmd* cmd);
	void                     hk_level_init_post_entity();
	void                     hk_level_shutdown();
	void                     hk_level_init_pre_entity(const char* map);
	void                     hk_frame_stage_notify(stage_t stage);
	void                     hk_update_clientside_animation();
	weapon_t*                hk_get_active_weapon();
	bool                     hk_in_prediction();
	bool                     hk_should_draw_particles();
	bool                     hk_should_draw_fog();
	void                     hk_override_view(c_view_setup* view);
	void                     hk_lock_cursor();
	void                     hk_play_sound(const char* name);
	void                     hk_on_screen_size_changed(int oldwidth, int oldheight);
	void                     hk_run_command(entity_t* ent, c_user_cmd* cmd, i_move_helper* movehelper);
	int                      hk_send_datagram(void* data);
	void                     hk_process_packet(void* packet, bool header);
	void                     hk_sceneend();
	void                     hk_draw_model_execute(uintptr_t ctx, const draw_model_state_t& state, const model_render_info_t& info, matrix3x4_t* bone);
	void                     hk_compute_shadow_depth_textures(const c_view_setup& view, bool unk);
	int                      hk_debug_spread_get_int();
	int                      hk_csm_shadow_get_int();
	int						 hk_sv_competitive_minspec_get_int();
	//int						 hk_sv_cheats_get_bool();
	bool                     hk_net_show_fragments_get_bool();
	void                     hk_do_extra_bone_processing(int a2, int a3, int a4, int a5, int a6, int a7);
	void                     hk_build_transformations(int a2, int a3, int a4, int a5, int a6, int a7);
	bool                     hk_is_connected();
	bool                     hk_is_paused();
	bool                     hk_is_hltv();
	void                     hk_emit_sound(i_recipient_filter& filter, int iEntIndex, int iChannel, const char* pSoundEntry, unsigned int nSoundEntryHash, const char* pSample, float flVolume, float flAttenuation, int nSeed, int iFlags, int iPitch, const vec3_t* pOrigin, const vec3_t* pDirection, void* pUtlVecOrigins, bool bUpdatePositions, float soundtime, int speakerentity);
	void                     hk_render_smoke_overlay(bool unk);
	void                     hk_on_render_start();
	void                     hk_render_view(const c_view_setup& view, const c_view_setup& hud_view, int clear_flags, int what_to_draw);
	void                     hk_render_2d_effects_post_hud(const c_view_setup& setup);
	c_match_session_online_host* hk_get_match_session();
	bool                     hk_override_config(material_system_config_t* config, bool update);
	void                     hk_post_data_update(data_update_type_t type);
	void                     hk_standard_blending_rules(int a2, int a3, int a4, int a5, int a6);

	static HRESULT WINAPI Present(IDirect3DDevice9* pDevice, RECT* pRect1, const RECT* pRect2, HWND hWnd, const RGNDATA* pRGNData);
	static HRESULT WINAPI Reset(IDirect3DDevice9* pDevice, D3DPRESENT_PARAMETERS* pPresentParameters);
	static LRESULT WINAPI WndProc(HWND wnd, uint32_t msg, WPARAM wp, LPARAM lp);

public:
	// vmts.
	c_vmt m_panel;
	c_vmt m_client_mode;
	c_vmt m_client;
	c_vmt m_client_state;
	c_vmt m_engine;
	c_vmt m_engine_sound;
	c_vmt m_prediction;
	c_vmt m_surface;
	c_vmt m_render;
	c_vmt m_net_channel;
	c_vmt m_render_view;
	c_vmt m_model_render;
	c_vmt m_shadow_mgr;
	c_vmt m_view_render;
	c_vmt m_match_framework;
	c_vmt m_material_system;
	c_vmt m_fire_bullets;
	c_vmt m_net_show_fragments;
	c_vmt m_device;

	// player shit.
	std::array< c_vmt, 64 > m_player;

	// cvars
	c_vmt m_debug_spread;
	c_vmt m_cl_csm_shadows;
	c_vmt m_sv_cheats;
	c_vmt m_sv_competitive_minspec;
	c_vmt m_mat_wireframe;
	c_vmt m_r_drawmodelstatsoverlay;

	// wndproc old ptr.
	WNDPROC m_old_wndproc;

	// old player create fn.
	do_extra_bone_processing_t     m_DoExtraBoneProcessing;
	update_clientside_animation_t  m_UpdateClientSideAnimation;
	get_active_weapon_t            m_GetActiveWeapon;
	build_transformations_t        m_BuildTransformations;
	standard_blending_rules_t      m_StandardBlendingRules;

	// netvar proxies.
	recv_var_proxy_t m_pitch_original;
	recv_var_proxy_t m_body_original;
	recv_var_proxy_t m_force_original;
	recv_var_proxy_t m_abs_yaw_original;
};

// note - dex; these are defined in player.cpp.
class custom_entity_listener : public i_entity_listener {
public:
	virtual void on_entity_created(entity_t* ent);
	virtual void on_entity_deleted(entity_t* ent);

	__forceinline void init() {
		cstrike.AddListenerEntity(this);
	}
};

extern c_hook_handler                  hook_handler;
extern custom_entity_listener          g_custom_entity_listener;