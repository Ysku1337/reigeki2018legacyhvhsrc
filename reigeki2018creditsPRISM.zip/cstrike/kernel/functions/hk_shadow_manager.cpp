#include "../../project.hpp"

void c_hook_handler::hk_compute_shadow_depth_textures( const c_view_setup &view, bool unk ) {
	if( !unk )
		return hook_handler.m_shadow_mgr.get_method< compute_shadow_depth_textures_t >( i_client_shadow_mgr::COMPUTESHADOWDEPTHTEXTURES )( this, view, unk );

	if(g_cfg[XOR("visuals_misc_no_draw_team")].get<bool>() ) {
		for( int i{ 1 }; i <= cstrike.m_globals->m_max_clients; ++i ) {
			c_base_player* player = cstrike.m_entlist->get_client_entity< c_base_player* >( i );

			if( !player )
				continue;

			if( player->is_local_player( ) )
				continue;

			if( !player->enemy( ctx.m_local ) ) {
				// disable all rendering at the root.
				player->m_bReadyToDraw( ) = false;

				// now stop rendering their weapon.
				weapon_t* weapon = player->get_active_weapon( );
				if( weapon )
					weapon->m_bReadyToDraw( ) = false;
			}
		}
	}

	hook_handler.m_shadow_mgr.get_method< compute_shadow_depth_textures_t >( i_client_shadow_mgr::COMPUTESHADOWDEPTHTEXTURES )( this, view, unk );
}