#include "../../project.hpp"

void c_hook_handler::hk_sceneend() {
	hook_handler.m_render_view.get_method< c_hook_handler::sceneend_t >(iv_render_view::SCENEEND)(this);

	chams.SceneEnd();
}