#include "../../project.hpp"

bool c_hook_handler::hk_should_draw_particles( ) {
	return hook_handler.m_client_mode.get_method< should_draw_particles_t >( i_client_mode::SHOULDDRAWPARTICLES )( this );
}

bool c_hook_handler::hk_should_draw_fog( ) {
	// remove fog.
	if (g_cfg[XOR("visuals_misc_remove_fog")].get<bool>())
		return false;

	return hook_handler.m_client_mode.get_method< should_draw_fog_t >( i_client_mode::SHOULDDRAWFOG )( this );
}

void c_hook_handler::hk_override_view( c_view_setup* view ) {
	// damn son.
	ctx.m_local = cstrike.m_entlist->get_client_entity< c_base_player* >(cstrike.m_engine->get_local_player());

	//g_grenades.think( );	
	visuals.thirdperson_think();

	//if( g_cl.m_processing ) {
	//	if( g_hvh.m_fake_duck ) {
	//		view->m_origin.z = g_cl.m_local->GetAbsOrigin( ).z + 64.f;
	//	}
	//}

	// call original.
	hook_handler.m_client_mode.get_method< override_view_t >(i_client_mode::OVERRIDEVIEW)(this, view);

	// remove scope edge blur.
	if (ctx.m_local) {
		view->m_edge_blur = 0;
		
	}

	if (ctx.m_local && ctx.m_local->m_bIsScoped()) {
		if (g_cfg[XOR("misc_override_fov_scoped")].get<bool>()) {
			if (ctx.m_weapon && ctx.m_weapon->m_zoomLevel() != 2) {
				view->m_fov = g_cfg[XOR("misc_override_fov_amount")].get< float >();
			}
			else {
				view->m_fov += 45.f;
			}
		}
	}
	else view->m_fov = g_cfg[XOR("misc_override_fov_amount")].get< float >();

	//if (g_hvh.m_fake_duck)
	//	view->m_origin.z = g_cl.m_local->GetAbsOrigin().z + 64.f;

	//g_visuals.Zoom(view);
}

bool c_hook_handler::hk_create_move( float time, c_user_cmd* cmd ) {
	Stack   stack;
	bool    ret;

	// let original run first.
	ret = hook_handler.m_client_mode.get_method< createmove_t >( i_client_mode::CREATEMOVE )( this, time, cmd );

	// called from CInput::ExtraMouseSample -> return original.
	if( !cmd->m_command_number )
		return ret;

	// if we arrived here, called from -> CInput::CreateMove
	// call EngineClient::SetViewAngles according to what the original returns.
	if( ret )
		cstrike.m_engine->set_view_angles( cmd->m_view_angles );

	// random_seed isn't generated in ClientMode::CreateMove yet, we must set generate it ourselves.
	cmd->m_random_seed = cstrike.MD5_PseudoRandom( cmd->m_command_number ) & 0x7fffffff;

	// get bSendPacket off the stack.
	ctx.m_packet = stack.next( ).local( 0x1c ).as< bool* >( );

	// get bFinalTick off the stack.
	ctx.m_final_packet = stack.next( ).local( 0x1b ).as< bool* >( );

	if (ctx.m_local && !ctx.m_local->alive())
		engine_predict.m_curtime = cstrike.m_globals->m_curtime;

	// invoke move function.
	ctx.on_tick( cmd );

	return false;
}


bool c_hook_handler::hk_do_post_screen_space_effects( c_view_setup* setup ) {

	visuals.render_glow( );

	return hook_handler.m_client_mode.get_method< do_post_screen_space_effects_t >( i_client_mode::DOPOSTSPACESCREENEFFECTS )( this, setup );
}