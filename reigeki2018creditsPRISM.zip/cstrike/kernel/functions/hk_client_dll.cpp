#include "../../project.hpp"

void c_hook_handler::hk_level_init_pre_entity( const char* map ) {
	float rate{ 1.f / cstrike.m_globals->m_interval };

	// set rates when joining a server.
	cstrike.cl_updaterate->set_value(rate);
	cstrike.cl_cmdrate->set_value(rate);

	aimbot.reset();
	visuals.m_hit_start = visuals.m_hit_end = visuals.m_hit_duration = 0.f;

	// invoke original method.
	hook_handler.m_client.get_method< level_init_pre_entity_t >(chl_client::LEVELINITPREENTITY)(this, map);
}

void c_hook_handler::hk_level_init_post_entity( ) {
	ctx.on_map_load( );

	// invoke original method.
	hook_handler.m_client.get_method< level_init_post_entity_t >( chl_client::LEVELINITPOSTENTITY )( this );
}

void c_hook_handler::hk_level_shutdown( ) {
//	g_aimbot.reset( );

	ctx.m_local       = nullptr;
	ctx.m_weapon      = nullptr;
	ctx.m_processing  = false;
	ctx.m_weapon_info = nullptr;
	ctx.m_round_end   = false;

	aimbot.reset();

	ctx.m_sequences.clear( );

	// invoke original method.
	hook_handler.m_client.get_method< level_shutdown_t >( chl_client::LEVELSHUTDOWN )( this );
}

/*int c_hook_handler::IN_KeyEvent( int evt, int key, const char* bind ) {
	// see if this key event was fired for the drop bind.
	/*if( bind && FNV1a::get( bind ) == HASH( "drop" ) ) {
		// down.
		if( evt ) {
			ctx.m_drop = true;
			ctx.m_drop_query = 2;
			ctx.print( "drop\n" );
		}

		// up.
		else 
			ctx.m_drop = false;

		// ignore the event.
		return 0;
	}

	return hook_handler.m_client.get_method< IN_KeyEvent_t >( CHLClient::INKEYEVENT )( this, evt, key, bind );
}*/

void c_hook_handler::hk_frame_stage_notify( stage_t stage ) {
	// save stage.
	if( stage != FRAME_START )
		ctx.m_stage = stage;

	// damn son.
	ctx.m_local = cstrike.m_entlist->get_client_entity< c_base_player* >( cstrike.m_engine->get_local_player( ) );

	if( stage == FRAME_RENDER_START ) {	
		// apply local player animated angles.
		ctx.set_angles( );

		// apply local player animation fix.
		animations.update_local_animations( );

        // draw our custom beams.
		visuals.draw_beams( );
	}

	// call og.
	hook_handler.m_client.get_method< frame_stage_notify_t >( chl_client::FRAMESTAGENOTIFY )( this, stage );

	if( stage == FRAME_RENDER_START ) {
	

	}

	else if( stage == FRAME_NET_UPDATE_POSTDATAUPDATE_START ) {
		// restore non-compressed netvars.
		//netdata.apply( );

		skins.think( );

		dormancy.position_correction(stage);

		ctx.clantag_changer();
	}

	else if( stage == FRAME_NET_UPDATE_POSTDATAUPDATE_END ) {

		visuals.remove_smoke( );
	}

	else if( stage == FRAME_NET_UPDATE_END ) {
        // restore non-compressed netvars.
		netdata.apply( );

		 //update all players.
		for( int i{ 1 }; i <= cstrike.m_globals->m_max_clients; ++i ) {
			c_base_player* player = cstrike.m_entlist->get_client_entity< c_base_player* >( i );
			if( !player || player->is_local_player( ) )
				continue;

			c_aim_player* data = &aimbot.m_players[ i - 1 ];
				data->on_net_update( player );
		}
	}
}