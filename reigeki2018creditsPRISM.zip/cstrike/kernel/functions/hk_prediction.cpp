#include "../../project.hpp"

bool c_hook_handler::hk_in_prediction( ) {
	Stack stack;
	ang_t *angles;

	// note - dex; first 2 'test al, al' instructions in C_BasePlayer::CalcPlayerView.
	static Address CalcPlayerView_ret1{ pattern::find( cstrike.m_client_dll, XOR( "84 C0 75 0B 8B 0D ? ? ? ? 8B 01 FF 50 4C" ) ) };
	static Address CalcPlayerView_ret2{ pattern::find( cstrike.m_client_dll, XOR( "84 C0 75 08 57 8B CE E8 ? ? ? ? 8B 06" ) ) };

	if( ctx.m_local && g_cfg[ XOR( "visuals_misc_remove_visual_recoil" ) ].get< bool >( ) ) {
		// note - dex; apparently this calls 'view->DriftPitch()'.
		//             i don't know if this function is crucial for normal gameplay, if it causes issues then comment it out.
		if( stack.ReturnAddress( ) == CalcPlayerView_ret1 )
			return true;

		if( stack.ReturnAddress( ) == CalcPlayerView_ret2 ) {
			// at this point, angles are copied into the CalcPlayerView's eyeAngles argument.
			// (ebp) InPrediction -> (ebp) CalcPlayerView + 0xC = eyeAngles.
			angles = stack.next( ).arg( 0xC ).to< ang_t* >( );

			if( angles ) {
				*angles -= ctx.m_local->m_viewPunchAngle( )
					+ (ctx.m_local->m_aimPunchAngle( ) * cstrike.weapon_recoil_scale->get_float( ) )
					* cstrike.view_recoil_tracking->get_float( );
			}

			return true;
		}
	}

	return hook_handler.m_prediction.get_method< in_prediction_t >( c_prediciton::INPREDICTION )( this );
}

void c_hook_handler::hk_run_command( entity_t* ent, c_user_cmd* cmd, i_move_helper* movehelper ) {
	// airstuck jitter / overpred fix.
	if( cmd->m_tick >= std::numeric_limits< int >::max( ) )
		return;

	hook_handler.m_prediction.get_method< run_command_t >( c_prediciton::RUNCOMMAND )( this, ent, cmd, movehelper );

	// store non compressed netvars.
//	netdata.store( );
}