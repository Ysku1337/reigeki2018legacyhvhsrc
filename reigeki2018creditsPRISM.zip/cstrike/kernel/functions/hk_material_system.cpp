#include "../../project.hpp"

bool c_hook_handler::hk_override_config( material_system_config_t* config, bool update ) {
	if (g_cfg[XOR("misc_world_fullbright")].get<bool>())
		config->m_nFullbright = true;

	static bool should_update = false;
	static bool did_nightmode_change = false;
	static int last_nightmode_value;
	static bool last_nightmode_toggle = false;

	if (!ctx.m_local) {
		should_update = true;
	}

	if (last_nightmode_value != g_cfg[XOR("misc_world_night_darkness")].get<int>() || last_nightmode_toggle != g_cfg[XOR("misc_world_night")].get<bool>()) {
		did_nightmode_change = true;
	}

	// philip015 added this to his cheat and it made it so much better.
	if (should_update || did_nightmode_change) {
		last_nightmode_value = g_cfg[XOR("misc_world_night_darkness")].get<int>();
		last_nightmode_toggle = g_cfg[XOR("misc_world_night")].get<bool>();

		visuals.modulate_world();
		//visuals.skybox_manipulation();

		should_update = false;
		did_nightmode_change = false;
	}

	return hook_handler.m_material_system.get_method< override_config_t >(i_material_system::OVERRIDECONFIG)(this, config, update);
}