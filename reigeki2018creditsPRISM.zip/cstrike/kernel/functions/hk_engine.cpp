#include "../../project.hpp"

bool c_hook_handler::hk_is_connected( ) {
	Stack stack;

	static Address IsLoadoutAllowed{ pattern::find( cstrike.m_client_dll, XOR( "84 C0 75 04 B0 01 5F" ) ) };

	if( stack.ReturnAddress( ) == IsLoadoutAllowed )
		return false;

	return hook_handler.m_engine.get_method< is_connected_t >( iv_engine_client::ISCONNECTED )( this );
}

bool c_hook_handler::hk_is_paused() {
	static DWORD* return_to_extrapolation = ( DWORD* )( pattern::find(cstrike.m_client_dll,
		XOR("FF D0 A1 ?? ?? ?? ?? B9 ?? ?? ?? ?? D9 1D ?? ?? ?? ?? FF 50 34 85 C0 74 22 8B 0D ?? ?? ?? ??") ) + 0x29 );

	if (_ReturnAddress( ) == ( void* )return_to_extrapolation )
		return true;

	return hook_handler.m_engine.get_method< is_paused_t >( iv_engine_client::ISPAUSED )( this );
}

bool c_hook_handler::hk_is_hltv( ) {
	Stack stack;

	static Address SetupVelocity{ pattern::find( cstrike.m_client_dll, XOR( "84 C0 75 38 8B 0D ? ? ? ? 8B 01 8B 80" ) ) };

	// AccumulateLayers
	if( bonesetup.m_running )
		return true;

	// fix for animstate velocity.
	if( stack.ReturnAddress( ) == SetupVelocity )
		return true;

	return hook_handler.m_engine.get_method< is_hltv_t >( iv_engine_client::ISHLTV )( this );
}

void c_hook_handler::hk_emit_sound( i_recipient_filter& filter, int iEntIndex, int iChannel, const char* pSoundEntry, unsigned int nSoundEntryHash, const char* pSample, float flVolume, float flAttenuation, int nSeed, int iFlags, int iPitch, const vec3_t* pOrigin, const vec3_t* pDirection, void* pUtlVecOrigins, bool bUpdatePositions, float soundtime, int speakerentity ) {
	if( strstr( pSample, "null" ) ) {
		iFlags = ( 1 << 2 ) | ( 1 << 5 );
	}

	hook_handler.m_engine_sound.get_method< emit_sound_t >( i_engine_sound::EMITSOUND )( this, filter, iEntIndex, iChannel, pSoundEntry, nSoundEntryHash, pSample, flVolume, flAttenuation, nSeed, iFlags, iPitch, pOrigin, pDirection, pUtlVecOrigins, bUpdatePositions, soundtime, speakerentity );
}