#include "../../project.hpp"

bool c_hook_handler::hk_temp_entities( void *msg ) {
	if( !ctx.m_processing ) {
		return hook_handler.m_client_state.get_method< temp_entities_t >( c_client_state::TEMPENTITIES )( this, msg );
	}

	const bool ret = hook_handler.m_client_state.get_method< temp_entities_t >( c_client_state::TEMPENTITIES )( this, msg );

	c_event_info  *ei = cstrike.m_cl->m_events; 
	c_event_info  *next = nullptr;

	if( !ei ) {
		return ret;
	}

	do {
		next = *reinterpret_cast< c_event_info ** >( reinterpret_cast< uintptr_t >( ei ) + 0x38 );

		uint16_t classID = ei->m_class_id - 1;

		auto m_pCreateEventFn = ei->m_client_class->m_pCreateEvent;
		if( !m_pCreateEventFn ) {
			continue;
		}

		void *pCE = m_pCreateEventFn( );
		if( !pCE ) {
			continue;
		}

		if( classID == 170 ){
			ei->m_fire_delay = 0.0f;
		}
		ei = next;
	} while( next != nullptr );

	return ret;
}