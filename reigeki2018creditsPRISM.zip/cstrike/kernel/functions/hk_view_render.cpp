#include "../../project.hpp"

void c_hook_handler::hk_on_render_start( ) {
	// call og.
	hook_handler.m_view_render.get_method< on_render_start_t >( c_view_render::ONRENDERSTART )( this );


}

void c_hook_handler::hk_render_view( const c_view_setup &view, const c_view_setup &hud_view, int clear_flags, int what_to_draw ) {
	// ...

	hook_handler.m_view_render.get_method< render_view_t >( c_view_render::RENDERVIEW )( this, view, hud_view, clear_flags, what_to_draw );
}

void c_hook_handler::hk_render_2d_effects_post_hud( const c_view_setup &setup ) {
	if (!g_cfg[XOR("visuals_misc_remove_flash")].get<bool>())
		hook_handler.m_view_render.get_method< render_2d_effects_post_hud_t >( c_view_render::RENDER2DEFFECTSPOSTHUD )( this, setup );
}

void c_hook_handler::hk_render_smoke_overlay( bool unk ) {
	// do not render smoke overlay.
	if (!g_cfg[XOR("visuals_misc_remove_smoke")].get<bool>())
		hook_handler.m_view_render.get_method< render_smoke_overlay_t >( c_view_render::RENDERSMOKEOVERLAY )( this, unk );
}
