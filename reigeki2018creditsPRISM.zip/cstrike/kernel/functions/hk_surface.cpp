#include "../../project.hpp"

/*void Hooks::GetScreenSize( int& w, int& h ) {
	//Stack stack;

	//static Address DrawCrosshairW{ pattern::find( cstrike.m_client_dll, XOR( "99 2B C2 D1 F8 89 44 24 18" ) ) };
	//static Address DrawCrosshairH{ pattern::find( cstrike.m_client_dll, XOR( "8B 0D ? ? ? ? 99 2B C2 D1 F8 89" ) ) };

	// run the original method first.
	hook_handler.m_surface.get_method< Hooks::GetScreenSize_t >( ISurface::GETSCREENSIZE )( this, w, h );

	//if( stack.next( ).return_address( ) == DrawCrosshairW )
	//	w = 50;

	//if( stack.next( ).return_address( ) == DrawCrosshairH )
	//	h = 50;
}*/

void c_hook_handler::hk_lock_cursor( ) {
	if( g_menu.m_opened ) {

		// un-lock the cursor.
		cstrike.m_surface->unlock_cursor( );

		// disable input.
		cstrike.m_input_system->enable_input( false );
	}

	else {
		// call the original.
		hook_handler.m_surface.get_method< lock_cursor_t >( i_surface::LOCKCURSOR )( this );

		// enable input.
		cstrike.m_input_system->enable_input( true );
	}
}

void c_hook_handler::hk_play_sound( const char* name ) {
	hook_handler.m_surface.get_method< play_sound_t >(i_surface::PLAYSOUND )( this, name );

	//if( g_menu.main.misc.autoaccept.get( ) ) {

	//	// auto accept.
	//	if( FNV1a::get( name ) == HASH( "!UI/competitive_accept_beep.wav" ) && !cstrike.m_engine->is_in_game( ) ) {
	//		// accept match.
	//		cstrike.IsReady( );

	//		// notify user.
	//		cstrike.m_surface->play_sound( XOR( "ui/xp_levelup.wav" ) );
	//	}
	//}
}

void c_hook_handler::hk_on_screen_size_changed( int oldwidth, int oldheight ) {
	hook_handler.m_surface.get_method< on_screen_size_changed_t >( i_surface::ONSCREENSIZECHANGED )( this, oldwidth, oldheight );

	render::init( );

	visuals.modulate_world();
}