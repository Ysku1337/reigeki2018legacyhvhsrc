#include "../../project.hpp"

int c_hook_handler::hk_debug_spread_get_int( ) {

	if (ctx.m_processing && !ctx.m_local->m_bIsScoped() && g_cfg[XOR("misc_force_crosshair")].get< bool >())
		return 3;

	return hook_handler.m_debug_spread.get_method< get_int_t >(c_convar::GETINT)(this);
}


int c_hook_handler::hk_csm_shadow_get_int() {

	// fuck the blue nigger shit on props with nightmode
	// :nauseated_face:
	return 0;
}

int c_hook_handler::hk_sv_competitive_minspec_get_int() {

	if (visuals.m_viewmodel_modified && cstrike.m_engine->is_in_game())
		return 0;

	return hook_handler.m_sv_competitive_minspec.get_method< get_int_t >(c_convar::GETINT)(this);
}

//int c_hook_handler::hk_sv_cheats_get_bool() {
//
//	if (reinterpret_cast<DWORD>(_ReturnAddress()) == cstrike.CamThink)
//		return 1;
//
//	return hook_handler.m_sv_cheats.get_method< get_int_t >(c_convar::GETINT)(this);
//}
//
//bool c_hook_handler::hk_mat_wireframe_get_int() {
//
//	if (reinterpret_cast<DWORD>(_ReturnAddress()) == cstrike.RenderingOrder1)
//		return true;
//
//	return hook_handler.m_mat_wireframe.get_method< get_int_t >(c_convar::GETINT)(this);
//}
//
//bool c_hook_handler::R_DrawmodelstatsoverlayGetInt() {
//
//	if (reinterpret_cast<DWORD>(_ReturnAddress()) == cstrike.RenderingOrder2)
//		return true;
//
//	return hook_handler.m_r_drawmodelstatsoverlay.get_method< get_int_t >(c_convar::GETINT)(this);
//}


bool c_hook_handler::hk_net_show_fragments_get_bool( ) {
	if( !cstrike.m_engine->is_in_game( ) )
		return hook_handler.m_net_show_fragments.get_method< get_bool_t >( c_convar::GETBOOL )( this );

	static auto read_sub_channel_data_ret = pattern::find( cstrike.m_engine_dll, "85 C0 74 12 53 FF 75 0C 68 ? ? ? ? FF 15 ? ? ? ? 83 C4 0C" ).as< uintptr_t *>( );
	static auto check_receiving_list_ret = pattern::find( cstrike.m_engine_dll, "8B 1D ? ? ? ? 85 C0 74 16 FF B6" ).as< uintptr_t *>();

	static uint32_t last_fragment = 0;

	if( _ReturnAddress( ) == reinterpret_cast< void * >( read_sub_channel_data_ret ) && last_fragment > 0 )
	{
		const auto data = &reinterpret_cast< uint32_t * >( cstrike.m_cl->m_net_channel )[ 0x56 ];
		const auto bytes_fragments = reinterpret_cast< uint32_t * >( data )[ 0x43 ];

		if( bytes_fragments == last_fragment )
		{
			auto &buffer = reinterpret_cast< uint32_t * >( data )[ 0x42 ];
			buffer = 0;	
		}
	}

	if( _ReturnAddress( ) == check_receiving_list_ret )
	{
		const auto data = &reinterpret_cast< uint32_t * >( cstrike.m_cl->m_net_channel )[ 0x56 ];
		const auto bytes_fragments = reinterpret_cast< uint32_t * >( data )[ 0x43 ];

		last_fragment = bytes_fragments;
	}

	return hook_handler.m_net_show_fragments.get_method< get_bool_t >( c_convar::GETBOOL )( this );
}