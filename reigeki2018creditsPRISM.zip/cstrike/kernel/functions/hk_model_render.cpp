#include "../../project.hpp"

void c_hook_handler::hk_draw_model_execute( uintptr_t ctx, const draw_model_state_t& state, const model_render_info_t& info, matrix3x4_t* bone ) {
	// disable rendering of shadows.
	if (strstr(info.m_model->m_name, XOR("shadow")) != nullptr && g_cfg[XOR("visuals_misc_remove_entity_shadows")].get<bool>())
		return;

	// disable rendering of sleeves.
	if (strstr(info.m_model->m_name, XOR("sleeve")) != nullptr && g_cfg[XOR("visuals_misc_remove_sleeves")].get<bool>())
		return;

	// disables csgo's hdr effect.
	static auto hdr = cstrike.m_material_system->find_material(XOR("dev/blurfiltery_nohdr"), XOR("Other textures"));
	hdr->set_flag(MATERIAL_VAR_NO_DRAW, true);

	// dont override glow.
	if (cstrike.m_studio_render->IsForcedMaterialOverriden())
		return hook_handler.m_model_render.get_method< c_hook_handler::draw_model_execute_t >(iv_model_render::DRAWMODELEXECUTE)(this, ctx, state, info, bone);

	// do chams.
	if (chams.DrawModel(ctx, state, info, bone)) {
		hook_handler.m_model_render.get_method< c_hook_handler::draw_model_execute_t >(iv_model_render::DRAWMODELEXECUTE)(this, ctx, state, info, bone);
		cstrike.m_studio_render->forced_material_override(nullptr);
	}
}