#include "../../project.hpp"

void c_hook_handler::hk_paint_traverse( VPANEL panel, bool repaint, bool force ) {
	static VPANEL tools{}, zoom{};

	// cache CHudZoom panel once.
	if( !zoom && FNV1a::get( cstrike.m_panel->get_name( panel ) ) == HASH( "HudZoom" ) )
		zoom = panel;

	// cache tools panel once.
	if( !tools && panel == cstrike.m_engine_vgui->get_panel( PANEL_TOOLS ) )
		tools = panel;

	// render hack stuff.
	if( panel == tools )
		ctx.on_paint( );

	// don't call the original function if we want to remove the scope.
	if( panel == zoom && g_cfg[XOR("visuals_misc_remove_scope")].get< bool >())
		return;
		
	hook_handler.m_panel.get_method< paint_traverse_t >( i_panel::PAINTTRAVERSE )( this, panel, repaint, force );
}