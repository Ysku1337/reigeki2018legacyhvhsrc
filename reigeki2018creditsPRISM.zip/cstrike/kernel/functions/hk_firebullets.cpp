#include "../../project.hpp"

class c_te_fire_bullets {
public:
	PAD( 0xC );
	int		m_index;
	int     m_item_id;
	vec3_t	m_origin;
	ang_t	m_angles;
	int		m_weapon_id;
	int		m_mode;
	int		m_seed;
	float	m_spread;
};

void c_hook_handler::hk_post_data_update( data_update_type_t type ) {
	//C_TEFireBullets* shot = ( C_TEFireBullets* )this;
	
	//Player* player = cstrike.m_entlist->GetClientEntity< Player* >( shot->m_index + 1 );

	hook_handler.m_fire_bullets.get_method< post_data_update_t >( 7 )( this, type );
}

void c_hook_handler::hk_standard_blending_rules(int a2, int a3, int a4, int a5, int a6)
{
	// cast thisptr to player ptr.
	c_base_player* player = (c_base_player*)this;

	if (!player || (player->index() - 1) > 63)
		return hook_handler.m_StandardBlendingRules(this, a2, a3, a4, a5, a6);

	// disable interpolation.
	if (!(player->m_fEffects() & EF_NOINTERP))
		player->m_fEffects() |= EF_NOINTERP;

	hook_handler.m_StandardBlendingRules(this, a2, a3, a4, a5, a6);

	// restore interpolation.
	player->m_fEffects() &= ~EF_NOINTERP;

}