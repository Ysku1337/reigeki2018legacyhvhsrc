#include "../../project.hpp"

HRESULT WINAPI c_hook_handler::Present(IDirect3DDevice9* pDevice, RECT* pRect1, const RECT* pRect2, HWND hWnd, const RGNDATA* pRGNData) {

	static bool initialised_renderer = false;
	if (!initialised_renderer) {

		g_menu.ApplyFonts();
		g_menu.SetupPresent(pDevice);
		g_menu.SetupTextures(pDevice);

		initialised_renderer = true;
	}
	else {
		IDirect3DVertexDeclaration9* decl = nullptr;
		IDirect3DVertexShader9* shader = nullptr;
		IDirect3DStateBlock9* block = nullptr;

		pDevice->GetVertexDeclaration(&decl);
		pDevice->GetVertexShader(&shader);
		pDevice->CreateStateBlock(D3DSBT_PIXELSTATE, &block);
		block->Capture();

		render::setup_render_state();
		ctx.on_render();

		//backup render states
		DWORD colorwrite, srgbwrite;
		pDevice->GetRenderState(D3DRS_COLORWRITEENABLE, &colorwrite);
		pDevice->GetRenderState(D3DRS_SRGBWRITEENABLE, &srgbwrite);

		// fix drawing without calling engine functons/cl_showpos
		pDevice->SetRenderState(D3DRS_COLORWRITEENABLE, 0xffffffff);
		// removes the source engine color correction
		pDevice->SetRenderState(D3DRS_SRGBWRITEENABLE, false);

		g_menu.PostRender(pDevice);
		g_menu.Think(pDevice);
		g_menu.EndPresent(pDevice);

		//restore these
		pDevice->SetRenderState(D3DRS_COLORWRITEENABLE, colorwrite);
		pDevice->SetRenderState(D3DRS_SRGBWRITEENABLE, srgbwrite);

		block->Apply();
		block->Release();
		pDevice->SetVertexShader(shader);
		pDevice->SetVertexDeclaration(decl);

		g_input.update();

		InputHelper::Update();

		bool old_night = g_cfg[XOR("misc_world_night")].get< bool >();
		float old_night_darkness = g_cfg[XOR("misc_world_night_darkness")].get< float >();
		float old_prop_opacity = g_cfg[XOR("misc_world_prop_opacity")].get< float >();

		bool old_skins = g_cfg[XOR("skins_enable")].get< bool >();
		int old_knife = g_cfg[XOR("skins_knife")].get< int >();
		int old_gloves = g_cfg[XOR("skins_gloves")].get< int >();
		int old_glove_skins = g_cfg[XOR("skins_glove_kit")].get< int >();
		float old_volume = g_cfg[XOR("misc_hitsound_volume")].get< float >();
		int old_sound = g_cfg[XOR("misc_custom_hitsound")].get< int >();

		if (old_night != g_cfg[XOR("misc_world_night")].get< bool >() ||
			old_night_darkness != g_cfg[XOR("misc_world_night_darkness")].get< float >() ||
			old_prop_opacity != g_cfg[XOR("misc_world_prop_opacity")].get< float >()) {
			ctx.m_update_night = true;
		}

		if (old_skins != g_cfg[XOR("skins_enable")].get< bool >() ||
			old_knife != g_cfg[XOR("skins_knife")].get< int >() ||
			old_gloves != g_cfg[XOR("skins_gloves")].get< int >() ||
			old_glove_skins != g_cfg[XOR("skins_glove_kit")].get< int >()) {
			skins.m_update = true;
		}

		//if (old_volume != g_cfg[XOR("misc_hitsound_volume")].get<  float  >() || old_sound != g_cfg[XOR("misc_custom_hitsound")].get<  int  >()) {
		//	ctx.m_update_sound = true;
		//}

	
		visuals.m_thirdperson = g_config.get_hotkey(XOR("misc_thirdperson_key"));
		movement.m_slow_motion = g_config.get_hotkey(XOR("misc_slowwalk_bind"));
		aimbot.m_enable = g_cfg[XOR("aimbot_enable")].get<  bool  >();
	//	aimbot.m_override_hitboxes = g_config.get_hotkey(XOR("hitbox_override_key"));
		aimbot.m_override_damage = g_config.get_hotkey(XOR("override_min_dmg_key"));
		aimbot.m_force_body = g_config.get_hotkey(XOR("rage_aimbot_baim_key"));
		
	


	}

	return hook_handler.m_device.get_method<decltype(&Present)>(17)(pDevice, pRect1, pRect2, hWnd, pRGNData);
}

HRESULT WINAPI c_hook_handler::Reset(IDirect3DDevice9* pDevice, D3DPRESENT_PARAMETERS* pPresentParameters)
{
	ImGui_ImplDX9_InvalidateDeviceObjects();
	auto result = hook_handler.m_device.get_method<decltype(&Reset)>(16)(pDevice, pPresentParameters);

	if (result >= 0)
		ImGui_ImplDX9_CreateDeviceObjects();

	return result;
}