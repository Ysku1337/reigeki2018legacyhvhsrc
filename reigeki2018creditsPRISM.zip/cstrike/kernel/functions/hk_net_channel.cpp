#include "../../project.hpp"

#define NET_FRAMES_BACKUP 64 // must be power of 2. 
#define NET_FRAMES_MASK ( NET_FRAMES_BACKUP - 1 )

int c_hook_handler::hk_send_datagram( void* data ) {
	int backup2 = cstrike.m_net->m_in_seq;

	//if( aimbot.m_fake_latency ) {
	//	int ping = g_menu.main.misc.fake_latency_amt.get( );

	//	// the target latency.
	//	float correct = std::max( 0.f, ( ping / 1000.f ) - ctx.m_latency - ctx.m_lerp );

	//	cstrike.m_net->m_in_seq += 2 * NET_FRAMES_MASK - static_cast< uint32_t >( NET_FRAMES_MASK * correct );
	//}

	int ret = hook_handler.m_net_channel.get_method< send_datagram_t >( i_net_channel::SENDDATAGRAM )( this, data );

	cstrike.m_net->m_in_seq = backup2;

	return ret;
}

void c_hook_handler::hk_process_packet( void* packet, bool header ) {
	hook_handler.m_net_channel.get_method< process_packet_t >( i_net_channel::PROCESSPACKET )( this, packet, header );

	ctx.update_incoming_sequences( );

	// get this from CL_FireEvents string "Failed to execute event for classId" in engine.dll
	for( c_event_info* it{ cstrike.m_cl->m_events }; it != nullptr; it = it->m_next ) {
		if( !it->m_class_id )
			continue;

		// set all delays to instant.
		it->m_fire_delay = 0.f;
	}

	// game events are actually fired in OnRenderStart which is WAY later after they are received
	// effective delay by lerp time, now we call them right after theyre received (all receive proxies are invoked without delay).
	cstrike.m_engine->fire_events( );
}