#include "../project.hpp"

c_hook_handler                hook_handler{ };;
custom_entity_listener        g_custom_entity_listener{ };;

void pitch_proxy(c_recv_proxy_data* data, Address ptr, Address out) {
	// normalize this fucker.
	math::normalize_angle(data->m_Value.m_Float);

	// clamp to remove retardedness.
	math::clamp(data->m_Value.m_Float, -90.f, 90.f);

	// call original netvar proxy.
	if (hook_handler.m_pitch_original)
		hook_handler.m_pitch_original(data, ptr, out);
}

void body_proxy(c_recv_proxy_data* data, Address ptr, Address out) {
	Stack stack;

	static Address RecvTable_Decode{ pattern::find(cstrike.m_engine_dll, XOR("EB 0D FF 77 10")) };

	// call from entity going into pvs.
	if (stack.next().next().ReturnAddress() != RecvTable_Decode) {
		// convert to player.
		c_base_player* player = ptr.as< c_base_player* >();

		// store data about the update.
		resolver.on_body_update(player, data->m_Value.m_Float);
	}

	// call original proxy.
	if (hook_handler.m_body_original)
		hook_handler.m_body_original(data, ptr, out);
}

void abs_yaw_proxy(c_recv_proxy_data* data, Address ptr, Address out) {
	// convert to ragdoll.
	//Ragdoll* ragdoll = ptr.as< Ragdoll* >( );

	// get ragdoll owner.
	//Player* player = ragdoll->GetPlayer( );

	// get data for this player.
	/*AimPlayer* aim = &g_aimbot.m_players[ player->index( ) - 1 ];

	if( player && aim ) {
	if( !aim->m_records.empty( ) ) {
	LagRecord* match{ nullptr };

	// iterate records.
	for( const auto &it : aim->m_records ) {
	// find record that matches with simulation time.
	if( it->m_sim_time == player->m_flSimulationTime( ) ) {
	match = it.get( );
	break;
	}
	}

	// we have a match.
	// and it is standing
	// TODO; add air?
	if( match /*&& match->m_mode == Resolver::Modes::RESOLVE_STAND*/// ) {
	/*	RagdollRecord record;
	record.m_record   = match;
	record.m_rotation = math::NormalizedAngle( data->m_Value.m_Float );
	record.m_delta    = math::NormalizedAngle( record.m_rotation - match->m_lbyt );

	float death = math::NormalizedAngle( ragdoll->m_flDeathYaw( ) );

	// store.
	//aim->m_ragdoll.push_front( record );

	//ctx.print( tfm::format( XOR( "rot %f death %f delta %f\n" ), record.m_rotation, death, record.m_delta ).data( ) );
	}
	}*/
	//}

	// call original netvar proxy.
	if (hook_handler.m_abs_yaw_original)
		hook_handler.m_abs_yaw_original(data, ptr, out);
}

void force_proxy(c_recv_proxy_data* data, Address ptr, Address out) {
	// convert to ragdoll.
	ragdoll_t* ragdoll = ptr.as< ragdoll_t* >();

	// get ragdoll owner.
	c_base_player* player = ragdoll->get_player();

	// we only want this happening to noobs we kill.
	//if (g_menu.main.misc.ragdoll_force.get() && ctx.m_local && player && player->enemy(ctx.m_local)) {
	//	// get m_vecForce.
	//	vec3_t vel = { data->m_Value.m_Vector[0], data->m_Value.m_Vector[1], data->m_Value.m_Vector[2] };

	//	// give some speed to all directions.
	//	vel *= 1000.f;

	//	// boost z up a bit.
	//	if (vel.z <= 1.f)
	//		vel.z = 2.f;

	//	vel.z *= 2.f;

	//	// don't want crazy values for this... probably unlikely though?
	//	math::clamp(vel.x, std::numeric_limits< float >::lowest(), std::numeric_limits< float >::max());
	//	math::clamp(vel.y, std::numeric_limits< float >::lowest(), std::numeric_limits< float >::max());
	//	math::clamp(vel.z, std::numeric_limits< float >::lowest(), std::numeric_limits< float >::max());

	//	// set new velocity.
	//	data->m_Value.m_Vector[0] = vel.x;
	//	data->m_Value.m_Vector[1] = vel.y;
	//	data->m_Value.m_Vector[2] = vel.z;
	//}

	if (hook_handler.m_force_original)
		hook_handler.m_force_original(data, ptr, out);
}

void c_hook_handler::initialize() {
	// hook wndproc.
	cstrike.m_window = FindWindowA(XOR("Valve001"), NULL);
	m_old_wndproc = (WNDPROC)winapi.SetWindowLongA(cstrike.m_window, GWL_WNDPROC, util::force_cast<LONG>(c_hook_handler::WndProc));

	// setup normal VMT hooks.
	m_panel.init(cstrike.m_panel);
	m_panel.add(i_panel::PAINTTRAVERSE, util::force_cast(&c_hook_handler::hk_paint_traverse));

	m_client.init(cstrike.m_client);
	m_client.add(chl_client::LEVELINITPREENTITY, util::force_cast(&c_hook_handler::hk_level_init_pre_entity));
	m_client.add(chl_client::LEVELINITPOSTENTITY, util::force_cast(&c_hook_handler::hk_level_init_post_entity));
	m_client.add(chl_client::LEVELSHUTDOWN, util::force_cast(&c_hook_handler::hk_level_shutdown));
	m_client.add(chl_client::FRAMESTAGENOTIFY, util::force_cast(&c_hook_handler::hk_frame_stage_notify));


	m_engine.init(cstrike.m_engine);
	m_engine.add(iv_engine_client::ISCONNECTED, util::force_cast(&c_hook_handler::hk_is_connected));
	m_engine.add(iv_engine_client::ISHLTV, util::force_cast(&c_hook_handler::hk_is_hltv));

	m_prediction.init(cstrike.m_prediction);
	m_prediction.add(c_prediciton::INPREDICTION, util::force_cast(&c_hook_handler::hk_in_prediction));
	m_prediction.add(c_prediciton::RUNCOMMAND, util::force_cast(&c_hook_handler::hk_run_command));


	m_client_mode.init(cstrike.m_client_mode);
	m_client_mode.add(i_client_mode::SHOULDDRAWPARTICLES, util::force_cast(&c_hook_handler::hk_should_draw_particles));
	m_client_mode.add(i_client_mode::SHOULDDRAWFOG, util::force_cast(&c_hook_handler::hk_should_draw_fog));
	m_client_mode.add(i_client_mode::OVERRIDEVIEW, util::force_cast(&c_hook_handler::hk_override_view));
	m_client_mode.add(i_client_mode::CREATEMOVE, util::force_cast(&c_hook_handler::hk_create_move));
	m_client_mode.add(i_client_mode::DOPOSTSPACESCREENEFFECTS, util::force_cast(&c_hook_handler::hk_do_post_screen_space_effects));

	m_surface.init(cstrike.m_surface);
	m_surface.add(i_surface::LOCKCURSOR, util::force_cast(&c_hook_handler::hk_lock_cursor));
	m_surface.add(i_surface::PLAYSOUND, util::force_cast(&c_hook_handler::hk_play_sound));
	m_surface.add(i_surface::ONSCREENSIZECHANGED, util::force_cast(&c_hook_handler::hk_on_screen_size_changed));

	m_model_render.init(cstrike.m_model_render);
	m_model_render.add(iv_model_render::DRAWMODELEXECUTE, util::force_cast(&c_hook_handler::hk_draw_model_execute));

	m_render_view.init(cstrike.m_render_view);
	m_render_view.add(iv_render_view::SCENEEND, util::force_cast(&c_hook_handler::hk_sceneend));

	m_shadow_mgr.init(cstrike.m_shadow_mgr);
	m_shadow_mgr.add(i_client_shadow_mgr::COMPUTESHADOWDEPTHTEXTURES, util::force_cast(&c_hook_handler::hk_compute_shadow_depth_textures));

	m_view_render.init(cstrike.m_view_render);
	m_view_render.add(c_view_render::ONRENDERSTART, util::force_cast(&c_hook_handler::hk_on_render_start));
	m_view_render.add(c_view_render::RENDERVIEW, util::force_cast(&c_hook_handler::hk_render_view));
	m_view_render.add(c_view_render::RENDER2DEFFECTSPOSTHUD, util::force_cast(&c_hook_handler::hk_render_2d_effects_post_hud));
	m_view_render.add(c_view_render::RENDERSMOKEOVERLAY, util::force_cast(&c_hook_handler::hk_render_smoke_overlay));

	m_match_framework.init(cstrike.m_match_framework);
	m_match_framework.add(c_match_framework::GETMATCHSESSION, util::force_cast(&c_hook_handler::hk_get_match_session));

	m_material_system.init(cstrike.m_material_system);
	m_material_system.add(i_material_system::OVERRIDECONFIG, util::force_cast(&c_hook_handler::hk_override_config));

	m_fire_bullets.init(cstrike.TEFireBullets);
	m_fire_bullets.add(7, util::force_cast(&c_hook_handler::hk_post_data_update));

	m_device.init(cstrike.m_device);
	m_device.add(17, util::force_cast(&c_hook_handler::Present));
	m_device.add( 16, util::force_cast( &c_hook_handler::Reset ) );

	g_custom_entity_listener.init();

	// cvar hooks.
	m_debug_spread.init(cstrike.weapon_debug_spread_show);
	m_debug_spread.add(c_convar::GETINT, util::force_cast(&c_hook_handler::hk_debug_spread_get_int));

	m_cl_csm_shadows.init(cstrike.cl_csm_shadows);
	m_cl_csm_shadows.add(c_convar::GETINT, util::force_cast(&c_hook_handler::hk_csm_shadow_get_int));


	m_sv_competitive_minspec.init(cstrike.sv_competitive_minspec);
	m_sv_competitive_minspec.add(c_convar::GETINT, util::force_cast(&c_hook_handler::hk_sv_competitive_minspec_get_int));




	m_net_show_fragments.init(cstrike.net_showfragments);
	m_net_show_fragments.add(c_convar::GETBOOL, util::force_cast(&c_hook_handler::hk_net_show_fragments_get_bool));

	// set netvar proxies.
	netvars.SetProxy(HASH("DT_CSPlayer"), HASH("m_angEyeAngles[0]"), pitch_proxy, m_pitch_original);
	netvars.SetProxy(HASH("DT_CSPlayer"), HASH("m_flLowerBodyYawTarget"), body_proxy, m_body_original);
	netvars.SetProxy(HASH("DT_CSRagdoll"), HASH("m_vecForce"), force_proxy, m_force_original);
	netvars.SetProxy(HASH("DT_CSRagdoll"), HASH("m_flAbsYaw"), abs_yaw_proxy, m_abs_yaw_original);
}