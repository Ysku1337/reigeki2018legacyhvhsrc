#pragma once

// predeclares.
class c_animation_state;
class c_cs_game_rules;

class c_cstrike {
public:
	using MD5_PseudoRandom_t = uint32_t(__thiscall*)(uint32_t);
	using GetGlowObjectManager_t = c_glow_object_manager * (__cdecl*)();
	using RandomSeed_t = void(__cdecl*)(int);
	using RandomInt_t = int(__cdecl*)(int, int);
	using RandomFloat_t = float(__cdecl*)(float, float);
	using IsBreakableEntity_t = bool(__thiscall*)(entity_t*);
	using AngleMatrix_t = void(__fastcall*)(const ang_t&, matrix3x4_t&);
	using LoadFromBuffer_t = bool(__thiscall*)(key_values*, const char*, const char*, void*, void*, void*);
	using ServerRankRevealAll_t = bool(__cdecl*)(c_cs_usr_msg_server_rank_reveal_all*);
	using IsReady_t = void(__cdecl*)();
	using ShowAndUpdateSelection_t = void(__thiscall*)(c_hud_element*, int, weapon_t*, bool);
	using GetEconItemView_t = c_econ_item_view * (__thiscall*)(weapon_t*);
	using GetStaticData_t = c_econ_item_definition * (__thiscall*)(c_econ_item_view*);
	using ConcatTransforms_t = void(__fastcall*)();
	using BeamAlloc_t = beam_t * (__thiscall*)(i_view_render_beams*, bool);
	using SetupBeam_t = void(__stdcall*)(beam_t*, const beam_info_t&);
	using ClearNotices_t = void(__thiscall*)(killfeed_t*);
	using AddListenerEntity_t = void(__stdcall*)(i_entity_listener*);
	using GetShotgunSpread_t = void(__stdcall*)(int, int, int, float*, float*);

public:
	bool m_done;

	// module objects.
	PE::Module m_kernel32_dll;
	PE::Module m_user32_dll;
	PE::Module m_shell32_dll;
	PE::Module m_shlwapi_dll;
	PE::Module m_client_dll;
	PE::Module m_engine_dll;
	PE::Module m_vstdlib_dll;
	PE::Module m_tier0_dll;
	PE::Module m_serverbrowser_dll;
	PE::Module m_shaderapidx9_dll;

public:
	// interface ptrs.
	chl_client* m_client;
	i_cvar* m_cvar;
	iv_engine_client* m_engine;
	i_client_entity_list* m_entlist;
	i_input_system* m_input_system;
	i_surface* m_surface;
	i_panel* m_panel;
	i_engine_vgui* m_engine_vgui;
	c_prediciton* m_prediction;
	i_engine_trace* m_engine_trace;
	c_game_movement* m_game_movement;
	iv_render_view* m_render_view;
	c_view_render* m_view_render;
	iv_model_render* m_model_render;
	i_material_system* m_material_system;
	c_studio_render_context* m_studio_render;
	iv_model_info* m_model_info;
	iv_debug_overlay* m_debug_overlay;
	i_physics_surface_props* m_phys_props;
	i_game_event_manager2* m_game_events;
	c_match_framework* m_match_framework;
	i_localize* m_localize;
	i_network_string_table_container* m_networkstringtable;
	i_engine_sound* m_sound;

	i_client_mode* m_client_mode;
	c_global_vars_base* m_globals;
	c_input* m_input;
	i_move_helper* m_move_helper;
	i_net_channel* m_net;

	c_glow_object_manager* m_glow;
	c_client_state* m_cl;
	c_game_engine* m_game;
	c_render* m_render;
	i_mem_alloc* m_mem_alloc;
	i_client_shadow_mgr* m_shadow_mgr;
	// IClientEntityListener** m_entity_listeners;
	c_hud* m_hud;
	c_cs_game_rules* m_gamerules;
	i_view_render_beams* m_beams;
	void* m_radar;
	void* m_hookable_cl;

	IDirect3DDevice9* m_device;
	HWND m_window;

public:
	// convars.
	c_convar* clear;
	c_convar* toggleconsole;
	c_convar* name;
	c_convar* sv_maxunlag;
	c_convar* sv_gravity;
	c_convar* sv_jump_impulse;
	c_convar* sv_enablebunnyhopping;
	c_convar* sv_airaccelerate;
	c_convar* sv_friction;
	c_convar* sv_stopspeed;
	c_convar* sv_cheats;
	c_convar* cl_interp;
	c_convar* cl_interp_ratio;
	c_convar* mp_c4timer;
	c_convar* cl_updaterate;
	c_convar* cl_cmdrate;
	c_convar* cl_lagcompensation;
	c_convar* mp_teammates_are_enemies;
	c_convar* weapon_debug_spread_show;
	c_convar* cl_csm_shadows;
	c_convar* cl_extrapolate;
	c_convar* mat_wireframe;
	c_convar* molotov_throw_detonate_time;
	c_convar* weapon_molotov_maxdetonateslope;
	c_convar* weapon_recoil_scale;
	c_convar* view_recoil_tracking;
	c_convar* cl_fullupdate;
	c_convar* r_DrawSpecificStaticProp;
	c_convar* cl_crosshair_sniper_width;
	c_convar* hud_scaling;
	c_convar* sv_clip_penetration_traces_to_players;
	c_convar* weapon_accuracy_shotgun_spread_patterns;
	c_convar* viewmodel_offset_x;
	c_convar* viewmodel_offset_y;
	c_convar* viewmodel_offset_z;
	c_convar* r_drawmodelstatsoverlay;
	c_convar* sv_competitive_minspec;
	c_convar* cl_use_new_headbob;
	c_convar* fog_override;
	c_convar* fog_color;
	c_convar* fog_start;
	c_convar* fog_end;
	c_convar* fog_maxdensity;
	c_convar* sv_maxspeed;
	c_convar* net_showfragments;

public:
	// functions.
	GetGlowObjectManager_t   GetGlowObjectManager;
	MD5_PseudoRandom_t	     MD5_PseudoRandom;
	Address                  SetAbsAngles;
	Address				     SetAbsOrigin;
	Address                  InvalidateBoneCache;
	Address				     LockStudioHdr;
	//Address					 DisablePostProcess;
	RandomSeed_t             RandomSeed;
	RandomInt_t              RandomInt;
	RandomFloat_t            RandomFloat;
	IsBreakableEntity_t      IsBreakableEntity;
	Address	                 SetAbsVelocity;
	AngleMatrix_t            AngleMatrix;
	Address					 DoProceduralFootPlant;
	Address					 ComputeHitboxSurroundingBox;
	Address					 GetSequenceActivity;
	LoadFromBuffer_t		 LoadFromBuffer;
	ServerRankRevealAll_t    ServerRankRevealAll;
	Address					 HasC4;
	Address                  UpdateHud;
	Address                  PainkitDefinition;
	Address					 InvalidatePhysicsRecursive;
	IsReady_t				 IsReady;
	ShowAndUpdateSelection_t ShowAndUpdateSelection;
	GetEconItemView_t        GetEconItemView;
	GetStaticData_t          GetStaticData;
	Address					 TEFireBullets;
	BeamAlloc_t              BeamAlloc;
	SetupBeam_t              SetupBeam;
	ClearNotices_t           ClearNotices;
	AddListenerEntity_t      AddListenerEntity;
	GetShotgunSpread_t       GetShotgunSpread;

	size_t BoneAccessor;
	size_t AnimOverlay;
	size_t SpawnTime;
	size_t MostRecentModelBoneCounter;
	size_t LastBoneSetupTime;
	size_t IsLocalPlayer;
	size_t PlayerAnimState;
	size_t studioHdr;

	Address UTIL_TraceLine;
	Address CTraceFilterSimple_vmt;
	Address CTraceFilterSkipTwoEntities_vmt;

	int* m_nPredictionRandomSeed;
	c_base_player* m_pPredictionPlayer;

public:
	// initialize class.
	bool initialize();
};

extern c_cstrike cstrike;

namespace game {
	__forceinline float get_client_interp_amount() {
		return std::max(cstrike.cl_interp->get_float(), cstrike.cl_interp_ratio->get_float() / cstrike.cl_updaterate->get_float());
	}

	__forceinline int time_to_ticks(float time) {
		return (int)(0.5f + time / cstrike.m_globals->m_interval);
	}

	__forceinline float ticks_to_time(int ticks) {
		return cstrike.m_globals->m_interval * (float)(ticks);
	}

	__forceinline bool is_fake_player(int index) {
		player_info_t info;
		if (cstrike.m_engine->get_player_info(index, &info))
			return info.m_fake_player;

		return false;
	}

	__forceinline bool is_valid_hitgroup(int index) {
		if ((index >= HITGROUP_HEAD && index <= HITGROUP_RIGHTLEG) || index == HITGROUP_GEAR)
			return true;

		return false;
	}

	// note - dex; all of the static sigscans here should be moved to CSGO class... funcs that rely on these do 2 test statements to make sure the data is initialized
	//             also, nitro, is there a reason these are not __forceinline? i forget if you told me they must be inline.
	inline void create_animation_state(c_base_player* holder, c_animation_state* state) {
		using create_animation_state_t = void(__thiscall*)(c_animation_state*, c_base_player*);

		static auto func = pattern::find(cstrike.m_client_dll, XOR("55 8B EC 56 8B F1 B9 ? ? ? ? C7 46")).as< create_animation_state_t >();
		if (!func)
			return;

		func(state, holder);
	}

	inline void update_animation_state(c_animation_state* state, ang_t ang) {
		static auto func = pattern::find(cstrike.m_client_dll, XOR("E8 ? ? ? ? 0F 57 C0 0F 11 86")).rel32< uintptr_t >(0x1);
		if (!func)
			return;

		__asm {
			push  0
			mov	  ecx, state
			movss xmm1, dword ptr[ang + 4]
			movss xmm2, dword ptr[ang]
			call  func
		}
	}

	inline void reset_animation_state(c_animation_state* state) {
		using reset_animation_state_t = void(__thiscall*)(c_animation_state*);

		static auto func = pattern::find(cstrike.m_client_dll, XOR("56 6A 01 68 ? ? ? ? 8B F1")).as< reset_animation_state_t >();
		if (!func)
			return;

		func(state);
	}

	__forceinline void clip_trace_to_players(const vec3_t& start, const vec3_t& end, uint32_t mask, i_trace_filter* filter, c_game_trace* tr, float range) {
		static auto func = pattern::find(cstrike.m_client_dll, XOR("E8 ? ? ? ? 83 C4 14 8A 56 37")).rel32< uintptr_t >(0x1);
		if (!func)
			return;

		__asm {
			mov  ecx, start
			mov	 edx, end
			push range
			push tr
			push filter
			push mask
			call func
			add	 esp, 16
		}
	}

	__forceinline void concat_transforms(const matrix3x4_t& in1, const matrix3x4_t& in2, matrix3x4_t& output) {
		static auto func = pattern::find(cstrike.m_client_dll, XOR("E8 ? ? ? ? 0F 28 44 24")).rel32< uintptr_t >(0x1);
		if (!func)
			return;

		__asm {
			push output
			lea  edx, in2
			lea  ecx, in1
			call func
			add  esp, 4
		}
	}


	vec2_t screen_transform(vec3_t world);
	bool   is_breakable(entity_t* ent);
	beam_t* create_generic_beam(const beam_info_t& beam_info);
}