#include "../project.hpp"

c_cstrike	   cstrike{};;
windows_api	   winapi{};;
c_netvars	   netvars{};;
c_offsets      offsets{};;
Notify         notify{};;

bool c_cstrike::initialize() {
	m_done = false;

	if (m_done)
		return false;

	// wait for the game to init.
	// "serverbrowser.dll" is the last module to be loaded.
	// if it gets loaded we can be ensured that the entire game done loading.

#ifndef KOLO
	while (!m_serverbrowser_dll) {
		m_serverbrowser_dll = PE::GetModule(HASH("serverbrowser.dll"));
		if (!m_serverbrowser_dll)
			std::this_thread::sleep_for(std::chrono::milliseconds(100));
	}
#endif

	// grab some modules.
	m_kernel32_dll = PE::GetModule(HASH("kernel32.dll"));
	m_user32_dll = PE::GetModule(HASH("user32.dll"));
	m_shell32_dll = PE::GetModule(HASH("shell32.dll"));
	m_shlwapi_dll = PE::GetModule(HASH("shlwapi.dll"));
	m_client_dll = PE::GetModule(HASH("client.dll"));
	m_engine_dll = PE::GetModule(HASH("engine.dll"));
	m_vstdlib_dll = PE::GetModule(HASH("vstdlib.dll"));
	m_tier0_dll = PE::GetModule(HASH("tier0.dll"));
	m_shaderapidx9_dll = PE::GetModule(HASH("shaderapidx9.dll"));

	// import winapi functions.
	winapi.WideCharToMultiByte = PE::GetExport(m_kernel32_dll, HASH("WideCharToMultiByte")).as< windows_api::WideCharToMultiByte_t >();
	winapi.MultiByteToWideChar = PE::GetExport(m_kernel32_dll, HASH("MultiByteToWideChar")).as< windows_api::MultiByteToWideChar_t >();
	winapi.GetTickCount = PE::GetExport(m_kernel32_dll, HASH("GetTickCount")).as< windows_api::GetTickCount_t >();
	winapi.VirtualProtect = PE::GetExport(m_kernel32_dll, HASH("VirtualProtect")).as< windows_api::VirtualProtect_t >();
	winapi.VirtualQuery = PE::GetExport(m_kernel32_dll, HASH("VirtualQuery")).as< windows_api::VirtualQuery_t >();
	winapi.CreateDirectoryA = PE::GetExport(m_kernel32_dll, HASH("CreateDirectoryA")).as< windows_api::CreateDirectoryA_t >();
	winapi.SetWindowLongA = PE::GetExport(m_user32_dll, HASH("SetWindowLongA")).as< windows_api::SetWindowLongA_t >();
	winapi.CallWindowProcA = PE::GetExport(m_user32_dll, HASH("CallWindowProcA")).as< windows_api::CallWindowProcA_t >();
	winapi.SHGetFolderPathA = PE::GetExport(m_shell32_dll, HASH("SHGetFolderPathA")).as< windows_api::SHGetFolderPathA_t >();
	winapi.PathAppendA = PE::GetExport(m_shlwapi_dll, HASH("PathAppendA")).as< windows_api::PathAppendA_t >();

	// run interface collection code.
	Interfaces interfaces{};

	// get interface pointers.
	m_client = interfaces.get< chl_client* >(HASH("VClient"));
	m_cvar = interfaces.get< i_cvar* >(HASH("VEngineCvar"));
	m_engine = interfaces.get< iv_engine_client* >(HASH("VEngineClient"));
	m_entlist = interfaces.get< i_client_entity_list* >(HASH("VClientEntityList"));
	m_input_system = interfaces.get< i_input_system* >(HASH("InputSystemVersion"));
	m_surface = interfaces.get< i_surface* >(HASH("VGUI_Surface"));
	m_panel = interfaces.get< i_panel* >(HASH("VGUI_Panel"));
	m_engine_vgui = interfaces.get< i_engine_vgui* >(HASH("VEngineVGui"));
	m_prediction = interfaces.get< c_prediciton* >(HASH("VClientPrediction"));
	m_engine_trace = interfaces.get< i_engine_trace* >(HASH("EngineTraceClient"));
	m_game_movement = interfaces.get< c_game_movement* >(HASH("GameMovement"));
	m_render_view = interfaces.get< iv_render_view* >(HASH("VEngineRenderView"));
	m_model_render = interfaces.get< iv_model_render* >(HASH("VEngineModel"));
	m_material_system = interfaces.get< i_material_system* >(HASH("VMaterialSystem"));
	m_studio_render = interfaces.get< c_studio_render_context* >(HASH("VStudioRender"));
	m_model_info = interfaces.get< iv_model_info* >(HASH("VModelInfoClient"));
	m_debug_overlay = interfaces.get< iv_debug_overlay* >(HASH("VDebugOverlay"));
	m_phys_props = interfaces.get< i_physics_surface_props* >(HASH("VPhysicsSurfaceProps"));
	m_game_events = interfaces.get< i_game_event_manager2* >(HASH("GAMEEVENTSMANAGER"), 1);
	m_match_framework = interfaces.get< c_match_framework* >(HASH("MATCHFRAMEWORK_"));
	m_localize = interfaces.get< i_localize* >(HASH("Localize_"));
	m_networkstringtable = interfaces.get< i_network_string_table_container* >(HASH("VEngineClientStringTable"));
	m_sound = interfaces.get< i_engine_sound* >(HASH("IEngineSoundClient"));

	// convars.
	clear = m_cvar->find_var(HASH("clear"));
	toggleconsole = m_cvar->find_var(HASH("toggleconsole"));
	name = m_cvar->find_var(HASH("name"));
	sv_maxunlag = m_cvar->find_var(HASH("sv_maxunlag"));
	sv_gravity = m_cvar->find_var(HASH("sv_gravity"));
	sv_jump_impulse = m_cvar->find_var(HASH("sv_jump_impulse"));
	sv_enablebunnyhopping = m_cvar->find_var(HASH("sv_enablebunnyhopping"));
	sv_airaccelerate = m_cvar->find_var(HASH("sv_airaccelerate"));
	sv_friction = m_cvar->find_var(HASH("sv_friction"));
	sv_stopspeed = m_cvar->find_var(HASH("sv_stopspeed"));
	cl_interp = m_cvar->find_var(HASH("cl_interp"));
	cl_interp_ratio = m_cvar->find_var(HASH("cl_interp_ratio"));
	mp_c4timer = m_cvar->find_var(HASH("mp_c4timer"));
	cl_updaterate = m_cvar->find_var(HASH("cl_updaterate"));
	cl_cmdrate = m_cvar->find_var(HASH("cl_cmdrate"));
	cl_lagcompensation = m_cvar->find_var(HASH("cl_lagcompensation"));
	mp_teammates_are_enemies = m_cvar->find_var(HASH("mp_teammates_are_enemies"));
	weapon_debug_spread_show = m_cvar->find_var(HASH("weapon_debug_spread_show"));
	cl_csm_shadows = m_cvar->find_var(HASH("cl_csm_shadows"));
	cl_extrapolate = m_cvar->find_var(HASH("cl_extrapolate"));
	sv_cheats = m_cvar->find_var(HASH("sv_cheats"));
	molotov_throw_detonate_time = m_cvar->find_var(HASH("molotov_throw_detonate_time"));
	weapon_molotov_maxdetonateslope = m_cvar->find_var(HASH("weapon_molotov_maxdetonateslope"));
	weapon_recoil_scale = m_cvar->find_var(HASH("weapon_recoil_scale"));
	view_recoil_tracking = m_cvar->find_var(HASH("view_recoil_tracking"));
	cl_fullupdate = m_cvar->find_var(HASH("cl_fullupdate"));
	r_DrawSpecificStaticProp = m_cvar->find_var(HASH("r_DrawSpecificStaticProp"));
	cl_crosshair_sniper_width = m_cvar->find_var(HASH("cl_crosshair_sniper_width"));
	hud_scaling = m_cvar->find_var(HASH("hud_scaling"));
	sv_clip_penetration_traces_to_players = m_cvar->find_var(HASH("sv_clip_penetration_traces_to_players"));
	weapon_accuracy_shotgun_spread_patterns = m_cvar->find_var(HASH("weapon_accuracy_shotgun_spread_patterns"));
	viewmodel_offset_x = m_cvar->find_var(HASH("viewmodel_offset_x"));
	viewmodel_offset_y = m_cvar->find_var(HASH("viewmodel_offset_y"));
	viewmodel_offset_z = m_cvar->find_var(HASH("viewmodel_offset_z"));
	mat_wireframe = m_cvar->find_var(HASH("mat_wireframe"));
	r_drawmodelstatsoverlay = m_cvar->find_var(HASH("r_drawmodelstatsoverlay"));
	sv_competitive_minspec = m_cvar->find_var(HASH("sv_competitive_minspec"));
	cl_use_new_headbob = m_cvar->find_var(HASH("cl_use_new_headbob"));
	fog_override = m_cvar->find_var(HASH("fog_override"));
	fog_color = m_cvar->find_var(HASH("fog_color"));
	fog_start = m_cvar->find_var(HASH("fog_start"));
	fog_end = m_cvar->find_var(HASH("fog_end"));
	fog_maxdensity = m_cvar->find_var(HASH("fog_maxdensity"));
	sv_maxspeed = m_cvar->find_var(HASH("sv_maxspeed"));
	net_showfragments = m_cvar->find_var(HASH("net_showfragments"));

	// hehe xd.
	name->m_callbacks.RemoveAll();
	//cl_lagcompensation->m_callbacks.RemoveAll( );
	//cl_lagcompensation->m_flags &= ~FCVAR_NOT_CONNECTED;

	// classes by sig.
	m_move_helper = pattern::find(m_client_dll, XOR("8B 0D ? ? ? ? 8B 46 08 68")).add(2).get< i_move_helper* >(2);
	m_cl = **reinterpret_cast<c_client_state***> ((*reinterpret_cast<uintptr_t**> (m_engine))[12] + 0x10);
	m_game = pattern::find(m_engine_dll, XOR("A1 ? ? ? ? B9 ? ? ? ? FF 75 08 FF 50 34")).add(1).get< c_game_engine* >();
	m_render = pattern::find(m_engine_dll, XOR("A1 ? ? ? ? B9 ? ? ? ? FF 75 0C FF 75 08 FF 50 0C")).add(1).get< c_render* >();
	m_shadow_mgr = pattern::find(m_client_dll, XOR("A1 ? ? ? ? FF 90 ? ? ? ? 6A 00")).add(1).get().as< i_client_shadow_mgr* >();
	m_view_render = pattern::find(m_client_dll, XOR("8B 0D ? ? ? ? 8B 01 FF 50 4C 8B 06")).add(2).get< c_view_render* >(2);
	// m_entity_listeners   = pattern::find( m_client_dll, XOR( "B9 ? ? ? ? E8 ? ? ? ? 5E 5D C2 04" ) ).add( 0x1 ).get< IClientEntityListener** >( 2 );
	m_hud = pattern::find(m_client_dll, XOR("B9 ? ? ? ? 0F 94 C0 0F B6 C0 50 68")).add(0x1).get().as< c_hud* >();
	m_gamerules = pattern::find(m_client_dll, XOR("8B 0D ? ? ? ? E8 ? ? ? ? 84 C0 75 6B")).add(0x2).get< c_cs_game_rules* >();
	m_beams = pattern::find(m_client_dll, XOR("8D 04 24 50 A1 ? ? ? ? B9")).add(0x5).get< i_view_render_beams* >();
	m_mem_alloc = PE::GetExport(m_tier0_dll, HASH("g_pMemAlloc")).get< i_mem_alloc* >();
	GetGlowObjectManager = pattern::find(m_client_dll, XOR("A1 ? ? ? ? A8 01 75 4B")).as< GetGlowObjectManager_t >();
	m_glow = GetGlowObjectManager();
	m_hookable_cl = reinterpret_cast<void*>(*reinterpret_cast<uintptr_t**>(reinterpret_cast<uintptr_t>(m_cl) + 0x8));

	// classes by offset from virtual.
	m_globals = util::get_method(m_client, chl_client::INIT).add(0x1b).get< c_global_vars_base* >(2);
	m_client_mode = util::get_method(m_client, chl_client::HUDPROCESSINPUT).add(0x5).get< i_client_mode* >(2);
	m_input = util::get_method(m_client, chl_client::INACTIVATEMOUSE).at< c_input* >(0x1);

	m_device = **pattern::find(m_shaderapidx9_dll, XOR("A1 ?? ?? ?? ?? 50 8B 08 FF 51 0C")).add(0x1).as<IDirect3DDevice9***>();

	// functions.
	MD5_PseudoRandom = pattern::find(m_client_dll, XOR("55 8B EC 83 E4 F8 83 EC 70 6A 58")).as< MD5_PseudoRandom_t >();
	SetAbsAngles = pattern::find(m_client_dll, XOR("55 8B EC 83 E4 F8 83 EC 64 53 56 57 8B F1 E8"));
	InvalidateBoneCache = pattern::find(m_client_dll, XOR("80 3D ? ? ? ? ? 74 16 A1 ? ? ? ? 48 C7 81"));
	LockStudioHdr = pattern::find(m_client_dll, XOR("55 8B EC 51 53 8B D9 56 57 8D B3"));
	SetAbsOrigin = pattern::find(m_client_dll, XOR("55 8B EC 83 E4 F8 51 53 56 57 8B F1"));
	//DisablePostProcess = pattern::find(m_client_dll, XOR("80 3D ? ? ? ? ? 53 56 57 0F 85")).add(0x2);
	IsBreakableEntity = pattern::find(m_client_dll, XOR("55 8B EC 51 56 8B F1 85 F6 74 68 83 BE")).as< IsBreakableEntity_t >();
	SetAbsVelocity = pattern::find(m_client_dll, XOR("55 8B EC 83 E4 F8 83 EC 0C 53 56 57 8B 7D 08 8B F1"));
	AngleMatrix = pattern::find(m_client_dll, XOR("E8 ? ? ? ? 8B 07 89 46 0C")).rel32(0x1).as< AngleMatrix_t >();
	ComputeHitboxSurroundingBox = pattern::find(m_client_dll, XOR("E9 ? ? ? ? 32 C0 5D")).rel32(0x1);
	GetSequenceActivity = pattern::find(m_client_dll, XOR("53 56 8B F1 8B DA 85 F6 74 55"));
	LoadFromBuffer = pattern::find(m_client_dll, XOR("E8 ? ? ? ? 88 44 24 0F 8B 56 FC")).rel32(0x1).as< LoadFromBuffer_t >();
	ServerRankRevealAll = pattern::find(m_client_dll, XOR("55 8B EC 8B 0D ? ? ? ? 68")).as< ServerRankRevealAll_t >();
	HasC4 = pattern::find(m_client_dll, XOR("E8 ? ? ? ? 38 83")).rel32(0x1);
	UpdateHud = pattern::find(cstrike.m_client_dll, XOR("55 8B EC 51 53 56 8B 75 08 8B D9 57 6B FE 2C"));
	PainkitDefinition = pattern::find(cstrike.m_client_dll, XOR("E8 ? ? ? ? FF 76 0C 8D 48 04 E8"));
	InvalidatePhysicsRecursive = pattern::find(m_client_dll, XOR("E8 ? ? ? ? 89 5E 18")).rel32(0x1);
	IsReady = pattern::find(m_client_dll, XOR("E8 ? ? ? ? 59 C2 08 00 51 E8")).rel32(0x1).as< IsReady_t >();
	ShowAndUpdateSelection = pattern::find(m_client_dll, XOR("E8 ? ? ? ? A1 ? ? ? ? F3 0F 10 40 ? C6 83")).rel32(0x1).as< ShowAndUpdateSelection_t >();
	GetEconItemView = pattern::find(m_client_dll, XOR("8B 81 ? ? ? ? 81 C1 ? ? ? ? FF 50 04 83 C0 40 C3")).as< GetEconItemView_t >();
	GetStaticData = pattern::find(m_client_dll, XOR("55 8B EC 51 56 57 8B F1 E8 ? ? ? ? 0F B7 8E")).as< GetStaticData_t >();
	TEFireBullets = pattern::find(m_client_dll, XOR("C7 05 ? ? ? ? ? ? ? ? C7 05 ? ? ? ? ? ? ? ? 66 A3")).add(0x2).to();
	BeamAlloc = pattern::find(m_client_dll, XOR("E8 ? ? ? ? 8B F0 85 F6 74 7C")).rel32< BeamAlloc_t >(0x1);
	SetupBeam = pattern::find(m_client_dll, XOR("E8 ? ? ? ? 8B 07 33 C9")).rel32< SetupBeam_t >(0x1);
	ClearNotices = pattern::find(m_client_dll, XOR("E8 ? ? ? ? 68 ? ? ? ? B9 ? ? ? ? E8 ? ? ? ? 8B F0 85 F6 74 19")).rel32< ClearNotices_t >(0x1);
	AddListenerEntity = pattern::find(m_client_dll, XOR("55 8B EC 8B 0D ? ? ? ? 33 C0 56 85 C9 7E 32 8B 55 08 8B 35")).as< AddListenerEntity_t >();
	GetShotgunSpread = pattern::find(m_client_dll, XOR("E8 ? ? ? ? EB 38 83 EC 08")).rel32< GetShotgunSpread_t >(1);
	BoneAccessor = pattern::find(m_client_dll, XOR("8D 81 ? ? ? ? 50 8D 84 24")).add(2).to< size_t >();
	AnimOverlay = pattern::find(m_client_dll, XOR("8B 80 ? ? ? ? 8D 34 C8")).add(2).to< size_t >();
	SpawnTime = pattern::find(m_client_dll, XOR("F3 0F 5C 88 ? ? ? ? 0F")).add(4).to< size_t >();
	IsLocalPlayer = pattern::find(m_client_dll, XOR("74 ? 8A 83 ? ? ? ? 88")).add(4).to< size_t >();
	PlayerAnimState = pattern::find(m_client_dll, XOR("8B 8E ? ? ? ? 85 C9 74 3E")).add(2).to< size_t >();
	studioHdr = pattern::find(m_client_dll, XOR("8B 86 ? ? ? ? 89 44 24 10 85 C0")).add(2).to< size_t >();
	UTIL_TraceLine = pattern::find(m_client_dll, XOR("55 8B EC 83 E4 F0 83 EC 7C 56 52"));
	CTraceFilterSimple_vmt = UTIL_TraceLine.add(0x3D).to();
	CTraceFilterSkipTwoEntities_vmt = pattern::find(m_client_dll, XOR("E8 ? ? ? ? F3 0F 10 84 24 ? ? ? ? 8D 84 24 ? ? ? ? F3 0F 58 44 24")).rel32(1).add(0x59).to();
	LastBoneSetupTime = InvalidateBoneCache.add(0x11).to< size_t >();
	MostRecentModelBoneCounter = InvalidateBoneCache.add(0x1B).to< size_t >();

	// exported functions.
	RandomSeed = PE::GetExport(m_vstdlib_dll, HASH("RandomSeed")).as< RandomSeed_t >();
	RandomInt = PE::GetExport(m_vstdlib_dll, HASH("RandomInt")).as< RandomInt_t >();
	RandomFloat = PE::GetExport(m_vstdlib_dll, HASH("RandomFloat")).as< RandomFloat_t >();

	// prediction pointers.
	m_nPredictionRandomSeed = util::get_method(m_prediction, c_prediciton::RUNCOMMAND).add(0x30).get< int* >();
	m_pPredictionPlayer = util::get_method(m_prediction, c_prediciton::RUNCOMMAND).add(0x54).get< c_base_player* >();

	// some weird tier0 stuff that prevents me from debugging properly...
//#ifdef _DEBUG
//	Address debugbreak = pattern::find(cstrike.m_client_dll, XOR("CC F3 0F 10 4D ? 0F 57 C0"));
//
//	DWORD old;
//	winapi.VirtualProtect(debugbreak, 1, PAGE_EXECUTE_READWRITE, &old);
//
//	debugbreak.set< uint8_t >(0x90);
//
//	winapi.VirtualProtect(debugbreak, 1, old, &old);
//#endif

	// init everything else.
	g_config.init();

	// g_netvars stores all netvar offsets into an unordered_map, EntOffsets is for the raw offset values so we don't have to access the unordered_map a bunch.
	netvars.init();
	offsets.init();
	listener.init();
	render::init();
	chams.init();
	skins.init();
	hook_handler.initialize();

	// if we injected and we're ingame, run map load func.
	if (m_engine->is_in_game()) {
		ctx.on_map_load();
		//cstrike.cl_fullupdate->m_callback();
	}

	m_done = true;
	return true;
}

vec2_t game::screen_transform(vec3_t world) {
	//todo: replace with a diff matrix
	//this one spergs out sometimes

	const v_matrix& w2s_matrix = cstrike.m_engine->world_to_screen_matrix();

	vec2_t screen;
	auto w2s = [&world, &screen]() -> bool {

		const v_matrix& matrix = cstrike.m_engine->world_to_screen_matrix();
		screen.x = matrix[0][0] * world[0] + matrix[0][1] * world[1] + matrix[0][2] * world[2] + matrix[0][3];
		screen.y = matrix[1][0] * world[0] + matrix[1][1] * world[1] + matrix[1][2] * world[2] + matrix[1][3];

		float w = matrix[3][0] * world[0] + matrix[3][1] * world[1] + matrix[3][2] * world[2] + matrix[3][3];

		if (w < 0.001f) {
			//screen.x *= 100000.f;
			//screen.y *= 100000.f;
			return true;
		}

		float invw = 1.0f / w;
		screen.x *= invw;
		screen.y *= invw;

		return false;
	};

	w2s();
	//if ( !w2s( ) ) {
	int w, h;
	cstrike.m_engine->get_screen_size(w, h);

	screen.x = (w * .5f) + (screen.x * w) * .5f;
	screen.y = (h * .5f) - (screen.y * h) * .5f;

	return screen;
	//}

	return vec2_t{ };
}

bool game::is_breakable(entity_t* ent) {
	bool          ret;
	client_class* cc;
	const char* name;
	char* takedmg, old_takedmg;

	static size_t m_takedamage_offset{ *(size_t*)((uintptr_t)cstrike.IsBreakableEntity + 38) };

	// skip null ents and the world ent.
	if (!ent || ent->index() == 0)
		return false;

	// get m_takedamage and save old m_takedamage.
	takedmg = (char*)((uintptr_t)ent + m_takedamage_offset);
	old_takedmg = *takedmg;

	// get clientclass.
	cc = ent->get_client_class();

	if (cc) {
		// get clientclass network name.
		name = cc->m_pNetworkName;

		// CBreakableSurface, CBaseDoor, ...
		if (name[1] != 'F'
			|| name[4] != 'c'
			|| name[5] != 'B'
			|| name[9] != 'h') {
			*takedmg = DAMAGE_YES;
		}
	}

	ret = cstrike.IsBreakableEntity(ent);
	*takedmg = old_takedmg;

	return ret;
}

beam_t* game::create_generic_beam(const beam_info_t& beam_info) {
	beam_t* out;
	const model_t* sprite;

	out = cstrike.BeamAlloc(cstrike.m_beams, beam_info.m_bRenderable);
	if (!out)
		return nullptr;

	out->die = cstrike.m_globals->m_curtime;

	if (beam_info.m_nModelIndex < 0)
		return nullptr;

	sprite = cstrike.m_model_info->get_model(beam_info.m_nModelIndex);
	if (sprite) {
		out->type = (beam_info.m_nType < 0) ? 0 : beam_info.m_nType;
		out->modelIndex = beam_info.m_nModelIndex;
		out->haloIndex = beam_info.m_nHaloIndex;
		out->haloScale = beam_info.m_flHaloScale;
		out->frame = 0;
		out->frameRate = 0;
		out->frameCount = cstrike.m_model_info->get_model_frame_count(sprite);
		out->freq = cstrike.m_globals->m_curtime * beam_info.m_flSpeed;
		out->die = cstrike.m_globals->m_curtime + beam_info.m_flLife;
		out->width = beam_info.m_flWidth;
		out->endWidth = beam_info.m_flEndWidth;
		out->fadeLength = beam_info.m_flFadeLength;
		out->amplitude = beam_info.m_flAmplitude;
		out->brightness = beam_info.m_flBrightness;
		out->speed = beam_info.m_flSpeed;
		out->life = beam_info.m_flLife;
		out->flags = 0;
		out->attachment[0] = beam_info.m_vecStart;
		out->attachment[1] = beam_info.m_vecEnd;

		out->delta = (beam_info.m_vecEnd - beam_info.m_vecStart);

		if (beam_info.m_nSegments == -1) {
			if (out->amplitude >= 0.50)
				out->segments = out->delta.length() * 0.25 + 3;  // one per 4 pixels
			else
				out->segments = out->delta.length() * 0.075 + 3; // one per 16 pixels
		}

		else
			out->segments = beam_info.m_nSegments;
	}

	// note - dex; this is CViewRenderBeams::SetBeamAttributes, but it got inlined so i have to rebuild it.
	//             not sure if this is needed, it's taken from CViewRenderBeams::CreateBeamPoints.
	out->frame = (float)beam_info.m_nStartFrame;
	out->frameRate = beam_info.m_flFrameRate;
	out->flags |= beam_info.m_nFlags;
	out->r = beam_info.m_flRed;
	out->g = beam_info.m_flGreen;
	out->b = beam_info.m_flBlue;

	return out;
}