#pragma once

class c_sequence {
public:
	float m_time;
	int   m_state;
	int   m_seq;

public:
	__forceinline c_sequence() : m_time{}, m_state{}, m_seq{} {};
	__forceinline c_sequence(float time, int state, int seq) : m_time{ time }, m_state{ state }, m_seq{ seq } {};
};

class c_net_pos {
public:
	float  m_time;
	vec3_t m_pos;

public:
	__forceinline c_net_pos() : m_time{}, m_pos{} {};
	__forceinline c_net_pos(float time, vec3_t pos) : m_time{ time }, m_pos{ pos } {};
};

class c_ctx {
public:
	// hack thread.
	static ulong_t __stdcall initialize(void* arg);

	void start_move(c_user_cmd* cmd);
	void end_move(c_user_cmd* cmd);
	void backup_players(bool restore);
	void do_move();;
	void update_clientside_information();
	void set_angles();
	void set_angles2(ang_t angle);
	void killfeed();
	void mouse_delta();
	void clantag_changer();
	void on_render();
	void on_paint();
	void on_map_load();
	void on_tick(c_user_cmd* cmd);

	// debugprint function.
	void print(const std::string text, ...);

	// check if we are able to fire this tick.
	bool can_fire_weapon();
	void update_revolver();
	void update_incoming_sequences();
	void purchase_bot();

public:
	// local player variables.
	c_base_player* m_local;
	bool	         m_processing;
	int	             m_flags;
	vec3_t	         m_shoot_pos;
	bool	         m_player_fire;
	bool	         m_shot;
	bool	         m_old_shot;
	float            m_abs_yaw;
	float            m_poses[24];
	float			 m_left_thickness[64], m_right_thickness[64], m_at_target_angle[64];
	bool     m_pressing_move;

	// active weapon variables.
	weapon_t* m_weapon;
	int         m_weapon_id;
	c_weapon_info* m_weapon_info;
	int         m_weapon_type;
	bool        m_weapon_fire;

	// revolver variables.
	int	 m_revolver_cock;
	int	 m_revolver_query;
	bool m_revolver_fire;

	// general game varaibles.
	bool     m_round_end;
	int      m_round_flags;
	stage_t	 m_stage;
	int	     m_max_lag;
	int	     m_wanted_choke;
	bool	 m_should_lag;
	int      m_lag;
	int	     m_old_lag;
	bool*     m_packet;
	bool* m_final_packet;
	bool	 m_old_packet;
	float	 m_lerp;
	float    m_latency;
	int      m_latency_ticks;
	int      m_server_tick;
	int      m_arrival_tick;
	int      m_goal_shift;
	int      m_width, m_height;
	bool	 m_in_glow;
	bool	 m_update_night;
	bool	 m_update_sound;
	char     clantag_lable[25];
	int		 m_fakelag_jitter_value;

	// usercommand variables.
	c_user_cmd* m_cmd;
	int	      m_tick;
	int	      m_rate;
	int		  m_shot_command_number;
	int		  m_shot_tickbase;
	int	      m_buttons;
	int       m_old_buttons;
	ang_t     m_view_angles;
	ang_t	  m_strafe_angles;
	vec3_t	  m_forward_dir;

	penetration::PenetrationOutput_t m_pen_data;

	std::deque< c_sequence > m_sequences;
	std::deque< c_net_pos >   m_net_pos;

	// animation variables.
	ang_t            m_angle;
	ang_t            m_rotation;
	ang_t            m_radar;
	float            m_speed;
	float			 m_body;
	float			 m_body_pred;
	float            m_anim_time;
	float            m_anim_frame;
	bool             m_animate;
	bool             m_update;
	bool             m_ground;
	bool             m_lagcomp;
	ang_t            m_real_abs_ang;

	float            m_real_poses[24];
	float            m_fake_poses[24];
	float            m_backup_poses[24];
	float            m_fake_abs;



	// other variables.
	c_animation_state* m_fake_state;
	c_animation_state* m_fake_state_allocated;
	ulong_t                  m_ent_handle;
	float                    m_spawn_time;
	//c_bone_array                m_real_matrix[128];
	//c_bone_array                m_fake_matrix[128];
	std::vector<std::string> m_hitsounds;

	// hack username.
	std::string m_user;
};

extern c_ctx ctx;