#pragma once

#pragma warning( disable : 4307 ) // '*': integral constant overflow
#pragma warning( disable : 4244 ) // possible loss of data
#pragma warning( disable : 4800 ) // forcing value to bool 'true' or 'false'
#pragma warning( disable : 4838 ) // conversion from '::size_t' to 'int' requires a narrowing conversion

// You can define _SILENCE_CXX17_OLD_ALLOCATOR_MEMBERS_DEPRECATION_WARNING or _SILENCE_ALL_CXX17_DEPRECATION_WARNINGS to acknowledge that you have received this warning.
#define _SILENCE_CXX17_OLD_ALLOCATOR_MEMBERS_DEPRECATION_WARNING
#define _SILENCE_ALL_CXX17_DEPRECATION_WARNINGS

#define VC_EXTRALEAN
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX

using ulong_t = unsigned long;

#include <Windows.h>
#include <cstdint>
#include <intrin.h>
#include <xmmintrin.h>
#include <array>
#include <vector>
#include <algorithm>
#include <cctype>
#include <string>
#include <chrono>
#include <thread>
#include <memory>
#include <sstream>
#include <unordered_map>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <deque>
#include <functional>
#include <map>
#include <shlobj.h>
#include <filesystem>
#include <streambuf>

#include <d3d9.h>
#pragma comment(lib, "d3d9.lib")
#include <d3dx9.h>
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "Urlmon.lib")

//imgui
#include "raigeki_gui/imgui/imgui.h"
#include "raigeki_gui/fonts/droid_sans.cpp"
#include "raigeki_gui/fonts/droid_sans_bold.cpp"
#include "raigeki_gui/fonts/agency_bold.cpp"
#include "raigeki_gui/fonts/SegoeUI.cpp"
#include "raigeki_gui/images/logo.c"
#include "raigeki_gui/images/background.c"
#include "raigeki_gui/imgui/imgui.h"
#include "raigeki_gui/imgui/dx9/imgui_impl_dx9.h"

//framework include
#include "framework/util/unique_vector.hpp"
#include "framework/util/contrib/tinyformat.hpp"
#include "framework/util/hash.hpp"
#include "framework/util/xorstr.hpp"
#include "framework/util/pe.hpp"
#include "framework/util/winapir.hpp"
#include "framework/util/address.hpp"
#include "framework/util/util.hpp"
#include "framework/util/module.hpp"
#include "framework/util/pattern.hpp"
#include "framework/util/vmt.hpp"
#include "framework/util/stack.hpp"
#include "framework/util/nt.hpp"
#include "framework/util/x86.hpp"
#include "framework/util/syscall.hpp"
#include "framework/util/contrib/json.h"
#include "framework/util/contrib/base64.hpp"


//kernel include
#include "context/interfaces.hpp"
#include "valve/sdk.hpp"
#include "context/cstrike.hpp"
#include "features/c_penetrate_walls.hpp"
#include "framework/entity/netvars.hpp"
#include "framework/entity/offsets.hpp"
#include "valve/source_engine/entity.hpp"
#include "context/context.hpp"
#include "valve/source_engine/game_rules.hpp"
#include "kernel/hook_handler.hpp"
#include "framework/render/renderer.hpp"

//features include
#include "features/c_prediction_system.hpp"
#include "features/c_lag_record.hpp"
#include "features/c_dormant_esp.hpp"
#include "features/c_visuals.hpp"
#include "features/c_movement.hpp"
#include "features/c_animation_sync.hpp"
#include "features/c_antiaim_system.hpp"
#include "features/c_aim_player.hpp"
#include "features/c_lag_compensation.hpp"
#include "features/c_aimbot_system.hpp"
#include "features/c_network_data.hpp"
#include "features/c_chams_system.hpp"
#include "features/c_notify.hpp"
#include "features/c_aim_resolver.hpp"
#include "features/c_grenade_simulation.hpp"
#include "features/c_skinchanger.hpp"
#include "features/c_events.hpp"
#include "features/c_shots.hpp"
#include "features/c_game_movement.hpp"

// gui includes.
#include "raigeki_gui/helpers/InputHelper.h"
#include "raigeki_gui/inputsystem.h"
#include "raigeki_gui/config.h"

//#include "Renderer.h"
#include "raigeki_gui/ui.hpp"
#include "raigeki_gui/wrapper.h"
#include "raigeki_gui/helpers/Easing.h"