#include "../project.hpp"

c_network_data netdata{};;

void c_network_data::store() {
    int            tickbase;
    stored_data_t* data;

    if (!ctx.m_processing) {
        reset();
        return;
    }

    tickbase = ctx.m_local->m_nTickBase();

    // get current record and store data.
    data = &m_data[tickbase % MULTIPLAYER_BACKUP];

    data->m_tickbase = tickbase;
    data->m_punch = ctx.m_local->m_aimPunchAngle();
    data->m_punch_vel = ctx.m_local->m_aimPunchAngleVel();
    data->m_view_offset = ctx.m_local->m_vecViewOffset();
}

void c_network_data::apply() {
    int            tickbase;
    stored_data_t* data;
    ang_t          punch_delta, punch_vel_delta;
    vec3_t         view_delta;

    if (!ctx.m_processing) {
        reset();
        return;
    }

    tickbase = ctx.m_local->m_nTickBase();

    // get current record and validate.
    data = &m_data[tickbase % MULTIPLAYER_BACKUP];

    if (ctx.m_local->m_nTickBase() != data->m_tickbase)
        return;

    // get deltas.
    // note - dex;  before, when you stop shooting, punch values would sit around 0.03125 and then goto 0 next update.
    //              with this fix applied, values slowly decay under 0.03125.
    punch_delta = ctx.m_local->m_aimPunchAngle() - data->m_punch;
    punch_vel_delta = ctx.m_local->m_aimPunchAngleVel() - data->m_punch_vel;
    view_delta = ctx.m_local->m_vecViewOffset() - data->m_view_offset;

    // set data.
    if (std::abs(punch_delta.x) < 0.03125f &&
        std::abs(punch_delta.y) < 0.03125f &&
        std::abs(punch_delta.z) < 0.03125f)
        ctx.m_local->m_aimPunchAngle() = data->m_punch;

    if (std::abs(punch_vel_delta.x) < 0.03125f &&
        std::abs(punch_vel_delta.y) < 0.03125f &&
        std::abs(punch_vel_delta.z) < 0.03125f)
        ctx.m_local->m_aimPunchAngleVel() = data->m_punch_vel;

    if (std::abs(view_delta.x) < 0.03125f &&
        std::abs(view_delta.y) < 0.03125f &&
        std::abs(view_delta.z) < 0.03125f)
        ctx.m_local->m_vecViewOffset() = data->m_view_offset;
}

void c_network_data::reset() {
    m_data.fill(stored_data_t());
}