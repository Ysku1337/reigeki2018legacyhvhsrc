#include "../project.hpp"



c_aim_resolver resolver{};;

c_lag_record* c_aim_resolver::find_ideal_record(c_aim_player* data) {
	c_lag_record* first_valid, * current;

	if (data->m_records.empty())
		return nullptr;

	first_valid = nullptr;

	// iterate records.
	for (const auto& it : data->m_records) {
		if (it->dormant() || it->immune() || !it->valid())
			continue;

		// get current record.
		current = it.get();

		// first record that was valid, store it for later.
		if (!first_valid)
			first_valid = current;

		// try to find a record with a shot, lby update, walking or no anti-aim.
		if (it->m_shot || it->m_mode == resolver_mode::lby_yaw_mode || it->m_mode == resolver_mode::walking_mode || it->m_mode == resolver_mode::none)
			return current;
	}

	// none found above, return the first valid record if possible.
	return (first_valid) ? first_valid : nullptr;
}

c_lag_record* c_aim_resolver::find_last_record(c_aim_player* data) {
	c_lag_record* current;

	if (data->m_records.empty())
		return nullptr;

	// iterate records in reverse.
	for (auto it = data->m_records.crbegin(); it != data->m_records.crend(); ++it) {
		current = it->get();

		// if this record is valid.
		// we are done since we iterated in reverse.
		if (current->valid() && !current->immune() && !current->dormant())
			return current;
	}

	return nullptr;
}

void c_aim_resolver::on_body_update(c_base_player* player, float value) {
	c_aim_player* data = &aimbot.m_players[player->index() - 1];

	// set data.
	data->m_old_body = data->m_body;
	data->m_body = value;
}

float c_aim_resolver::get_away_angle(c_lag_record* record) {
	float  delta{ std::numeric_limits< float >::max() };
	vec3_t pos;
	ang_t  away;

	if (ctx.m_net_pos.empty()) {
		math::vector_angles(ctx.m_local->m_vecOrigin() - record->m_pred_origin, away);
		return away.y;
	}

	float owd = (ctx.m_latency / 2.f);

	float target = record->m_pred_time;

	// iterate all.
	for (const auto& net : ctx.m_net_pos) {
		float dt = std::abs(target - net.m_time);

		// the best origin.
		if (dt < delta) {
			delta = dt;
			pos = net.m_pos;
		}
	}

	math::vector_angles(pos - record->m_pred_origin, away);
	return away.y;
}

void c_aim_resolver::match_shot(c_aim_player* data, c_lag_record* record) {
	// do not attempt to do this in nospread mode.
		// do not attempt to do this in nospread mode.
	//if (g_menu.main.config.mode.get() == 1)
	//	return;

	float shoot_time = -1.f;

	weapon_t* weapon = data->m_player->get_active_weapon();
	if (weapon) {
		// with logging this time was always one tick behind.
		// so add one tick to the last shoot time.
		shoot_time = weapon->m_fLastShotTime() + cstrike.m_globals->m_interval;
	}

	// this record has a shot on it.
	if (game::time_to_ticks(shoot_time) == game::time_to_ticks(record->m_sim_time)) {
		if (record->m_lag <= 2)
			record->m_shot = true;

		// more then 1 choke, cant hit pitch, apply prev pitch.
		else if (data->m_records.size() >= 2) {
			c_lag_record* previous = data->m_records[1].get();

			if (previous && !previous->dormant())
				record->m_eye_angles.x = previous->m_eye_angles.x;
		}
	}
}

void c_aim_resolver::anti_freestand(c_lag_record* record) {
	//// constants
	//constexpr float STEP{ 4.f };
	//constexpr float RANGE{ 32.f };

	//// best target.
	//vec3_t enemypos = record->m_player->get_shoot_position();
	//float away = get_away_angle(record);

	//// construct vector of angles to test.
	//std::vector< c_adaptive_angle > angles{ };
	//angles.emplace_back(away - 180.f);
	//angles.emplace_back(away + 90.f);
	//angles.emplace_back(away - 90.f);

	//// start the trace at the your shoot pos.
	//vec3_t start = ctx.m_local->get_shoot_position();

	//// see if we got any valid result.
	//// if this is false the path was not obstructed with anything.
	//bool valid{ false };

	//// iterate vector of angles.
	//for (auto it = angles.begin(); it != angles.end(); ++it) {

	//	// compute the 'rough' estimation of where our head will be.
	//	vec3_t end{ enemypos.x + std::cos(math::deg_to_rad(it->m_yaw)) * RANGE,
	//		enemypos.y + std::sin(math::deg_to_rad(it->m_yaw)) * RANGE,
	//		enemypos.z };

	//	// draw a line for debugging purposes.
	//	// g_csgo.m_debug_overlay->AddLineOverlay( start, end, 255, 0, 0, true, 0.1f );

	//	// compute the direction.
	//	vec3_t dir = end - start;
	//	float len = dir.normalize();

	//	// should never happen.
	//	if (len <= 0.f)
	//		continue;

	//	// step thru the total distance, 4 units per step.
	//	for (float i{ 0.f }; i < len; i += STEP) {
	//		// get the current step position.
	//		vec3_t point = start + (dir * i);

	//		// get the contents at this point.
	//		int contents = cstrike.m_engine_trace->get_point_contents(point, MASK_SHOT_HULL);

	//		// contains nothing that can stop a bullet.
	//		if (!(contents & MASK_SHOT_HULL))
	//			continue;

	//		float mult = 1.f;

	//		// over 50% of the total length, prioritize this shit.
	//		if (i > (len * 0.5f))
	//			mult = 1.25f;

	//		// over 90% of the total length, prioritize this shit.
	//		if (i > (len * 0.75f))
	//			mult = 1.25f;

	//		// over 90% of the total length, prioritize this shit.
	//		if (i > (len * 0.9f))
	//			mult = 2.f;

	//		// append 'penetrated distance'.
	//		it->m_dist += (STEP * mult);

	//		// mark that we found anything.
	//		valid = true;
	//	}
	//}

	//if (!valid) {
	//	return;
	//}

	//// put the most distance at the front of the container.
	//std::sort(angles.begin(), angles.end(),
	//	[](const c_adaptive_angle& a, const c_adaptive_angle& b) {
	//		return a.m_dist > b.m_dist;
	//	});

	//// the best angle should be at the front now.
	//c_adaptive_angle* best = &angles.front();

	//record->m_eye_angles.y = best->m_yaw;
}

void c_aim_resolver::set_mode(c_lag_record* record) {
	// the resolver has 3 modes to chose from.
	// these modes will vary more under the hood depending on what data we have about the player
	// and what kind of hack vs. hack we are playing (mm/nospread).

	float speed = record->m_velocity.length_2d();

	// if on ground, moving, and not fakewalking.
	if ((record->m_flags & FL_ONGROUND) && speed > 0.1f && !record->m_fake_walk)
		record->m_mode = resolver_mode::walking_mode;

	// if on ground, not moving or fakewalking.
	else if ((record->m_flags & FL_ONGROUND) && (speed <= 0.1f || record->m_fake_walk))
		record->m_mode = resolver_mode::lastmove_mode;

	// if not on ground.
	else if (!(record->m_flags & FL_ONGROUND))
		record->m_mode = resolver_mode::in_air_mode;
}

void c_aim_resolver::resolve_angles(c_base_player* player, c_lag_record* record) {
	c_aim_player* data = &aimbot.m_players[player->index() - 1];
	c_lag_record* move = &data->m_walk_record;

	float delta = record->m_anim_time - move->m_anim_time;

	c_animation_layer* curr = &record->m_layers[3];
	const int activity = data->m_player->get_sequence_activity(curr->m_sequence);

	// mark this record if it contains a shot.
	match_shot(data, record);

	// next up mark this record with a resolver mode that will be used.
	set_mode(record);

	// if we are in nospread mode, force all players pitches to down.
	// TODO; we should check thei actual pitch and up too, since those are the other 2 possible angles.
	// this should be somehow combined into some iteration that matches with the air angle iteration.

//	if (g_menu.main.config.mode.get() == 1)
	//	record->m_eye_angles.x = 90.f;

	// we arrived here we can do the acutal resolve.
	if (record->m_mode == resolver_mode::walking_mode)
		resolve_walk(data, record);

	else if (record->m_mode == resolver_mode::lastmove_mode || record->m_mode == resolver_mode::unknown_mode)
		init_resolver(record, data, player);

	else if (record->m_mode == resolver_mode::in_air_mode)
		resolve_air(data, record, player);

	else if (activity == 979 && curr->m_weight == 0 && delta > .22f)
		anti_freestand(record);

	// normalize the eye angles, doesn't really matter but its clean.
	math::normalize_angle(record->m_eye_angles.y);
}


void c_aim_resolver::resolve_walk(c_aim_player* data, c_lag_record* record) {
	// apply lby to eyeangles.
	record->m_eye_angles.y = record->m_body;

	// delay body update.
	data->m_body_update = record->m_anim_time + 0.22f; // was 0.22

	// reset stand and body index.
	data->m_stand_index = 0;
	data->m_bruteforce_index = 0;
	data->m_lby_yaw_index = 0;
	data->m_last_move_index = 0;
	data->m_unknown_move = 0;

	// copy the last record that this player was walking
	// we need it later on because it gives us crucial data.
	std::memcpy(&data->m_walk_record, record, sizeof(c_lag_record));
}

float c_aim_resolver::get_lby_rotate(float lby, float yaw)
{
	float delta = math::normalized_angle(yaw - lby);
	if (fabs(delta) < 25.f)
		return lby;

	if (delta > 0.f)
		return yaw + 25.f;

	return yaw;
}

bool c_aim_resolver::detect_sideways(c_base_player* entity, float yaw)
{
	auto local_player = ctx.m_local;
	if (!local_player)
		return false;

	const auto at_target_yaw = math::calc_angle(local_player->m_vecOrigin(), entity->m_vecOrigin()).y;
	const float delta = fabs(math::normalized_angle(at_target_yaw - yaw));

	return delta > 20.f && delta < 160.f;
}

float c_aim_resolver::get_direction_angle(int index, c_base_player* player) {
	const auto left_thickness = ctx.m_left_thickness[index];
	const auto right_thickness = ctx.m_right_thickness[index];
	const auto at_target_angle = ctx.m_at_target_angle[index];

	auto angle = 0.f;

	if ((left_thickness >= 350 && right_thickness >= 350) || (left_thickness <= 50 && right_thickness <= 50) || (std::fabs(left_thickness - right_thickness) <= 7)) {
		angle = math::normalize_float(at_target_angle + 180.f);
	}
	else {
		if (left_thickness > right_thickness) {
			angle = math::normalize_float(at_target_angle - 90.f);
		}
		else if (left_thickness == right_thickness) {
			angle = math::normalize_float(at_target_angle + 180.f);
		}
		else {
			angle = math::normalize_float(at_target_angle + 90.f);
		}
	}
	return angle;

}

bool check_sequence(c_base_player* player, int sequence, bool checklayers = false, int layerstocheck = 15)
{

	if (!player || !player->alive())
		return false;

	for (int i = 0; i < checklayers ? layerstocheck : 15; i++)
	{
		auto layer = player->m_AnimOverlay()[i];

		if (player->get_sequence_activity(layer.m_sequence) == sequence)
			return true;
	}

	return false;
}

bool check_lower_body_yaw(c_base_player* player, c_lag_record* record, c_lag_record* prev_record)
{
	if (player->m_vecVelocity().length_2d() > 1.1f)
		return false;

	bool choking = fabs(player->m_flSimulationTime() - player->m_flOldSimulationTime()) > cstrike.m_globals->m_interval;

	for (int i = 0; i < 13; i++)
	{
		auto layer = record->m_layers[i];
		auto prev_layer = prev_record->m_layers[i];


		if (layer.m_cycle != prev_layer.m_cycle)
		{
			if (layer.m_cycle > 0.9 || layer.m_weight == 1.f)
			{
				if (i == 3)
					return true;


				if (choking && fabs(math::normalized_angle(record->m_body - prev_record->m_body)) > 5.f)
					return true;
			}
			else if (choking)
			{
				if (player->get_sequence_activity(layer.m_sequence) == 979)
				{
					if (player->get_sequence_activity(prev_layer.m_sequence) == 979)
					{
						return true;
					}
				}
			}
		}
	}
}

bool can_last_moving(c_lag_record* move_record, c_aim_player* data, c_base_player* player)
{
	if (player->is_dormant() || !player->alive())
		return false; // sanity check

	if (!move_record->valid() || move_record->dormant())
		return false;

	if (move_record->m_sim_time <= 0.f)

		return data->m_moved && data->m_last_move < 1;
}

void c_aim_resolver::resolve_by_bruteforce(c_lag_record* record, c_base_player* player, c_aim_player* data)
{
	auto local_player = ctx.m_local;
	if (!local_player)
		return;

	record->m_mode = resolver_mode::standing_mode;

	const float at_target_yaw = math::calc_angle(player->m_vecOrigin(), local_player->m_vecOrigin()).y;

	switch (data->m_stand_index % 3)
	{
	case 0:
		record->m_eye_angles.y = get_lby_rotate(player->m_flLowerBodyYawTarget(), at_target_yaw + 60.f);
		break;
	case 1:
		record->m_eye_angles.y = at_target_yaw + 140.f;
		break;
	case 2:
		record->m_eye_angles.y = at_target_yaw - 75.f;
		break;
	}
}

void c_aim_resolver::init_resolver(c_lag_record* record, c_aim_player* data, c_base_player* player)
{
	// for no-spread call a seperate resolver.

//	if (g_menu.main.config.mode.get() == 1) {
	//	apply_stand_nospread(data, record);
	//	return;
	//}

	// pointer for easy access.
	c_lag_record* move = &data->m_walk_record;

	// get predicted away angle for the player.
	float away = get_away_angle(record);

	c_animation_layer* curr = &record->m_layers[3];
	int act = data->m_player->get_sequence_activity(curr->m_sequence);

	float diff = math::normalized_angle(record->m_body - move->m_body);
	float delta = record->m_anim_time - move->m_anim_time;

	ang_t vAngle = ang_t(0, 0, 0);
	math::calculate_angle(player->m_vecOrigin(), ctx.m_local->m_vecOrigin(), vAngle);

	float flToMe = vAngle.y;

	const float at_target_yaw = math::calc_angle(ctx.m_local->m_vecOrigin(), player->m_vecOrigin()).y;

	/*for (int i = 1; i <= 32; i++)
	{
		Player* pEnemy = g_csgo.m_entlist->GetClientEntity< Player* >(i);
		const auto freestanding_record = player_resolve_records[i].m_sAntiEdge;

		AntiFreestand(player, record->m_eye_angles.y, freestanding_record.left_damage, freestanding_record.right_damage, freestanding_record.right_fraction, freestanding_record.left_fraction, flToMe, data->m_last_move);
	}*/

	const auto freestanding_record = player_resolve_records[player->index()].m_anti_edge;

	// we have a valid moving record.
	if (move->m_sim_time > 0.f) {
		vec3_t delta = move->m_origin - record->m_origin;

		// check if moving record is close.
		if (delta.length() <= 128.f) {
			// indicate that we are using the moving lby.
			data->m_moved = true;
		}
	}

	if (!data->m_moved) {

		record->m_mode = resolver_mode::unknown_mode;

		//record->m_eye_angles.y = GetDirectionAngle(player->index(), player);

		resolve_by_bruteforce(record, player, data);

		/*
			const auto left_thickness = g_cl.m_left_thickness[index];
			const auto right_thickness = g_cl.m_right_thickness[index];
			const auto at_target_angle = g_cl.m_at_target_angle[index];
		*/

		//AntiFreestand(player, record->m_eye_angles.y, freestanding_record.left_damage, freestanding_record.right_damage, freestanding_record.right_fraction, freestanding_record.left_fraction, at_target_yaw, data->m_last_move);

		if (data->m_body != data->m_old_body)
		{
			record->m_eye_angles.y = record->m_body;

			data->m_body_update = record->m_anim_time + 1.1f;

			m_players[record->m_player->index()] = false;
			record->m_mode = resolver_mode::lby_yaw_mode;
		}
	}
	else if (data->m_moved) {
		float diff = math::normalized_angle(record->m_body - move->m_body);
		float delta = record->m_anim_time - move->m_anim_time;

		record->m_mode = resolver_mode::lastmove_mode;
		//data->m_last_move

		const float at_target_yaw = math::calc_angle(ctx.m_local->m_vecOrigin(), player->m_vecOrigin()).y;


		//if (IsYawSideways(player, move->m_body)) // anti-urine
		record->m_eye_angles.y = move->m_body;
		//else
		//	record->m_eye_angles.y = away + 180.f;

		//record->m_eye_angles.y = GetLBYRotatedYaw(player->m_flLowerBodyYawTarget(), move->m_body);

		if (data->m_last_move >= 1)
			resolve_by_bruteforce(record, player, data);

		//record->m_eye_angles.y = GetDirectionAngle(player->index(), player);

		if (data->m_body != data->m_old_body)
		{
			/*auto lby = math::normalize_float(record->m_body);
			if (fabsf(record->m_eye_angles.y - lby) <= 150.f && fabsf(record->m_eye_angles.y - lby) >= 35.f) {
				record->m_eye_angles.y ? lby -= 25.f : lby += 25.f;
			}
			record->m_eye_angles.y = lby;
			player->SetAbsAngles(ang_t(0.f, lby, 0.f));*/

			record->m_eye_angles.y = record->m_body;

			data->m_body_update = record->m_anim_time + 1.1f;
			m_players[record->m_player->index()] = false;
			record->m_mode = resolver_mode::lby_yaw_mode;
		}
		/*else
		{
			// LBY SHOULD HAVE UPDATED HERE.
			if (record->m_anim_time >= data->m_body_update) {
				// only shoot the LBY flick 3 times.
				// if we happen to miss then we most likely mispredicted
				if (data->m_body_index < 1) {
					// set angles to current LBY.
					record->m_eye_angles.y = record->m_body;

					data->m_body_update = record->m_anim_time + 1.1f;

					// set the resolve mode.
					iPlayers[record->m_player->index()] = false;
					record->m_mode = Modes::RESOLVE_BODY;
				}
			}
		}*/
		//if (data->m_last_move > 1)
			//AntiFreestand(player, record->m_eye_angles.y, freestanding_record.left_damage, freestanding_record.right_damage, freestanding_record.right_fraction, freestanding_record.left_fraction, flToMe, data->m_last_move);
	}
}


//void c_aim_resolver::resolve_stand( c_aim_player* data, c_lag_record* record ) {
//	data->m_moved = false;
//
//	// for no-spread call a seperate resolver.
//	if (g_menu.main.config.mode.get() == 1) {
//		apply_stand_nospread(data, record);
//		return;
//	}
//
//	// get predicted away angle for the player.
//	float away = get_away_angle(record);
//
//	// pointer for easy access.
//	c_lag_record* move = &data->m_walk_record;
//
//	c_animation_layer* curr = &record->m_layers[3];
//	int act = data->m_player->get_sequence_activity(curr->m_sequence);
//
//
//	// we have a valid moving record.
//	if (move->m_sim_time > 0.f && !move->dormant() && !record->dormant() && data->m_last_move < 1 && data->m_missed_shots < 1) {
//		vec3_t delta = move->m_origin - record->m_origin;
//
//		// check if moving record is close.
//		if (delta.length() <= 100.f) {
//			// indicate that we are using the moving lby.
//			data->m_moved = true;
//		}
//	}
//
//	bool breaking = check_lower_body_yaw(data->m_player, record, find_last_record(data));
//	// a valid moving context was found
//	if (data->m_moved) {
//		float diff = math::normalized_angle(record->m_body - move->m_body);
//		float delta = record->m_anim_time - move->m_anim_time;
//
//		// it has not been time for this first update yet.
//		if (data->m_records.size() >= 2)
//		{
//			c_lag_record* previous = data->m_records[1].get();
//
//			if (previous)
//			{
//				if (record->m_body != previous->m_body && data->m_lby_yaw_index < 1)
//				{
//					record->m_eye_angles.y = record->m_body;
//					data->m_body_update = record->m_anim_time + 1.1f;
//					m_players[record->m_player->index()] = false;
//					record->m_mode = resolver_mode::lby_yaw_mode;
//				}
//			}
//		}
//		// LBY SHOULD HAVE UPDATED HERE.
//		else if (record->m_anim_time >= data->m_body_update) {
//			// only shoot the LBY flick 3 times.
//			// if we happen to miss then we most likely mispredicted.
//			if (data->m_records.size() >= 2)
//			{
//				c_lag_record* previous = data->m_records[1].get();
//
//				if (previous)
//				{
//					if (record->m_body != previous->m_body && data->m_lby_yaw_index < 1)
//					{
//						record->m_eye_angles.y = record->m_body;
//						data->m_body_update = record->m_anim_time + 1.1f;
//						m_players[record->m_player->index()] = false;
//						record->m_mode = resolver_mode::lby_yaw_mode;
//					}
//				}
//			}
//
//			// set to stand1 -> known last move.
//			record->m_mode = resolver_mode::stopped_moving_mode;
//
//			// ok, no fucking update. apply big resolver.
//			record->m_eye_angles.y = move->m_body;
//
//			if (!breaking && !(data->m_stand_index % 4))
//				record->m_eye_angles.y = record->m_body;
//
//			// every third shot do some fuckery.
//			if (!(data->m_stand_index % 3))
//				record->m_eye_angles.y += record->m_body + 90.f;
//
//			// jesus we can fucking stop missing can we?
//			if (data->m_stand_index > 6 && act != 980) {
//				// lets just hope they switched ang after move.
//				record->m_eye_angles.y = move->m_body + 180.f;
//			}
//
//			// we missed 4 shots.
//			else if (data->m_stand_index > 4 && act != 980) {
//				// try backwards.
//				record->m_eye_angles.y = away + 180.f;
//			}
//
//			return;
//		}
//	}
//
//	// stand2 -> no known last move.
//	record->m_mode = resolver_mode::bruteforce_mode;
//
//	if (breaking)
//	{
//		switch (data->m_bruteforce_index % 6) {
//
//		case 0:
//			record->m_eye_angles.y = move->m_body;
//			break;
//
//		case 1:
//			record->m_eye_angles.y = record->m_body + 115.f;
//			break;
//
//		case 2:
//			record->m_eye_angles.y = record->m_body - 115.f;
//			break;
//
//		case 3:
//			record->m_eye_angles.y = record->m_body + 180.f;
//			break;
//
//		case 4:
//			record->m_eye_angles.y = record->m_body;
//			break;
//
//		case 5:
//			record->m_eye_angles.y = away + 180.f;
//			break;
//
//		default:
//			break;
//		}
//	}
//	else // we should be able to hit LBY, since they arent breaking it
//	{
//		record->m_eye_angles.y = data->m_player->m_flLowerBodyYawTarget();
//		record->m_mode = resolver_mode::lby_yaw_mode;
//	}
//}

void c_aim_resolver::apply_stand_nospread(c_aim_player* data, c_lag_record* record) {
	// get away angles.
	float away = get_away_angle(record);

	switch (data->m_shots % 8) {
	case 0:
		record->m_eye_angles.y = away + 180.f;
		break;

	case 1:
		record->m_eye_angles.y = away + 90.f;
		break;
	case 2:
		record->m_eye_angles.y = away - 90.f;
		break;

	case 3:
		record->m_eye_angles.y = away + 45.f;
		break;
	case 4:
		record->m_eye_angles.y = away - 45.f;
		break;

	case 5:
		record->m_eye_angles.y = away + 135.f;
		break;
	case 6:
		record->m_eye_angles.y = away - 135.f;
		break;

	case 7:
		record->m_eye_angles.y = away + 0.f;
		break;

	default:
		break;
	}

	// force LBY to not fuck any pose and do a true bruteforce.
	record->m_body = record->m_eye_angles.y;
}

void c_aim_resolver::resolve_air(c_aim_player* data, c_lag_record* record, c_base_player* player) {
	// for no-spread call a seperate resolver.

//	if (g_menu.main.config.mode.get() == 1) {
//		apply_air_nospread(data, record);
//		return;
//	}

	// else run our matchmaking air resolver.

	// we have barely any speed. 
	// either we jumped in place or we just left the ground.
	// or someone is trying to fool our resolver.
	if (record->m_velocity.length_2d() < 60.f) {
		// set this for completion.
		// so the shot parsing wont pick the hits / misses up.
		// and process them wrongly.
		record->m_mode = resolver_mode::lastmove_mode;

		// invoke our resolver.
		init_resolver(record, data, player);

		// we are done.
		return;
	}

	// try to predict the direction of the player based on his velocity direction.
	// this should be a rough estimation of where he is looking.
	float velyaw = math::rad_to_deg(std::atan2(record->m_velocity.y, record->m_velocity.x));

	switch (data->m_shots % 3) {
	case 0:
		record->m_eye_angles.y = velyaw + 180.f;
		break;

	case 1:
		record->m_eye_angles.y = velyaw - 95.f;
		break;

	case 2:
		record->m_eye_angles.y = velyaw + 95.f;
		break;
	}
}

void c_aim_resolver::apply_air_nospread(c_aim_player* data, c_lag_record* record) {
	// get away angles.
	float away = get_away_angle(record);

	switch (data->m_shots % 9) {
	case 0:
		record->m_eye_angles.y = away + 180.f;
		break;

	case 1:
		record->m_eye_angles.y = away + 150.f;
		break;
	case 2:
		record->m_eye_angles.y = away - 150.f;
		break;

	case 3:
		record->m_eye_angles.y = away + 165.f;
		break;
	case 4:
		record->m_eye_angles.y = away - 165.f;
		break;

	case 5:
		record->m_eye_angles.y = away + 135.f;
		break;
	case 6:
		record->m_eye_angles.y = away - 135.f;
		break;

	case 7:
		record->m_eye_angles.y = away + 90.f;
		break;
	case 8:
		record->m_eye_angles.y = away - 90.f;
		break;

	default:
		break;
	}
}

void c_aim_resolver::resolve_poses(c_base_player* player, c_lag_record* record) {
	c_aim_player* data = &aimbot.m_players[player->index() - 1];

	// only do this bs when in air.
	if (record->m_mode == resolver_mode::in_air_mode) {
		// ang = pose min + pose val x ( pose range )

		// lean_yaw
		player->m_flPoseParameter()[2] = cstrike.RandomInt(0, 4) * 0.25f;

		// body_yaw
		player->m_flPoseParameter()[11] = cstrike.RandomInt(1, 3) * 0.25f;
	}
}