#pragma once

class c_prediction_system {
public:
	float m_curtime;
	float m_frametime;
	int m_predicted_flags;

public:
	void update();
	void run();
	void restore();
};

extern c_prediction_system engine_predict;