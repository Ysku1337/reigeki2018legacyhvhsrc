//#include "../project.hpp"
//
//c_antiaim_system antiaim{ };;
//
//void c_antiaim_system::ideal_pitch() {
//	c_animation_state* state = ctx.m_local->m_PlayerAnimState();
//	if (!state)
//		return;
//
//	ctx.m_cmd->m_view_angles.x = state->m_min_pitch;
//}
//
//void c_antiaim_system::init_pitch() {
//	bool safe = g_menu.main.config.mode.get() == 0;
//
//	switch (m_pitch) {
//	case 1:
//		// down.
//		ctx.m_cmd->m_view_angles.x = safe ? 89.f : 720.f;
//		break;
//
//	case 2:
//		// up.
//		ctx.m_cmd->m_view_angles.x = safe ? -89.f : -720.f;
//		break;
//
//	case 3:
//		// random.
//		ctx.m_cmd->m_view_angles.x = cstrike.RandomFloat(safe ? -89.f : -720.f, safe ? 89.f : 720.f);
//		break;
//
//	case 4:
//		// ideal.
//		ideal_pitch();
//		break;
//
//	default:
//		break;
//	}
//}
//
//void c_antiaim_system::run_auto_direction() {
//	// constants.
//	static constexpr float STEP{ 4.f };
//	static constexpr float RANGE{ 32.f };
//
//	if (!ctx.m_local)
//		return;
//
//	auto_target_t target = auto_target_t{ 180.f - 1.f, nullptr };
//
//	// iterate players.
//	for (int i{ 0 }; i <= cstrike.m_globals->m_max_clients; ++i) {
//		c_base_player* player = cstrike.m_entlist->get_client_entity< c_base_player* >(i);
//
//		// validate player.
//		if (!aimbot.is_valid_target(player))
//			continue;
//
//		// skip dormant players.
//		if (player->is_dormant())
//			continue;
//
//		// get best target based on fov.
//		float fov = math::get_fov(ctx.m_view_angles, ctx.m_shoot_pos, player->world_space_center());
//
//		if (fov < target.fov) {
//			target.fov = fov;
//			target.player = player;
//		}
//	}
//
//	if (!target.player) {
//		// we have a timeout.
//		/*if (m_auto_last > 0.f && m_auto_time > 2.5f && csgo.m_globals()->curtime < (m_auto_last + 2.5f))
//			return;*/
//
//			// set angle to backwards.
//		m_auto = math::normalized_angle(m_view - 180.f);
//		m_auto_dist = -1.f;
//		return;
//	}
//
//	// construct vector of angles to test.
//	std::vector<c_adaptive_angle> angles = {};
//	angles.emplace_back(m_view - 180.f);
//	angles.emplace_back(m_view + 90.f);
//	angles.emplace_back(m_view - 90.f);
//
//	// see if we got any valid result.
//	// if this is false the path was not obstructed with anything.
//	bool valid = false;
//
//	const auto start = target.player->get_shoot_position();
//
//	// iterate vector of angles.
//	for (auto i = 0; i < (int)angles.size(); ++i) {
//
//		auto it = &angles.at(i);
//
//		// compute the 'rough' estimation of where our head will be.
//		vec3_t end{ ctx.m_shoot_pos.x + std::cos(math::deg_to_rad(it->m_yaw)) * RANGE,
//			ctx.m_shoot_pos.y + std::sin(math::deg_to_rad(it->m_yaw)) * RANGE,
//			ctx.m_shoot_pos.z };	
//
//		// draw a line for debugging purposes.
//		//g_csgo.m_debug_overlay->AddLineOverlay( start, end, 255, 0, 0, true, 0.1f );
//
//		// compute the direction.
//		auto dir = end - start;
//		float len = dir.normalize();
//
//		// should never happen.
//		if (len <= 0.f)
//			continue;
//
//		// step thru the total distance, 4 units per step.
//		for (float i{ 0.f }; i < len; i += STEP) {
//			// get the current step position.
//			const auto point = start + (dir * i);
//
//			// get the contents at this point.
//			const int contents = cstrike.m_engine_trace->get_point_contents(point, MASK_SHOT_HULL);
//
//			// contains nothing that can stop a bullet.
//			if (!(contents & MASK_SHOT_HULL))
//				continue;
//
//			float mult = 1.f;
//
//			// over 50% of the total length, prioritize this shit.
//			if (i > (len * 0.5f))
//				mult = 1.25f;
//
//			// over 90% of the total length, prioritize this shit.
//			if (i > (len * 0.75f))
//				mult = 1.25f;
//
//			// over 90% of the total length, prioritize this shit.
//			if (i > (len * 0.9f))
//				mult = 2.f;
//
//			// append 'penetrated distance'.
//			it->m_dist += (STEP * mult);
//
//			// mark that we found anything.
//			valid = true;
//		}
//	}
//
//	if (!valid || angles.empty()) {
//		// set angle to backwards.
//		m_auto = math::normalized_angle(m_view - 180.f);
//		m_auto_dist = -1.f;
//		return;
//	}
//
//	// put the most distance at the front of the container.
//	std::sort(angles.begin(), angles.end(),
//		[](const c_adaptive_angle& a, const c_adaptive_angle& b) {
//			return a.m_dist > b.m_dist;
//		});
//
//
//	// the best angle should be at the front now.
//	c_adaptive_angle* best = &angles.front();
//
//	// check if we are not doing a useless change.
//	if (best->m_dist != m_auto_dist) {
//		// set yaw to the best result.
//		m_auto = math::normalized_angle(best->m_yaw);
//		m_auto_dist = best->m_dist;
//		m_auto_last = cstrike.m_globals->m_curtime;
//	}
//}
//
//void c_antiaim_system::get_anti_aim_direction() {
//	// edge aa.
//	if (g_menu.main.antiaim.edge.get() && ctx.m_local->m_vecVelocity().length() < 320.f) {
//
//		ang_t ang;
//		if (run_edge_anti_aim(ctx.m_local, ang)) {
//			m_direction = ang.y;
//			return;
//		}
//	}
//
//	// lock while standing..
//	bool lock = g_menu.main.antiaim.dir_lock.get();
//
//	// save view, depending if locked or not.
//	if ((lock && ctx.m_speed > 0.1f) || !lock)
//		m_view = ctx.m_cmd->m_view_angles.y;
//
//	if (m_base_angle > 0) {
//		// 'static'.
//		if (m_base_angle == 1)
//			m_view = 0.f;
//
//		// away options.
//		else {
//			float  best_fov{ std::numeric_limits< float >::max() };
//			float  best_dist{ std::numeric_limits< float >::max() };
//			float  fov, dist;
//			c_base_player* target, * best_target{ nullptr };
//
//			for (int i{ 1 }; i <= cstrike.m_globals->m_max_clients; ++i) {
//				target = cstrike.m_entlist->get_client_entity< c_base_player* >(i);
//
//				if (!aimbot.is_valid_target(target))
//					continue;
//
//				if (target->is_dormant())
//					continue;
//
//				// 'away crosshair'.
//				if (m_base_angle == 2) {
//
//					// check if a player was closer to our crosshair.
//					fov = math::get_fov(ctx.m_view_angles, ctx.m_shoot_pos, target->world_space_center());
//					if (fov < best_fov) {
//						best_fov = fov;
//						best_target = target;
//					}
//				}
//
//				// 'away distance'.
//				else if (m_base_angle == 3) {
//
//					// check if a player was closer to us.
//					dist = (target->m_vecOrigin() - ctx.m_local->m_vecOrigin()).length_sqr();
//					if (dist < best_dist) {
//						best_dist = dist;
//						best_target = target;
//					}
//				}
//			}
//
//			if (best_target) {
//				// todo - dex; calculate only the yaw needed for this (if we're not going to use the x component that is).
//				ang_t angle;
//				math::vector_angles(best_target->m_vecOrigin() - ctx.m_local->m_vecOrigin(), angle);
//				m_view = angle.y;
//			}
//		}
//	}
//
//	// switch direction modes.
//	switch (m_dir) {
//
//		// auto.
//	case 0:
//		run_auto_direction();
//		m_direction = m_auto;
//		break;
//
//		// backwards.
//	case 1:
//		m_direction = m_view + 180.f;
//		break;
//
//		// left.
//	case 2:
//		m_direction = m_view + 90.f;
//		break;
//
//		// right.
//	case 3:
//		m_direction = m_view - 90.f;
//		break;
//
//		// custom.
//	case 4:
//		m_direction = m_view + m_dir_custom;
//		break;
//
//	default:
//		break;
//	}
//
//	// normalize the direction.
//	math::normalize_angle(m_direction);
//}
//
//bool c_antiaim_system::run_edge_anti_aim(c_base_player* player, ang_t& out) {
//	c_game_trace trace;
//	static c_trace_filter_simple_game filter{ };
//
//	if (player->m_MoveType() == MOVETYPE_LADDER)
//		return false;
//
//	// skip this player in our traces.
//	filter.set_pass_entity(player);
//
//	// get player bounds.
//	vec3_t mins = player->m_vecMins();
//	vec3_t maxs = player->m_vecMaxs();
//
//	// make player bounds bigger.
//	mins.x -= 20.f;
//	mins.y -= 20.f;
//	maxs.x += 20.f;
//	maxs.y += 20.f;
//
//	// get player origin.
//	vec3_t start = player->get_abs_origin();
//
//	// offset the view.
//	start.z += 56.f;
//
//	cstrike.m_engine_trace->TraceRay(Ray(start, start, mins, maxs), CONTENTS_SOLID, (i_trace_filter*)&filter, &trace);
//	if (!trace.m_startsolid)
//		return false;
//
//	float  smallest = 1.f;
//	vec3_t plane;
//
//	// trace around us in a circle, in 20 steps (anti-degree conversion).
//	// find the closest object.
//	for (float step{ }; step <= math::pi_2; step += (math::pi / 10.f)) {
//		// extend endpoint x units.
//		vec3_t end = start;
//
//		// set end point based on range and step.
//		end.x += std::cos(step) * 32.f;
//		end.y += std::sin(step) * 32.f;
//
//		cstrike.m_engine_trace->TraceRay(Ray(start, end, { -1.f, -1.f, -8.f }, { 1.f, 1.f, 8.f }), CONTENTS_SOLID, (i_trace_filter*)&filter, &trace);
//
//		// we found an object closer, then the previouly found object.
//		if (trace.m_fraction < smallest) {
//			// save the normal of the object.
//			plane = trace.m_plane.m_normal;
//			smallest = trace.m_fraction;
//		}
//	}
//
//	// no valid object was found.
//	if (smallest == 1.f || plane.z >= 0.1f)
//		return false;
//
//	// invert the normal of this object
//	// this will give us the direction/angle to this object.
//	vec3_t inv = -plane;
//	vec3_t dir = inv;
//	dir.normalize();
//
//	// extend point into object by 24 units.
//	vec3_t point = start;
//	point.x += (dir.x * 24.f);
//	point.y += (dir.y * 24.f);
//
//	// check if we can stick our head into the wall.
//	if (cstrike.m_engine_trace->get_point_contents(point, CONTENTS_SOLID) & CONTENTS_SOLID) {
//		// trace from 72 units till 56 units to see if we are standing behind something.
//		cstrike.m_engine_trace->TraceRay(Ray(point + vec3_t{ 0.f, 0.f, 16.f }, point), CONTENTS_SOLID, (i_trace_filter*)&filter, &trace);
//
//		// we didnt start in a solid, so we started in air.
//		// and we are not in the ground.
//		if (trace.m_fraction < 1.f && !trace.m_startsolid && trace.m_plane.m_normal.z > 0.7f) {
//			// mean we are standing behind a solid object.
//			// set our angle to the inversed normal of this object.
//			out.y = math::rad_to_deg(std::atan2(inv.y, inv.x));
//			return true;
//		}
//	}
//
//	// if we arrived here that mean we could not stick our head into the wall.
//	// we can still see if we can stick our head behind/asides the wall.
//
//	// adjust bounds for traces.
//	mins = { (dir.x * -3.f) - 1.f, (dir.y * -3.f) - 1.f, -1.f };
//	maxs = { (dir.x * 3.f) + 1.f, (dir.y * 3.f) + 1.f, 1.f };
//
//	// move this point 48 units to the left 
//	// relative to our wall/base point.
//	vec3_t left = start;
//	left.x = point.x - (inv.y * 48.f);
//	left.y = point.y - (inv.x * -48.f);
//
//	cstrike.m_engine_trace->TraceRay(Ray(left, point, mins, maxs), CONTENTS_SOLID, (i_trace_filter*)&filter, &trace);
//	float l = trace.m_startsolid ? 0.f : trace.m_fraction;
//
//	// move this point 48 units to the right 
//	// relative to our wall/base point.
//	vec3_t right = start;
//	right.x = point.x + (inv.y * 48.f);
//	right.y = point.y + (inv.x * -48.f);
//
//	cstrike.m_engine_trace->TraceRay(Ray(right, point, mins, maxs), CONTENTS_SOLID, (i_trace_filter*)&filter, &trace);
//	float r = trace.m_startsolid ? 0.f : trace.m_fraction;
//
//	// both are solid, no edge.
//	if (l == 0.f && r == 0.f)
//		return false;
//
//	// set out to inversed normal.
//	out.y = math::rad_to_deg(std::atan2(inv.y, inv.x));
//
//	// left started solid.
//	// set angle to the left.
//	if (l == 0.f) {
//		out.y += 90.f;
//		return true;
//	}
//
//	// right started solid.
//	// set angle to the right.
//	if (r == 0.f) {
//		out.y -= 90.f;
//		return true;
//	}
//
//	return false;
//}
//
//void c_antiaim_system::run_real_anti_aim() {
//	// if we have a yaw antaim.
//	if (m_yaw > 0) {
//
//		// if we have a yaw active, which is true if we arrived here.
//		// set the yaw to the direction before applying any other operations.
//		ctx.m_cmd->m_view_angles.y = m_direction;
//
//		bool stand = g_menu.main.antiaim.body_fake_stand.get() > 0 && m_mode == antiaim_mode::stand;
//		bool air = g_menu.main.antiaim.body_fake_air.get() > 0 && m_mode == antiaim_mode::air;
//
//		// one tick before the update.
//		if (stand && !ctx.m_lag && cstrike.m_globals->m_curtime >= (ctx.m_body_pred - ctx.m_anim_frame) && cstrike.m_globals->m_curtime < ctx.m_body_pred) {
//			// z mode.
//			if (g_menu.main.antiaim.body_fake_stand.get() == 4)
//				ctx.m_cmd->m_view_angles.y -= 90.f;
//		}
//
//		static int negative = false;
//
//		// check if we will have a lby fake this tick.
//		if (!ctx.m_lag && cstrike.m_globals->m_curtime >= ctx.m_body_pred && (stand || air) && !g_input.GetKeyState(g_menu.main.movement.fakewalk.get())) {
//			// there will be an lbyt update on this tick.
//
//				if (stand) {
//					switch (g_menu.main.antiaim.body_fake_stand.get()) {
//
//						// z.
//					case 1:
//						ctx.m_cmd->m_view_angles.y += 90.f;
//						break;
//					case 2:
//						negative ? ctx.m_cmd->m_view_angles.y += 110.f : ctx.m_cmd->m_view_angles.y -= 110.f;
//						negative = !negative;
//						break;
//
//					}
//				}
//
//			else if (air) {
//				switch (g_menu.main.antiaim.body_fake_air.get()) {
//
//					// left.
//				case 1:
//					ctx.m_cmd->m_view_angles.y += 90.f;
//					break;
//
//					// right.
//				case 2:
//					ctx.m_cmd->m_view_angles.y -= 90.f;
//					break;
//
//					// opposite.
//				case 3:
//					ctx.m_cmd->m_view_angles.y += 180.f;
//					break;
//				}
//			}
//		}
//
//		// run normal aa code.
//		else {
//			switch (m_yaw) {
//
//				// direction.
//			case 1:
//				// do nothing, yaw already is direction.
//				break;
//
//				// jitter.
//			case 2: {
//
//				// get the range from the menu.
//				float range = m_jitter_range / 2.f;
//
//				// set angle.
//				ctx.m_cmd->m_view_angles.y += cstrike.RandomFloat(-range, range);
//				break;
//			}
//
//				  // rotate.
//			case 3: {
//				// set base angle.
//				ctx.m_cmd->m_view_angles.y = (m_direction - m_rot_range / 2.f);
//
//				// apply spin.
//				ctx.m_cmd->m_view_angles.y += std::fmod(cstrike.m_globals->m_curtime * (m_rot_speed * 20.f), m_rot_range);
//
//				break;
//			}
//
//				  // random.
//			case 4:
//				// check update time.
//				if (cstrike.m_globals->m_curtime >= m_next_random_update) {
//
//					// set new random angle.
//					m_random_angle = cstrike.RandomFloat(-180.f, 180.f);
//
//					// set next update time
//					m_next_random_update = cstrike.m_globals->m_curtime + m_rand_update;
//				}
//
//				// apply angle.
//				ctx.m_cmd->m_view_angles.y = m_random_angle;
//				break;
//
//			default:
//				break;
//			}
//		}
//	}
//
//	// normalize angle.
//	math::normalize_angle(ctx.m_cmd->m_view_angles.y);
//}
//
//void c_antiaim_system::run_fake_anti_aim() {
//	// do fake yaw operations.
//
//	// enforce this otherwise low fps dies.
//	// cuz the engine chokes or w/e
//	// the fake became the real, think this fixed it.
//	*ctx.m_packet = true;
//
//	switch (g_menu.main.antiaim.fake_yaw.get()) {
//
//		// default.
//	case 1:
//		// set base to opposite of direction.
//		ctx.m_cmd->m_view_angles.y = m_direction + 180.f;
//
//		// apply 45 degree jitter.
//		ctx.m_cmd->m_view_angles.y += cstrike.RandomFloat(-90.f, 90.f);
//		break;
//
//		// relative.
//	case 2:
//		// set base to opposite of direction.
//		ctx.m_cmd->m_view_angles.y = m_direction + 180.f;
//
//		// apply offset correction.
//		ctx.m_cmd->m_view_angles.y += g_menu.main.antiaim.fake_relative.get();
//		break;
//
//		// relative jitter.
//	case 3: {
//		// get fake jitter range from menu.
//		float range = g_menu.main.antiaim.fake_jitter_range.get() / 2.f;
//
//		// set base to opposite of direction.
//		ctx.m_cmd->m_view_angles.y = m_direction + 180.f;
//
//		// apply jitter.
//		ctx.m_cmd->m_view_angles.y += cstrike.RandomFloat(-range, range);
//		break;
//	}
//
//		  // rotate.
//	case 4:
//		ctx.m_cmd->m_view_angles.y = m_direction + 90.f + std::fmod(cstrike.m_globals->m_curtime * 360.f, 180.f);
//		break;
//
//		// random.
//	case 5:
//		ctx.m_cmd->m_view_angles.y = cstrike.RandomFloat(-180.f, 180.f);
//		break;
//
//		// local view.
//	case 6:
//		ctx.m_cmd->m_view_angles.y = ctx.m_view_angles.y;
//		break;
//
//	default:
//		break;
//	}
//
//	// normalize fake angle.
//	math::normalize_angle(ctx.m_cmd->m_view_angles.y);
//}
//
//void c_antiaim_system::anti_aim_init() {
//	bool attack, attack2;
//
//	if (!g_menu.main.antiaim.enable.get())
//		return;
//
//	attack = ctx.m_cmd->m_buttons & IN_ATTACK;
//	attack2 = ctx.m_cmd->m_buttons & IN_ATTACK2;
//
//	if (ctx.m_weapon && ctx.m_weapon_fire) {
//		bool knife = ctx.m_weapon_type == WEAPONTYPE_KNIFE && ctx.m_weapon_id != ZEUS;
//		bool revolver = ctx.m_weapon_id == REVOLVER;
//
//		// if we are in attack and can fire, do not anti-aim.
//		if (attack || (attack2 && (knife || revolver)))
//			return;
//	}
//
//	// disable conditions.
//	if (cstrike.m_gamerules->m_bFreezePeriod() || (ctx.m_flags & FL_FROZEN) || ctx.m_round_end || (ctx.m_cmd->m_buttons & IN_USE))
//		return;
//
//	// grenade throwing
//	// CBaseCSGrenade::ItemPostFrame()
//	// https://github.com/VSES/SourceEngine2007/blob/master/src_main/game/shared/cstrike/weapon_basecsgrenade.cpp#L209
//	if (ctx.m_weapon_type == WEAPONTYPE_GRENADE && (!ctx.m_weapon->m_bPinPulled() || attack || attack2) && ctx.m_weapon->m_fThrowTime() > 0.f && ctx.m_weapon->m_fThrowTime() < cstrike.m_globals->m_curtime)
//	   return;
//
//	m_mode = antiaim_mode::stand;
//
//	if ((ctx.m_buttons & IN_JUMP) || !(ctx.m_flags & FL_ONGROUND))
//		m_mode = antiaim_mode::air;
//
//	else if (ctx.m_speed > 0.1f)
//		m_mode = antiaim_mode::walk;
//
//	// load settings.
//	if (m_mode == antiaim_mode::stand) {
//		m_pitch = g_menu.main.antiaim.pitch_stand.get();
//		m_yaw = g_menu.main.antiaim.yaw_stand.get();
//		m_jitter_range = g_menu.main.antiaim.jitter_range_stand.get();
//		m_rot_range = g_menu.main.antiaim.rot_range_stand.get();
//		m_rot_speed = g_menu.main.antiaim.rot_speed_stand.get();
//		m_rand_update = g_menu.main.antiaim.rand_update_stand.get();
//		m_dir = g_menu.main.antiaim.dir_stand.get();
//		m_dir_custom = g_menu.main.antiaim.dir_custom_stand.get();
//		m_base_angle = g_menu.main.antiaim.base_angle_stand.get();
//		m_auto_time = g_menu.main.antiaim.dir_time_stand.get();
//	}
//
//	else if (m_mode == antiaim_mode::walk) {
//		m_pitch = g_menu.main.antiaim.pitch_walk.get();
//		m_yaw = g_menu.main.antiaim.yaw_walk.get();
//		m_jitter_range = g_menu.main.antiaim.jitter_range_walk.get();
//		m_rot_range = g_menu.main.antiaim.rot_range_walk.get();
//		m_rot_speed = g_menu.main.antiaim.rot_speed_walk.get();
//		m_rand_update = g_menu.main.antiaim.rand_update_walk.get();
//		m_dir = g_menu.main.antiaim.dir_walk.get();
//		m_dir_custom = g_menu.main.antiaim.dir_custom_walk.get();
//		m_base_angle = g_menu.main.antiaim.base_angle_walk.get();
//		m_auto_time = g_menu.main.antiaim.dir_time_walk.get();
//	}
//
//	else if (m_mode == antiaim_mode::air) {
//		m_pitch = g_menu.main.antiaim.pitch_air.get();
//		m_yaw = g_menu.main.antiaim.yaw_air.get();
//		m_jitter_range = g_menu.main.antiaim.jitter_range_air.get();
//		m_rot_range = g_menu.main.antiaim.rot_range_air.get();
//		m_rot_speed = g_menu.main.antiaim.rot_speed_air.get();
//		m_rand_update = g_menu.main.antiaim.rand_update_air.get();
//		m_dir = g_menu.main.antiaim.dir_air.get();
//		m_dir_custom = g_menu.main.antiaim.dir_custom_air.get();
//		m_base_angle = g_menu.main.antiaim.base_angle_air.get();
//		m_auto_time = g_menu.main.antiaim.dir_time_air.get();
//	}
//
//	// set pitch.
//	init_pitch();
//
//	// if we have any yaw.
//	if (m_yaw > 0) {
//		// set direction.
//		get_anti_aim_direction();
//	}
//
//	// we have no real, but we do have a fake.
//	else if (g_menu.main.antiaim.fake_yaw.get() > 0)
//		m_direction = ctx.m_cmd->m_view_angles.y;
//
//	if (g_menu.main.antiaim.fake_yaw.get()) {
//		// do not allow 2 consecutive sendpacket true if faking angles.
//		if (*ctx.m_packet && ctx.m_old_packet)
//			*ctx.m_packet = false;
//
//		// run the real on sendpacket false.
//		if (!*ctx.m_packet || !*ctx.m_final_packet)
//			run_real_anti_aim();
//
//		// run the fake on sendpacket true.
//		else run_fake_anti_aim();
//	}
//
//	// no fake, just run real.
//	else run_real_anti_aim();
//}
//
//void c_antiaim_system::sendpacket() {
//	// if not the last packet this shit wont get sent anyway.
//	// fix rest of hack by forcing to false.
//	if (!*ctx.m_final_packet)
//		*ctx.m_packet = false;
//
//	// fake-lag enabled.
//	if (g_menu.main.antiaim.lag_enable.get() && !cstrike.m_gamerules->m_bFreezePeriod() && !(ctx.m_flags & FL_FROZEN)) {
//		// limit of lag.
//		int limit = std::min((int)g_menu.main.antiaim.lag_limit.get(), ctx.m_max_lag);
//
//		// indicates wether to lag or not.
//		bool active{ };
//
//		// get current origin.
//		vec3_t cur = ctx.m_local->m_vecOrigin();
//
//		// get prevoius origin.
//		vec3_t prev = ctx.m_net_pos.empty() ? ctx.m_local->m_vecOrigin() : ctx.m_net_pos.front().m_pos;
//
//		// delta between the current origin and the last sent origin.
//		float delta = (cur - prev).length_sqr();
//
//		auto activation = g_menu.main.antiaim.lag_active.GetActiveIndices();
//		for (auto it = activation.begin(); it != activation.end(); it++) {
//
//			// move.
//			if (*it == 0 && delta > 0.1f && ctx.m_speed > 0.1f) {
//				active = true;
//				break;
//			}
//
//			// air.
//			else if (*it == 1 && ((ctx.m_buttons & IN_JUMP) || !(ctx.m_flags & FL_ONGROUND))) {
//				active = true;
//				break;
//			}
//
//			// crouch.
//			else if (*it == 2 && ctx.m_local->m_bDucking()) {
//				active = true;
//				break;
//			}
//		}
//
//		if (active) {
//			int mode = g_menu.main.antiaim.lag_mode.get();
//
//			// max.
//			if (mode == 0)
//				*ctx.m_packet = false;
//
//			// break.
//			else if (mode == 1 && delta <= 4096.f)
//				*ctx.m_packet = false;
//
//			// break step.
//			else if (mode == 2) {
//				// normal break.
//				if (m_step_switch) {
//					if (delta <= 4096.f)
//						*ctx.m_packet = false;
//				}
//
//				// max.
//				else *ctx.m_packet = false;
//			}
//
//			// fluctuate.
//			else if (mode == 3) {
//				int variance = g_menu.main.antiaim.lag_variance.get();
//
//				if (ctx.m_cmd->m_command_number % variance >= limit)
//					limit = 2;
//
//				*ctx.m_packet = false;
//			}
//
//			// random.
//			else if (mode == 4) {
//				// compute new factor.
//				if (ctx.m_lag >= m_random_lag)
//					m_random_lag = cstrike.RandomInt(2, limit);
//
//				// factor not met, keep choking.
//				else *ctx.m_packet = false;
//			}
//
//			if (ctx.m_lag >= limit)
//				*ctx.m_packet = true;
//		}
//	}
//
//	if (!g_menu.main.antiaim.lag_land.get()) {
//		vec3_t                     start = ctx.m_local->m_vecOrigin(), end = start, vel = ctx.m_local->m_vecVelocity();
//		c_trace_filter_world_only  filter;
//		c_game_trace               trace;
//
//		// gravity.
//		vel.z -= (cstrike.sv_gravity->get_float() * cstrike.m_globals->m_interval);
//
//		// extrapolate.
//		end += (vel * cstrike.m_globals->m_interval);
//
//		// move down.
//		end.z -= 2.f;
//
//		cstrike.m_engine_trace->TraceRay(Ray(start, end), MASK_SOLID, &filter, &trace);
//
//		// check if landed.
//		if (trace.m_fraction != 1.f && trace.m_plane.m_normal.z > 0.7f && !(ctx.m_flags & FL_ONGROUND))
//			*ctx.m_packet = true;
//	}
//
//	// force fake-lag to 14 when fakelagging.
//	if (g_input.GetKeyState(g_menu.main.movement.fakewalk.get())) {
//		*ctx.m_packet = false;
//	}
//
//	// do not lag while shooting.
//	if (ctx.m_old_shot)
//		*ctx.m_packet = true;
//
//	// we somehow reached the maximum amount of lag.
//	// we cannot lag anymore and we also cannot shoot anymore since we cant silent aim.
//	if (ctx.m_lag >= ctx.m_max_lag) {
//		// set bSendPacket to true.
//		*ctx.m_packet = true;
//
//		// disable firing, since we cannot choke the last packet.
//		ctx.m_weapon_fire = false;
//	}
//}