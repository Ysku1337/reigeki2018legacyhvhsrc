#pragma once

class c_bones {

public:
	bool m_running;

public:
	bool setup(c_base_player* player, c_bone_array* out, c_lag_record* record);
	bool build_bones(c_base_player* target, int mask, c_bone_array* out, c_lag_record* record);
};

extern c_bones bonesetup;

class c_animation_sync {
public:

	void predict_animations(c_animation_state* state, c_lag_record* record);
	void update_local_animations();


};

extern c_animation_sync animations;