#pragma once

class shot_record_t {
public:
	__forceinline shot_record_t() : m_target{}, m_record{}, m_time{}, m_lat{}, m_damage{}, m_pos{}, m_matched{} {}

public:
	c_base_player* m_target;
	c_lag_record* m_record;
	float         m_time, m_lat, m_damage;
	vec3_t        m_pos;
	bool          m_matched;
};

class visual_impact_data_t {
public:
	vec3_t m_impact_pos, m_shoot_pos;
	int    m_tickbase;
	bool   m_ignore, m_hit_player;

public:
	__forceinline visual_impact_data_t(const vec3_t& impact_pos, const vec3_t& shoot_pos, int tickbase) :
		m_impact_pos{ impact_pos }, m_shoot_pos{ shoot_pos }, m_tickbase{ tickbase }, m_ignore{ false }, m_hit_player{ false } {}
};

class impact_record_t {
public:
	__forceinline impact_record_t() : m_shot{}, m_pos{}, m_tick{} {}

public:
	shot_record_t* m_shot;
	int            m_tick;
	vec3_t         m_pos;
};

class hit_record_t {
public:
	__forceinline hit_record_t() : m_impact{}, m_group{ -1 }, m_damage{} {}

public:
	impact_record_t* m_impact;
	int              m_group;
	float            m_damage;
};

class c_shots {
private:
	std::array< std::string, 8 > m_groups = {
		XOR("body"),
		XOR("head"),
		XOR("chest"),
		XOR("stomach"),
		XOR("left arm"),
		XOR("right arm"),
		XOR("left leg"),
		XOR("right leg")
	};

public:
	void on_shot_fire(c_base_player* target, float damage, int bullets, c_lag_record* record);
	void on_impact(i_game_event* evt);
	void on_hurt(i_game_event* evt);

public:
	std::deque< shot_record_t >          m_shots;
	std::vector< visual_impact_data_t >  m_vis_impacts;
	std::deque< impact_record_t >        m_impacts;
	std::deque< hit_record_t >           m_hits;
};

extern c_shots shots;