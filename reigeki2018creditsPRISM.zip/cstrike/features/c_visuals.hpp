#pragma once

struct offscreen_damage_data_t {
    float m_time, m_color_step;
    Color m_color;

    __forceinline offscreen_damage_data_t( ) : m_time{ 0.f }, m_color{ colors::white } {}
    __forceinline offscreen_damage_data_t( float time, float m_color_step, Color color ) : m_time{ time }, m_color{ color } {}
};

struct world_hitmarker_data_t {
    float m_time, m_alpha;
    float m_pos_x, m_pos_y, m_pos_z;

    vec2_t m_world_pos;
    bool m_world_to_screen;
};


class c_visuals {
public:
    std::array< bool, 64 >                    m_draw;
    std::array< float, 2048 >                 m_opacities;
    std::array< offscreen_damage_data_t, 64 > m_offscreen_damage;
    std::vector< world_hitmarker_data_t >     m_world_hitmarkers;
    vec2_t                                    m_crosshair;
    bool                                      m_thirdperson;
    bool                                    m_old_thirdperson;
    float					                  m_hit_start, m_hit_end, m_hit_duration;
    std::array < rect_t, 64 >                 m_saved_boxes[65];

    // info about planted c4.
    bool        m_c4_planted;
    entity_t* m_planted_c4;
    float       m_planted_c4_explode_time;
    vec3_t      m_planted_c4_explosion_origin;
    float       m_planted_c4_damage;
    float       m_planted_c4_radius;
    float       m_planted_c4_radius_scaled;
    std::string m_last_bombsite;

    // viewmodel.
    float       m_viewmodel[3];
    bool        m_viewmodel_modified;

    i_material* smoke1;
    i_material* smoke2;
    i_material* smoke3;
    i_material* smoke4;

   std::unordered_map< int, char > m_weapon_icons = {
        { DEAGLE, 'F' },
        { ELITE, 'S' },
        { FIVESEVEN, 'U' },
        { GLOCK, 'C' },
        { AK47, 'B' },
        { AUG, 'E' },
        { AWP, 'R' },
        { FAMAS, 'T' },
        { G3SG1, 'I' },
        { GALIL, 'V' },
        { M249, 'Z' },
        { M4A4, 'W' },
        { MAC10, 'L' },
        { P90, 'M' },
        { UMP45, 'Q' },
        { XM1014, ']' },
        { BIZON, 'D' },
        { MAG7, 'K' },
        { NEGEV, 'Z' },
        { SAWEDOFF, 'K' },
        { TEC9, 'C' },
        { ZEUS, 'Y' },
        { P2000, 'Y' },
        { MP7, 'X' },
        { MP9, 'D' },
        { NOVA, 'K' },
        { P250, 'Y' },
        { SCAR20, 'I' },
        { SG553, '[' },
        { SSG08, 'N' },
        { KNIFE_CT, 'J' },
        { FLASHBANG, 'G' },
        { HEGRENADE, 'H' },
        { SMOKE, 'P' },
        { MOLOTOV, 'H' },
        { DECOY, 'G' },
        { FIREBOMB, 'H' },
        { C4, '\\' },
        { KNIFE_T, 'J' },
        { M4A1S, 'W' },
        { USPS, 'Y' },
        { CZ75A, 'Y' },
        { REVOLVER, 'F' },
        { KNIFE_BAYONET, 'J' },
        { KNIFE_FLIP, 'J' },
        { KNIFE_GUT, 'J' },
        { KNIFE_KARAMBIT, 'J' },
        { KNIFE_M9_BAYONET, 'J' },
        { KNIFE_HUNTSMAN, 'J' },
        { KNIFE_FALCHION, 'J' },
        { KNIFE_BOWIE, 'J' },
        { KNIFE_BUTTERFLY, 'J' },
        { KNIFE_SHADOW_DAGGERS, 'J' },
    };

    std::unordered_map< int, char* > m_weapon_name = {
        { DEAGLE, "deagle" },
        { ELITE, "elite" },
        { FIVESEVEN, "five-seven" },
        { GLOCK, "glock" },
        { AK47, "ak47" },
        { AUG, "aug" },
        { AWP, "awp" },
        { FAMAS, "famas" },
        { G3SG1, "g3sg1" },
        { GALIL, "galil" },
        { M249, "m249" },
        { M4A4, "m4a1" },
        { MAC10, "mac10" },
        { P90, "p90" },
        { UMP45, "ump45" },
        { XM1014, "xm1014" },
        { BIZON, "bizon" },
        { MAG7, "mag7" },
        { NEGEV, "negev" },
        { SAWEDOFF, "sawed-off" },
        { TEC9, "tec9" },
        { ZEUS, "taser" },
        { P2000, "p2000" },
        { MP7, "mp7" },
        { MP9, "mp9" },
        { NOVA, "nova" },
        { P250, "p250" },
        { SCAR20, "scar20" },
        { SG553, "sg556" },
        { SSG08, "ssg08" },
        { KNIFE_CT, "knife" },
        { FLASHBANG, "flashbang" },
        { HEGRENADE, "grenade" },
        { SMOKE, "smoke" },
        { MOLOTOV, "molotov" },
        { DECOY, "decoy" },
        { FIREBOMB, "incedinary" },
        { C4, "c4" },
        { KNIFE_T, "knife" },
        { M4A1S, "m4a1-s" },
        { USPS, "usp-s" },
        { CZ75A, "cz75-a" },
        { REVOLVER, "revolver" },
        { KNIFE_BAYONET, "bayonet" },
        { KNIFE_FLIP, "flip knife" },
        { KNIFE_GUT, "gut knife" },
        { KNIFE_KARAMBIT, "karambit" },
        { KNIFE_M9_BAYONET, "m9 bayonet" },
        { KNIFE_HUNTSMAN, "huntsman" },
        { KNIFE_FALCHION, "falchion" },
        { KNIFE_BOWIE, "bowie knife" },
        { KNIFE_BUTTERFLY, "butterfly knife" },
        { KNIFE_SHADOW_DAGGERS, "shadow daggers" },
    };


public:
	static void modulate_world( );
	void thirdperson_think( );
    void visual_interpolation( );
    void skybox_manipulation();
	void draw_hitmarker( );
    void draw_world_hitmarker();
	void remove_smoke( );
	void think( );
	void draw_spectators( );
	void draw_indicators( );
	void draw_spread_crosshair( );
    void draw_penetrate_crosshair( );
    void draw_planted_bomb();
	void draw( entity_t* ent );
	void draw_projectile( weapon_t* ent );
	void draw_ground_item( weapon_t* item );
	void draw_offscreen( c_base_player* player, int alpha );
	void draw_player( c_base_player* player );
	bool get_player_box_rect( c_base_player* player, rect_t& box );
	void draw_history_skeleton( c_base_player* player, int opacity );
	void draw_skeleton( c_base_player* player, int opacity );
	void render_glow( );
	void draw_hitgroup( c_lag_record* record, Color col, float time );
    void draw_beams( );
    void get_viewmodel();
    void ViewModel();
    void ClientImpacts();
	void draw_dbg_points( c_base_player* player );
    void taser_range();

};

extern c_visuals visuals;