#pragma once

// pre-declare.
class c_lag_record;

class c_backup_record {
public:
	c_bone_array* m_bones;
	int           m_bone_count;
	vec3_t        m_origin, m_abs_origin;
	vec3_t        m_mins;
	vec3_t        m_maxs;
	ang_t         m_abs_ang;

public:
	__forceinline void store(c_base_player* player) {
		// get bone cache ptr.
		c_bone_cache* cache = &player->m_BoneCache();

		// store bone data.
		m_bones = cache->m_pCachedBones;
		m_bone_count = cache->m_CachedBoneCount;
		m_origin = player->m_vecOrigin();
		m_mins = player->m_vecMins();
		m_maxs = player->m_vecMaxs();
		m_abs_origin = player->get_abs_origin();
		m_abs_ang = player->get_abs_angles();
	}

	__forceinline void restore(c_base_player* player) {
		// get bone cache ptr.
		c_bone_cache* cache = &player->m_BoneCache();

		cache->m_pCachedBones = m_bones;
		cache->m_CachedBoneCount = m_bone_count;

		player->m_vecOrigin() = m_origin;
		player->m_vecMins() = m_mins;
		player->m_vecMaxs() = m_maxs;
		player->set_abs_angles(m_abs_ang);
		player->set_abs_origin(m_origin);
	}
};

class c_lag_record {
public:
	// data.
	c_base_player* m_player;
	float          m_immune;
	int            m_tick;
	int            m_lag;
	bool           m_dormant;

	// netvars.
	float  m_sim_time;
	float  m_old_sim_time;
	int    m_flags;
	vec3_t m_abs_origin;
	vec3_t m_origin;
	vec3_t m_old_origin;
	vec3_t m_velocity;
	vec3_t m_mins;
	vec3_t m_maxs;
	ang_t  m_eye_angles;
	ang_t  m_abs_ang;
	float  m_body;
	float  m_duck;

	// anim stuff.
	c_animation_layer m_layers[13];
	float            m_poses[24];
	vec3_t           m_anim_velocity;

	// bone stuff.
	bool       m_setup;
	c_bone_array* m_bones;

	// lagfix stuff.
	bool   m_broke_lc;
	vec3_t m_pred_origin;
	vec3_t m_pred_velocity;
	float  m_pred_time;
	int    m_pred_flags;

	// resolver stuff.
	size_t m_mode;
	bool   m_fake_walk;
	bool   m_shot;
	float  m_away;
	float  m_anim_time;

	// other stuff.
	float  m_interp_time;
	float  m_curtime;

	//lby flick detect stuff
	bool m_running_timer;
	float m_next_lby_update;
	float m_last_lby_update;
	bool m_lby_flick;

public:

	// default ctor.
	__forceinline c_lag_record() :
		m_setup{ false },
		m_broke_lc{ false },
		m_fake_walk{ false },
		m_shot{ false },
		m_lag{},
		m_bones{} {}

	// ctor.
	__forceinline c_lag_record(c_base_player* player) :
		m_setup{ false },
		m_broke_lc{ false },
		m_fake_walk{ false },
		m_shot{ false },
		m_lag{},
		m_bones{} {

		store(player);
	}

	// dtor.
	__forceinline ~c_lag_record() {
		// free heap allocated game mem.
		cstrike.m_mem_alloc->free(m_bones);
	}

	__forceinline void invalidate() {
		// free heap allocated game mem.
		cstrike.m_mem_alloc->free(m_bones);

		// mark as not setup.
		m_setup = false;

		// allocate new memory.
		m_bones = (c_bone_array*)cstrike.m_mem_alloc->alloc(sizeof(c_bone_array) * 128);
	}

	// function: allocates memory for SetupBones and stores relevant data.
	void store(c_base_player* player) {
		// allocate game heap.
		m_bones = (c_bone_array*)cstrike.m_mem_alloc->alloc(sizeof(c_bone_array) * 128);

		// player data.
		m_player = player;
		m_immune = player->m_fImmuneToGunGameDamageTime();
		m_tick = cstrike.m_cl->m_server_tick;

		// netvars.
		m_pred_time = m_sim_time = player->m_flSimulationTime();
		m_old_sim_time = player->m_flOldSimulationTime();
		m_pred_flags = m_flags = player->m_fFlags();
		m_pred_origin = m_origin = player->m_vecOrigin();
		m_old_origin = player->m_vecOldOrigin();
		m_eye_angles = player->m_angEyeAngles();
		m_abs_ang = player->get_abs_angles();
		m_body = player->m_flLowerBodyYawTarget();
		m_mins = player->m_vecMins();
		m_maxs = player->m_vecMaxs();
		m_duck = player->m_flDuckAmount();
		m_pred_velocity = m_velocity = player->m_vecVelocity();

		// save networked animlayers.
		player->get_anim_layers(m_layers);

		// normalize eye angles.
		m_eye_angles.normalize();
		math::clamp(m_eye_angles.x, -90.f, 90.f);

		// get lag.
		m_lag = game::time_to_ticks(m_sim_time - m_old_sim_time);

		// compute animtime.
		m_anim_time = m_old_sim_time + cstrike.m_globals->m_interval;
	}

	// function: restores 'predicted' variables to their original.
	__forceinline void predict() {
		m_broke_lc = false;
		m_pred_origin = m_origin;
		m_pred_velocity = m_velocity;
		m_pred_time = m_sim_time;
		m_pred_flags = m_flags;
	}

	// function: writes current record to bone cache.
	__forceinline void cache() {
		// get bone cache ptr.
		c_bone_cache* cache = &m_player->m_BoneCache();

		cache->m_pCachedBones = m_bones;
		cache->m_CachedBoneCount = 128;

		m_player->m_vecOrigin() = m_pred_origin;
		m_player->m_vecMins() = m_mins;
		m_player->m_vecMaxs() = m_maxs;

		m_player->set_abs_angles(m_abs_ang);
		m_player->set_abs_origin(m_pred_origin);
	}

	__forceinline bool dormant() {
		return m_dormant;
	}

	__forceinline bool immune() {
		return m_immune > 0.f;
	}

	// function: checks if LagRecord obj is hittable if we were to fire at it now.
	bool valid() {
		// use prediction curtime for this.
		float curtime = game::ticks_to_time(ctx.m_local->m_nTickBase());

		// correct is the amount of time we have to correct game time,
		float correct = ctx.m_lerp + ctx.m_latency;

		// stupid fake latency goes into the incoming latency.
		float in = cstrike.m_net->get_latency(i_net_channel::FLOW_INCOMING);
		correct += in;

		// check bounds [ 0, sv_maxunlag ]
		math::clamp(correct, 0.f, cstrike.sv_maxunlag->get_float());

		// calculate difference between tick sent by player and our latency based tick.
		// ensure this record isn't too old.
		return std::abs(correct - (curtime - m_sim_time)) < 0.19f;
	}
};