#include "../project.hpp"

c_prediction_system engine_predict{};;

void c_prediction_system::update() {
	bool        valid{ cstrike.m_cl->m_delta_tick > 0 };
	//int         outgoing_command, current_command;
	//CUserCmd    *cmd;

	// render start was not called.
	if (ctx.m_stage == FRAME_NET_UPDATE_END) {

		int start = cstrike.m_cl->m_last_command_ack;
		int stop = cstrike.m_cl->m_last_outgoing_command + cstrike.m_cl->m_choked_commands;

		// call CPrediction::Update.
		cstrike.m_prediction->update(cstrike.m_cl->m_delta_tick, valid, start, stop);
	}

	static bool unlocked_fakelag = false;
	if (!unlocked_fakelag) {
		auto cl_move_clamp = pattern::find(cstrike.m_engine_dll, XOR("B8 ? ? ? ? 3B F0 0F 4F F0 89 5D FC")) + 1;
		unsigned long protect = 0;

		VirtualProtect((void*)cl_move_clamp, 4, PAGE_EXECUTE_READWRITE, &protect);
		*(std::uint32_t*)cl_move_clamp = 62;
		VirtualProtect((void*)cl_move_clamp, 4, protect, &protect);
		unlocked_fakelag = true;
	}
}

void c_prediction_system::run() {
	static c_move_data data{};

	cstrike.m_prediction->m_in_prediction = true;

	// CPrediction::StartCommand
	ctx.m_local->m_pCurrentCommand() = ctx.m_cmd;
	ctx.m_local->m_PlayerCommand() = *ctx.m_cmd;

	*cstrike.m_nPredictionRandomSeed = ctx.m_cmd->m_random_seed;
	cstrike.m_pPredictionPlayer = ctx.m_local;

	// backup globals.
	m_curtime = cstrike.m_globals->m_curtime;
	m_frametime = cstrike.m_globals->m_frametime;

	// CPrediction::RunCommand

	// set globals appropriately.
	cstrike.m_globals->m_curtime = game::ticks_to_time(ctx.m_local->m_nTickBase());
	cstrike.m_globals->m_frametime = cstrike.m_prediction->m_engine_paused ? 0.f : cstrike.m_globals->m_interval;

	// set target player ( host ).
	cstrike.m_move_helper->set_host(ctx.m_local);
	cstrike.m_game_movement->start_track_prediction_errors(ctx.m_local);

	// setup input.
	cstrike.m_prediction->setup_move(ctx.m_local, ctx.m_cmd, cstrike.m_move_helper, &data);

	// run movement.
	cstrike.m_game_movement->process_movement(ctx.m_local, &data);
	cstrike.m_prediction->finish_move(ctx.m_local, ctx.m_cmd, &data);
	cstrike.m_game_movement->finish_track_prediction_errors(ctx.m_local);

	// reset target player ( host ).
	cstrike.m_move_helper->set_host(nullptr);
}


void c_prediction_system::restore() {
	cstrike.m_prediction->m_in_prediction = false;

	*cstrike.m_nPredictionRandomSeed = -1;
	cstrike.m_pPredictionPlayer = nullptr;

	// restore globals.
	cstrike.m_globals->m_curtime = m_curtime;
	cstrike.m_globals->m_frametime = m_frametime;
}

