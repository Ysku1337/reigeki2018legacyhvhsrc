#pragma once

class c_game_move {
public:


	void player_movement(c_lag_record* record);
	void air_accelerate(c_lag_record* record, ang_t angle, float fmove, float smove);

	void extrapolate_movement(c_base_player* player, vec3_t& origin, vec3_t& velocity, int& flags, bool on_ground);

};

extern c_game_move game_movement;