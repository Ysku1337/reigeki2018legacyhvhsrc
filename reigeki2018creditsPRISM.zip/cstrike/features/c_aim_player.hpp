#pragma once

enum hitscan_mode : int {
	normal_mode = 0,
	lethal_mode = 1,
	lethal2_mode = 3,
	prefer_mode = 4
};


struct animation_backup_t {
	vec3_t           m_origin, m_abs_origin;
	vec3_t           m_velocity, m_abs_velocity;
	int              m_flags, m_eflags;
	float            m_duck, m_body;
	c_animation_layer m_layers[13];
};

struct hitscan_data_t {
	float  m_damage;
	vec3_t m_pos;

	__forceinline hitscan_data_t() : m_damage{ 0.f }, m_pos{} {}
};

struct hitscan_box_t {
	int          m_index;
	hitscan_mode m_mode;

	__forceinline bool operator==(const hitscan_box_t& c) const {
		return m_index == c.m_index && m_mode == c.m_mode;
	}
};


class c_aim_player {
public:
	using records_t = std::deque< std::shared_ptr< c_lag_record > >;
	using hitboxcan_t = stdpp::unique_vector< hitscan_box_t >;

public:
	// essential data.
	c_base_player* m_player;
	float	  m_spawn;
	records_t m_records;

	// aimbot data.
	hitboxcan_t m_hitboxes;

	// resolve data.
	int          m_shots;
	int          m_missed_shots;
	c_lag_record m_walk_record;

	float     m_body_update;
	bool      m_moved;

	int m_moving_index;
	int m_stand_index;
	int m_bruteforce_index;
	int m_lby_yaw_index;
	int m_freestanding_index;
	int m_unknown_move;
	int m_last_move_index;
	int m_last_move;


	// data about the LBY proxy.
	float m_body;
	float m_old_body;


	//std::deque< float >            m_lbyt_update;
	//std::deque< float >			   m_prefer_stand;
	//std::deque< float >            m_prefer_air;

public:
	void update_enemy_animations(c_lag_record* record);
	void on_net_update(c_base_player* player);
	void on_round_start(c_base_player* player);
	void setup_hitboxes(c_lag_record* record, bool history);
	bool setup_hitbox_points(c_lag_record* record, c_bone_array* bones, int index, std::vector< vec3_t >& points);
	bool get_best_aim_position(vec3_t& aim, float& damage, c_lag_record* record);

public:
	void reset() {
		m_player = nullptr;
		m_spawn = 0.f;
		m_walk_record = c_lag_record{};
		m_shots = 0;
		m_missed_shots = 0;

		m_records.clear();
		m_hitboxes.clear();
	}
};