#include "../project.hpp"

c_lag_compensation lagcomp{};;

bool c_lag_compensation::start_lag_compensation(c_aim_player* data) {
	
		// we have no data to work with.
		// this should never happen if we call this
		if (data->m_records.empty())
			return false;
	
		// meme.
		if (data->m_player->is_dormant())
			return false;
	
		// compute the true amount of updated records
		// since the last time the player entered pvs.
		size_t size{};
	
		// iterate records.
		for (const auto& it : data->m_records) {
			if (it->dormant())
				break;
	
			// increment total amount of data.
			++size;
		}
	
		int wish_tick = 0;
		// get first record.
		c_lag_record* record = data->m_records[0].get();


		// reset all prediction related variables.
		// this has been a recurring problem in all my hacks lmfao.
		// causes the prediction to stack on eachother.
		record->predict();
	
		// check if lc broken.
		if (size > 1 && ((record->m_origin - data->m_records[1]->m_origin).length_sqr() > 4096.f
			|| size > 2 && (data->m_records[1]->m_origin - data->m_records[2]->m_origin).length_sqr() > 4096.f))
			record->m_broke_lc = true;



	
		// we are not breaking lagcomp at this point.
		// return false so it can aim at all the records it once
		// since server-sided lagcomp is still active and we can abuse that.
		if (!record->m_broke_lc)
			return false;
	
		int simulation = game::time_to_ticks(record->m_sim_time);
	
		// this is too much lag to fix.
		if (std::abs(ctx.m_arrival_tick - simulation) >= 128)
			return true;
	
		// compute the amount of lag that we will predict for, if we have one set of data, use that.
		// if we have more data available, use the prevoius lag delta to counter weird fakelags that switch between 14 and 2.
		int lag = (size <= 2) ? game::time_to_ticks(record->m_sim_time - data->m_records[1]->m_sim_time)
			: game::time_to_ticks(data->m_records[1]->m_sim_time - data->m_records[2]->m_sim_time);

		// clamp this just to be sure.
		math::clamp(lag, 1, 15);

	
		// get the delta in ticks between the last server net update
		// and the net update on which we created this record.
		int updatedelta = ctx.m_server_tick - record->m_tick;

		// if the lag delta that is remaining is less than the current netlag
		// that means that we can shoot now and when our shot will get processed
		// the origin will still be valid, therefore we do not have to predict.
		if (ctx.m_latency_ticks <= lag - updatedelta)
			return true;
	
		// the next update will come in, wait for it.
		int next = record->m_tick + 1;
		if (next + lag >= ctx.m_arrival_tick)
			return true;
	
		float change = 0.f, dir = 0.f;
	
		// get the direction of the current velocity.
		if (record->m_velocity.y != 0.f || record->m_velocity.x != 0.f)
			dir = math::rad_to_deg(std::atan2(record->m_velocity.y, record->m_velocity.x));

		// we have more than one update
		// we can compute the direction.
		if (size > 1) {
			// get the delta time between the 2 most recent records.
			float dt = record->m_sim_time - data->m_records[1]->m_sim_time;
	
			// init to 0.
			float prevdir = 0.f;
	
			// get the direction of the prevoius velocity.
			if (data->m_records[1]->m_velocity.y != 0.f || data->m_records[1]->m_velocity.x != 0.f)
				prevdir = math::rad_to_deg(std::atan2(data->m_records[1]->m_velocity.y, data->m_records[1]->m_velocity.x));
	
			// compute the direction change per tick.
			change = (math::normalized_angle(dir - prevdir) / dt) * cstrike.m_globals->m_interval;
		}
	
		if (std::abs(change) > 6.f)
			change = 0.f;
	
		// get the pointer to the players animation state.
		c_animation_state* state = data->m_player->m_PlayerAnimState();

	
		// backup the animation state.
		c_animation_state backup{};

		if (state)
		std::memcpy( &backup, state, sizeof( c_animation_state ) );

		// add in the shot prediction here.
		int shot = 0;
	
		//auto pWeapon = player->get_weapon( );
		//if( pWeapon && pWeapon->IsGun()/*&& !data->m_fire_bullet.empty( )*/ ) {
	
		//	//static Address offset = g_netvars.get( HASH( "DT_BaseCombatWeapon" ), HASH( "m_fLastShotTime" ) );
		//	//float last = pWeapon->get< float >( offset );
	
		//	if( TIME_TO_TICKS( player->m_flSimulationTime() - pWeapon->m_flLastShotTime() ) == 1 ) {
		//		auto wpndata = pWeapon->GetCSWeaponData( );
	
		//		if( wpndata )
		//			shot = TIME_TO_TICKS(player->m_flSimulationTime() + wpndata->flCycleTime) + 1;
		//	}
		//}
	
		int pred = 0;
	
		// start our predicton loop.
		while (true) {
			// can the player shoot within his lag delta.
			if( shot && shot >= simulation && shot < simulation + lag ) {
	
				// if so his new lag will be the time until he shot again.
				lag = shot - simulation;
				math::clamp( lag, 3, 15 );
	
				// only predict a shot once.
				shot = 0;
			}
	
			// see if by predicting this amount of lag
			// we do not break stuff.
			next += lag;
			if (next >= ctx.m_arrival_tick)
				break;
	
			// predict lag.
			for (int sim{}; sim < lag; ++sim) {
				// predict movement direction by adding the direction change per tick to the previous direction.
				// make sure to normalize it, in case we go over the -180/180 turning point.
				dir = math::normalized_angle(dir + change);

				// pythagorean theorem
				// a^2 + b^2 = c^2
				// we know a and b, we square them and add them together, then root.
				float hyp = record->m_pred_velocity.length_2d();

				// compute the base velocity for our new direction.
				// since at this point the hypotenuse is known for us and so is the angle.
				// we can compute the adjacent and opposite sides like so:
				// cos(x) = a / h -> a = cos(x) * h
				// sin(x) = o / h -> o = sin(x) * h
				record->m_pred_velocity.x = std::cos(math::deg_to_rad(dir)) * hyp;
				record->m_pred_velocity.y = std::sin(math::deg_to_rad(dir)) * hyp;

	
				// we hit the ground, set the upwards impulse and apply CS:GO speed restrictions.
				if (record->m_pred_flags & FL_ONGROUND) {
					if (!cstrike.sv_enablebunnyhopping->get_int()) {
	
						// 260 x 1.1 = 286 units/s.
						float max = data->m_player->m_flMaxspeed() * 1.1f;

						// get current velocity.
						float speed = record->m_pred_velocity.length();
	
						// reset velocity to 286 units/s.
						if (max > 0.f && speed > max)
							record->m_pred_velocity *= (max / speed);
					}
	
					// assume the player is bunnyhopping here so set the upwards impulse.
					record->m_pred_velocity.z = cstrike.sv_jump_impulse->get_float();
				}
	
				// we are not on the ground
				// apply gravity and airaccel.
				else {
					// apply one tick of gravity.
					record->m_pred_velocity.z -= cstrike.sv_gravity->get_float() * cstrike.m_globals->m_interval;
	
					// compute the ideal strafe angle for this velocity.
					float speed2d = record->m_pred_velocity.length_2d();
					float ideal = (speed2d > 0.f) ? math::rad_to_deg(std::asin(15.f / speed2d)) : 90.f;
					math::clamp(ideal, 0.f, 90.f);
	
					float smove = 0.f;
					float abschange = std::abs(change);
	
					if (abschange <= ideal || abschange >= 30.f) {
						static float mod{ 1.f };
	
						dir += (ideal * mod);
						smove = 450.f * mod;
						mod *= -1.f;
					}
	
					else if (change > 0.f)
						smove = -450.f;
	
					else
						smove = 450.f;
	
					// apply air accel.
					game_movement.air_accelerate(record, ang_t{ 0.f, dir, 0.f }, 0.f, smove);
				}
	
				// predict player.
				// convert newly computed velocity
				// to origin and flags.
				game_movement.player_movement(record);
	
				// move time forward by one.
				record->m_pred_time += cstrike.m_globals->m_interval;
	
				// increment total amt of predicted ticks.
				++pred;
	
				// the server animates every first choked command.
				// therefore we should do that too.
				if (/*sim == 0 && */state)
					animations.predict_animations(state, record);
			}
		}

		//lagcomp.predict_player(data->m_player, record, data);
	
		// restore state.
		if (state)
			std::memcpy(state, &backup, sizeof(c_animation_state));

		if (pred <= 0)
			return true;

		// lagcomp broken, invalidate bones.
		record->invalidate();

		// re-setup bones for this record.
		bonesetup.setup(data->m_player, nullptr, record);

		return true;
}


int c_lag_compensation::fix_tickcount(const float& simtime)
{
	return game::time_to_ticks(simtime + get_lerp_time());
}

float c_lag_compensation::get_lerp_time()
{

	static auto cl_updaterate = cstrike.m_cvar->find_var(HASH("cl_updaterate"));
	static auto cl_interp = cstrike.m_cvar->find_var(HASH("cl_interp"));

	const auto update_rate = cl_updaterate->get_int();
	const auto interp_ratio = cl_interp->get_float();

	auto lerp = interp_ratio / update_rate;

	if (lerp <= cl_interp->get_float())
		lerp = cl_interp->get_float();

	return lerp;
}

void c_lag_compensation::update_lerp()
{
	static auto cl_interpolate = cstrike.m_cvar->find_var(HASH("cl_interpolate"));

	if (atoi(cl_interpolate->get_string()) != 0) {
		static auto cl_interp_ratio = cstrike.m_cvar->find_var(HASH("cl_interp_ratio"));
		static auto cl_interp = cstrike.m_cvar->find_var(HASH("cl_interp"));
		static auto sv_client_min_interp_ratio = cstrike.m_cvar->find_var(HASH("sv_client_min_interp_ratio"));
		static auto sv_client_max_interp_ratio = cstrike.m_cvar->find_var(HASH("sv_client_max_interp_ratio"));

		static auto cl_updaterate = cstrike.m_cvar->find_var(HASH("cl_updaterate"));
		static auto sv_minupdaterate = cstrike.m_cvar->find_var(HASH("sv_minupdaterate"));
		static auto sv_maxupdaterate = cstrike.m_cvar->find_var(HASH("sv_maxupdaterate"));

		auto update_rate = atoi(cl_updaterate->get_string());
		if (sv_minupdaterate && sv_maxupdaterate)
			update_rate = std::clamp(update_rate, atoi(sv_minupdaterate->get_string()), atoi(sv_maxupdaterate->get_string()));

		auto lerp_amount = (float)atof(cl_interp->get_string());
		auto lerp_ratio = (float)atof(cl_interp_ratio->get_string());
		if (lerp_ratio == 0.f)
			lerp_ratio = 1.f;

		if (sv_client_min_interp_ratio && sv_client_max_interp_ratio && atof(sv_client_min_interp_ratio->get_string()) != -1.f)
			lerp_ratio = (float)std::clamp(lerp_ratio, (float)atof(sv_client_min_interp_ratio->get_string()), (float)atof(sv_client_max_interp_ratio->get_string()));

		ctx.m_lerp = std::max(lerp_amount, lerp_ratio / (float)update_rate);
		return;
	}

	ctx.m_lerp = 0.f;
	return;
}

bool c_lag_compensation::valid_simtime(const float& simtime)
{
	const auto nci = cstrike.m_engine->get_net_channel_info();
	if (!nci)
		return false;

	float correct = 0;

	correct += nci->get_latency(i_net_channel::FLOW_OUTGOING);
	correct += nci->get_latency(i_net_channel::FLOW_INCOMING);
	correct += get_lerp_time();

	const auto delta_time = correct - (cstrike.m_globals->m_curtime - simtime);

	return fabsf(delta_time) <= 0.2f && correct < 1.f;
}


bool c_lag_compensation::is_tick_valid(int tick)
{
	// better use polak's version than our old one, getting more accurate results

	i_net_channel* nci = cstrike.m_engine->get_net_channel_info();

	if (!nci)
		return false;

	float correct = std::clamp(nci->get_latency(i_net_channel::FLOW_OUTGOING) + get_lerp_time(), 0.f, 1.f);

	float deltaTime = correct - (cstrike.m_globals->m_curtime - game::ticks_to_time(tick));

	return fabsf(deltaTime) < 0.2f;
}

void c_lag_compensation::overwrite_tick(c_aim_player* data, c_base_player* player, c_lag_record* overwrite_record, ang_t angles, float_t correct_time)
{
	int idx = player->index();
	auto& lag_records = data->m_records;

	overwrite_record->store(player);
	overwrite_record->m_eye_angles = angles;
	overwrite_record->m_sim_time = correct_time;
	lag_records.emplace_back(overwrite_record);

}


void c_lag_compensation::simulate_movement(c_simulation_data& data) {

	static auto sv_gravity = cstrike.sv_gravity;
	static auto sv_jump_impulse = cstrike.sv_jump_impulse;

	if (!(data.flags & FL_ONGROUND)) {
		data.velocity.z -= (cstrike.m_globals->m_interval * sv_gravity->get_float() * 0.5f);
	}
	else if (data.on_ground) {
		data.on_ground = false;
		data.velocity.z = sv_jump_impulse->get_float();
		data.flags &= ~FL_ONGROUND;
	}

	// can't step up onto very steep slopes
	static const float MIN_STEP_NORMAL = 0.7f;

	if (!data.velocity.is_zero()) {
		const vec3_t mins = data.entity->m_vecMins();
		const vec3_t max = data.entity->m_vecMaxs();

		const vec3_t src = data.origin;
		vec3_t end = src + (data.velocity * cstrike.m_globals->m_interval);

		//ray_t ray;
		//ray.Init(src, end, mins, max);

		c_game_trace trace;
		c_trace_filter_world_only filter;


		cstrike.m_engine_trace->TraceRay(Ray(src, end, mins, max), MASK_SOLID, &filter, &trace);

		// CGameMovement::TryPlayerMove
		if (trace.m_fraction != 1) {
			// BUGFIXME: is it should be 4? ( not 2 )
			for (int i = 0; i < 2; i++) {
				// decompose velocity into plane
				data.velocity -= trace.m_plane.m_normal * data.velocity.dot(trace.m_plane.m_normal);

				const float dot = data.velocity.dot(trace.m_plane.m_normal);
				if (dot < 0.f) { // moving against plane
					data.velocity.x -= dot * trace.m_plane.m_normal.x;
					data.velocity.y -= dot * trace.m_plane.m_normal.y;
					data.velocity.z -= dot * trace.m_plane.m_normal.z;
				}

				end = trace.m_endpos + (data.velocity * (cstrike.m_globals->m_interval * (1.f - trace.m_fraction)));

				cstrike.m_engine_trace->TraceRay(Ray(trace.m_endpos, end, mins, max), MASK_SOLID, &filter, &trace);
				if (trace.m_fraction == 1)
					break;
			}
		}

		data.origin = trace.m_endpos;
		end = trace.m_endpos;
		end.z -= 2;

		cstrike.m_engine_trace->TraceRay(Ray(data.origin, end, mins, max), MASK_SOLID, &filter, &trace);

		data.flags &= ~FL_ONGROUND;

		if (trace.hit() && trace.m_plane.m_normal.z >= MIN_STEP_NORMAL) {
			data.flags |= FL_ONGROUND;
		}

		if (data.flags & FL_ONGROUND)
			data.velocity.z = 0;
		else
			data.velocity.z -= cstrike.m_globals->m_interval * sv_gravity->get_float() * 0.5f;
	}
}

bool c_lag_compensation::extrapolate(c_base_player* entity, c_lag_record* record, float time, c_aim_player* data)
{
	//const int player_index = entity->index();
	//const float time_delta = time - record->m_curtime;

	//static auto sv_gravity = cstrike.m_cvar->find_var(HASH("sv_gravity"));
	//static auto sv_jump_impulse = cstrike.m_cvar->find_var(HASH("sv_jump_impulse"));

	///// need 3 records to extrapolate
	//if (data->m_records.size() < 3)
	//	return false;

	///// to check if ground is below the nigger, and speed is per second
	//auto IsObjectInWay = [](vec3_t origin, vec3_t velocity, vec3_t& end) -> bool
	//{
	//	c_game_trace trace;
	//	c_trace_filter_world_only filter;
	//	//SDK::Ray_t ray;
	////	ray.Init(origin, origin + (velocity * INTERFACES::Globals->interval_per_tick));

	//	cstrike.m_engine_trace->TraceRay(Ray(origin, origin + (velocity * cstrike.m_globals->m_interval)), MASK_ALL, &filter, &trace);

	//	end = trace.m_endpos;

	//	return trace.m_fraction < 1.f;
	//};

	//auto record_1 = data->m_records[0].get(), record_2 = data->m_records[1].get(), record_3 = data->m_records[2].get();
	//record = record_1;

	///// velocity and acceleration are per second, not per tick
	//vec3_t velocity = record->m_velocity;
	//vec3_t acceleration = ((record_1->m_velocity - record_2->m_velocity) + (record_2->m_velocity - record_3->m_velocity)) / (record_1->m_sim_time - record_2->m_sim_time);
	//acceleration.z = -sv_gravity->get_float();

	//bool was_object_in_way_last_tick = false;
	//float curtime = record->m_sim_time;
	//while (curtime < time)
	//{
	//	vec3_t vel_change = velocity * cstrike.m_globals->m_interval;

	//	record->m_origin += vel_change;
	//	record->m_maxs += vel_change;
	//	record->m_mins += vel_change;

	//	velocity += acceleration * cstrike.m_globals->m_interval;

	//	vec3_t end;
	//	if (IsObjectInWay(record->m_origin, velocity, end))
	//	{
	//		record->m_origin = end;

	//		if (!was_object_in_way_last_tick)
	//			velocity.z = sv_jump_impulse->get_float();
	//		else
	//			break;

	//		was_object_in_way_last_tick = true;
	//	}
	//	else
	//		was_object_in_way_last_tick = false;

	//	curtime += cstrike.m_globals->m_interval;
	//}

	return false;
}

