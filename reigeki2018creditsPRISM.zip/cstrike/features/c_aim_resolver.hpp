#pragma once

class shot_record_t;

class c_aim_resolver {
public:
	enum resolver_mode : size_t {
		none = 0,
		walking_mode,
		standing_mode,
		lastmove_mode,
		bruteforce_mode,
		in_air_mode,
		lby_yaw_mode,
		stopped_moving_mode,
		freestand_mode,
		unknown_mode
	};

public:
	c_lag_record* find_ideal_record(c_aim_player* data);
	c_lag_record* find_last_record(c_aim_player* data);

	//c_lag_record* FindFirstRecord(c_aim_player* data );

	void on_body_update(c_base_player* player, float value);
	float get_away_angle(c_lag_record* record);

	void match_shot(c_aim_player* data, c_lag_record* record);
	void anti_freestand(c_lag_record* record);
	void set_mode(c_lag_record* record);

	void resolve_angles(c_base_player* player, c_lag_record* record);
	void resolve_walk(c_aim_player* data, c_lag_record* record);
	float get_lby_rotate(float lby, float yaw);
	bool detect_sideways(c_base_player* entity, float yaw);
	float get_direction_angle(int index, c_base_player* player);
	void resolve_by_bruteforce(c_lag_record* record, c_base_player* player, c_aim_player* data);
	void init_resolver(c_lag_record* record, c_aim_player* data, c_base_player* player);
	void apply_stand_nospread(c_aim_player* data, c_lag_record* record);
	void resolve_air(c_aim_player* data, c_lag_record* record, c_base_player* player);


	void apply_air_nospread(c_aim_player* data, c_lag_record* record);
	void resolve_poses(c_base_player* player, c_lag_record* record);

public:
	std::array< vec3_t, 64 > m_impacts;
	int	   m_players[64];
	bool   m_step_switch;
	int    m_random_lag;
	float  m_next_random_update;
	float  m_random_angle;
	float  m_direction;
	float  m_auto;
	float  m_auto_dist;
	float  m_auto_last;
	float  m_view;

	class c_player_resolve_record
	{
	public:
		struct anti_freestand_record_t
		{
			int right_damage = 0, left_damage = 0;
			float right_fraction = 0.f, left_fraction = 0.f;
		};

	public:
		anti_freestand_record_t m_anti_edge;
	};

	c_player_resolve_record player_resolve_records[33];
};

extern c_aim_resolver resolver;