#include "../project.hpp"

c_bones	bonesetup{ };;
c_animation_sync animations{ };;

void c_aim_player::update_enemy_animations(c_lag_record* record) {
	c_animation_state* state = m_player->m_PlayerAnimState();
	if (!state)
		return;

	// player respawned.
	if (m_player->m_flSpawnTime() != m_spawn) {
		// reset animation state.
		game::reset_animation_state(state);

		// note new spawn time.
		m_spawn = m_player->m_flSpawnTime();
	}

	// backup curtime.
	float curtime = cstrike.m_globals->m_curtime;
	float frametime = cstrike.m_globals->m_frametime;

	// set curtime to animtime.
	// set frametime to ipt just like on the server during simulation.
	cstrike.m_globals->m_curtime = record->m_anim_time;
	cstrike.m_globals->m_frametime = cstrike.m_globals->m_interval;

	// backup stuff that we do not want to fuck with.
	animation_backup_t backup;

	backup.m_origin = m_player->m_vecOrigin();
	backup.m_abs_origin = m_player->get_abs_origin();
	backup.m_velocity = m_player->m_vecVelocity();
	backup.m_abs_velocity = m_player->m_vecAbsVelocity();
	backup.m_flags = m_player->m_fFlags();
	backup.m_eflags = m_player->m_iEFlags();
	backup.m_duck = m_player->m_flDuckAmount();
	backup.m_body = m_player->m_flLowerBodyYawTarget();
	m_player->get_anim_layers(backup.m_layers);

	// is player a bot?
	bool bot = game::is_fake_player(m_player->index());

	// reset fakewalk state.
	record->m_fake_walk = false;
	record->m_mode = c_aim_resolver::resolver_mode::none;

	// fix velocity.
	// https://github.com/VSES/SourceEngine2007/blob/master/se2007/game/client/c_baseplayer.cpp#L659
	if (record->m_lag > 0 && record->m_lag < 16 && m_records.size() >= 2) {
		// get pointer to previous record.
		c_lag_record* previous = m_records[1].get();

		if (previous && !previous->dormant())
			record->m_velocity = (record->m_origin - previous->m_origin) * (1.f / game::ticks_to_time(record->m_lag));
	}

	// set this fucker, it will get overriden.
	record->m_anim_velocity = record->m_velocity;

	// fix various issues with the game eW91dHViZS5jb20vZHlsYW5ob29r
	// these issues can only occur when a player is choking data.
	if (record->m_lag > 1 && !bot) {
		// detect fakewalk.
		float speed = record->m_velocity.length();

		if (record->m_flags & FL_ONGROUND && record->m_layers[6].m_weight == 0.f && speed > 0.1f && speed < 120.f)
			record->m_fake_walk = true;

		if (record->m_fake_walk)
			record->m_anim_velocity = record->m_velocity = { 0.f, 0.f, 0.f };

		// we need atleast 2 updates/records
		// to fix these issues.
		if (m_records.size() >= 2) {
			// get pointer to previous record.
			c_lag_record* previous = m_records[1].get();

			if (previous && !previous->dormant()) {
				// set previous flags.
				m_player->m_fFlags() = previous->m_flags;

				// strip the on ground flag.
				m_player->m_fFlags() &= ~FL_ONGROUND;

				// been onground for 2 consecutive ticks? fuck yeah.
				if (record->m_flags & FL_ONGROUND && previous->m_flags & FL_ONGROUND)
					m_player->m_fFlags() |= FL_ONGROUND;

				//if( record->m_layers[ 4 ].m_weight != 0.f && previous->m_layers[ 4 ].m_weight == 0.f && record->m_layers[ 5 ].m_weight != 0.f )
				//	m_player->m_fFlags( ) |= FL_ONGROUND;

				// fix jump_fall.
				if (record->m_layers[4].m_weight != 1.f && previous->m_layers[4].m_weight == 1.f && record->m_layers[5].m_weight != 0.f)
					m_player->m_fFlags() |= FL_ONGROUND;

				if (record->m_flags & FL_ONGROUND && !(previous->m_flags & FL_ONGROUND))
					m_player->m_fFlags() &= ~FL_ONGROUND;

				// fix crouching players.
				// the duck amount we receive when people choke is of the last simulation.
				// if a player chokes packets the issue here is that we will always receive the last duckamount.
				// but we need the one that was animated.
				// therefore we need to compute what the duckamount was at animtime.

				// delta in duckamt and delta in time..
				float duck = record->m_duck - previous->m_duck;
				float time = record->m_sim_time - previous->m_sim_time;

				// get the duckamt change per tick.
				float change = (duck / time) * cstrike.m_globals->m_interval;

				// fix crouching players.
				m_player->m_flDuckAmount() = previous->m_duck + change;

				if (!record->m_fake_walk) {
					// fix the velocity till the moment of animation.
					vec3_t velo = record->m_velocity - previous->m_velocity;

					// accel per tick.
					vec3_t accel = (velo / time) * cstrike.m_globals->m_interval;

					// set the anim velocity to the previous velocity.
					// and predict one tick ahead.
					record->m_anim_velocity = previous->m_velocity + accel;
				}
			}
		}
	}

	// // better fake angle detection.
	// size_t consistency{};
	// size_t size = std::min( 5u, m_records.size( ) );
	// 
	// for( size_t i{}; i < size; i++ ) {
	//     // if we have lag on this record.
	//     if( m_records[ i ].get( )->m_lag > 1 )
	//         ++consistency;
	// }
	// 
	// // compute lag consistency scale.
	// float scale = ( float )consistency / ( float )size;
	// 
	// // if faking angles more than 80% of the time
	// // and not bot, player uses fake angles.
	// bool fake = g_menu.main.aimbot.correct.get( ) && !bot && scale > 0.8f;

	// size_t consistency{ 0u };
	// size_t size{ m_records.size( ) };
	// 
	// // add up records the player didn't lag.
	// for( size_t i{ 0u }; i < size; i++ ) {
	//     if( m_records[ i ].get( )->m_lag < 1 )
	//         ++consistency;
	// }
	// 
	// // compute lag consistency scale.
	// float scale = ( float )consistency / size;
	// 
	// // lagged too much.
	// bool fake = !bot && scale < 0.5f;

	bool fake = record->m_shot ? !bot && g_cfg[XOR("aimbot_fix_fake")].get< bool >() : (record->m_eye_angles.x < -60 || record->m_eye_angles.x > 60) && record->m_lag > 0 && !bot && g_cfg[XOR("aimbot_fix_fake")].get< bool >();

	// if using fake angles, correct angles.
	if (fake)
		resolver.resolve_angles(m_player, record);

	// set stuff before animating.
	m_player->m_vecOrigin() = record->m_origin;
	m_player->m_vecVelocity() = m_player->m_vecAbsVelocity() = record->m_anim_velocity;
	m_player->m_flLowerBodyYawTarget() = record->m_body;

	// EFL_DIRTY_ABSVELOCITY
	// skip call to C_BaseEntity::CalcAbsoluteVelocity
	m_player->m_iEFlags() &= ~0x1000;

	// write potentially resolved angles.
	m_player->m_angEyeAngles() = record->m_eye_angles;

	// fix animating in same frame.
	if (state->m_frame == cstrike.m_globals->m_frame)
		state->m_frame -= 1;

	// 'm_animating' returns true if being called from SetupVelocity, passes raw velocity to animstate.
	m_player->m_bClientSideAnimation() = true;
	m_player->update_clientside_animation();
	m_player->m_bClientSideAnimation() = false;

	// correct poses if fake angles.
	if (fake)
		resolver.resolve_poses(m_player, record);

	// store updated/animated poses and rotation in lagrecord.
	m_player->get_pose_parameters(record->m_poses);
	record->m_abs_ang = m_player->get_abs_angles();

	// restore backup data.
	m_player->m_vecOrigin() = backup.m_origin;
	m_player->m_vecVelocity() = backup.m_velocity;
	m_player->m_vecAbsVelocity() = backup.m_abs_velocity;
	m_player->m_fFlags() = backup.m_flags;
	m_player->m_iEFlags() = backup.m_eflags;
	m_player->m_flDuckAmount() = backup.m_duck;
	m_player->m_flLowerBodyYawTarget() = backup.m_body;
	m_player->set_abs_origin(backup.m_abs_origin);
	m_player->set_anim_layers(backup.m_layers);

	// IMPORTANT: do not restore poses here, since we want to preserve them for rendering.
	// also dont restore the render angles which indicate the model rotation.

	// restore globals.
	cstrike.m_globals->m_curtime = curtime;
	cstrike.m_globals->m_frametime = frametime;
}

void c_animation_sync::predict_animations(c_animation_state* state, c_lag_record* record) {
	struct AnimBackup_t {
		float  curtime;
		float  frametime;
		int    flags;
		int    eflags;
		vec3_t velocity;
	};

	// get player ptr.
	c_base_player* player = record->m_player;

	// backup data.
	AnimBackup_t backup;
	backup.curtime = cstrike.m_globals->m_curtime;
	backup.frametime = cstrike.m_globals->m_frametime;
	backup.flags = player->m_fFlags();
	backup.eflags = player->m_iEFlags();
	backup.velocity = player->m_vecAbsVelocity();

	// set globals appropriately for animation.
	cstrike.m_globals->m_curtime = record->m_pred_time;
	cstrike.m_globals->m_frametime = cstrike.m_globals->m_interval;

	// EFL_DIRTY_ABSVELOCITY
	// skip call to C_BaseEntity::CalcAbsoluteVelocity
	player->m_iEFlags() &= ~0x1000;

	// set predicted flags and velocity.
	player->m_fFlags() = record->m_pred_flags;
	player->m_vecAbsVelocity() = record->m_pred_velocity;

	// enable re-animation in the same frame if animated already.
	if (state->m_frame >= cstrike.m_globals->m_frame)
		state->m_frame = cstrike.m_globals->m_frame - 1;

	bool fake = g_cfg[XOR("aimbot_fix_fake")].get< bool >();

	// rerun the resolver since we edited the origin.
	if (fake)
		resolver.resolve_angles(player, record);

	// update animations.
	game::update_animation_state(state, record->m_eye_angles);

	// rerun the pose correction cuz we are re-setupping them.
	if (fake)
		resolver.resolve_poses(player, record);

	// get new rotation poses and layers.
	player->get_pose_parameters(record->m_poses);
	player->get_anim_layers(record->m_layers);
	record->m_abs_ang = player->get_abs_angles();

	// restore globals.
	cstrike.m_globals->m_curtime = backup.curtime;
	cstrike.m_globals->m_frametime = backup.frametime;

	// restore player data.
	player->m_fFlags() = backup.flags;
	player->m_iEFlags() = backup.eflags;
	player->m_vecAbsVelocity() = backup.velocity;

}


void c_animation_sync::update_local_animations() {
	if (!ctx.m_local || !ctx.m_processing)
		return;

	c_animation_state* state = ctx.m_local->m_PlayerAnimState();
	if (!state)
		return;

	//get standing view
	vec3_t stand_eye_pos = cstrike.m_game_movement->get_player_view_offset(false);
	vec3_t duck_eye_pos = cstrike.m_game_movement->get_player_view_offset(true);

	// fix model folding
	if (!visuals.m_thirdperson && state->m_land && !GetAsyncKeyState(0x20)) {
		if (ctx.m_local->m_bDucking()) {
			ctx.m_local->modify_eye_position(state, &duck_eye_pos);
			hook_handler.m_UpdateClientSideAnimation(ctx.m_local);

			// stop landing animation.
			ctx.m_local->m_AnimOverlay()[5].m_weight = 0.f;

			// prevent model sway on player.
			ctx.m_local->m_AnimOverlay()[12].m_weight = 0.f;

			// update animations with last networked data.
			ctx.m_local->set_pose_parameters(ctx.m_poses);

			// update abs yaw with last networked abs yaw.
			ctx.m_local->set_abs_angles(ang_t(0.f, ctx.m_abs_yaw, 0.f));
		}
		else {
			ctx.m_local->modify_eye_position(state, &stand_eye_pos);
			hook_handler.m_UpdateClientSideAnimation(ctx.m_local);

			// stop landing animation.
			ctx.m_local->m_AnimOverlay()[5].m_weight = 0.f;

			// prevent model sway on player.
			ctx.m_local->m_AnimOverlay()[12].m_weight = 0.f;

			// update animations with last networked data.
			ctx.m_local->set_pose_parameters(ctx.m_poses);

			// update abs yaw with last networked abs yaw.
			ctx.m_local->set_abs_angles(ang_t(0.f, ctx.m_abs_yaw, 0.f));
		}

	}

	//sync attachments with player position.
	static const auto jiggle_bones = cstrike.m_cvar->find_var(HASH("r_jiggle_bones"));
	jiggle_bones->set_value(0);

	// prevent model sway on player.
	ctx.m_local->m_AnimOverlay()[12].m_weight = 0.f;

	// update animations with last networked data.
	ctx.m_local->set_pose_parameters(ctx.m_poses);

	// stop falling animation.
	//g_cl.m_local->m_AnimOverlay()[4].m_weight = 0.f;

	// update abs yaw with last networked abs yaw.
	ctx.m_local->set_abs_angles(ang_t(0.f, ctx.m_abs_yaw, 0.f));
}


void c_ctx::update_clientside_information() {
	if (ctx.m_lag > 0)
		return;

	c_animation_state* state = ctx.m_local->m_PlayerAnimState();
	if (!state)
		return;

	// update time.
	m_anim_frame = cstrike.m_globals->m_curtime - m_anim_time;
	m_anim_time = cstrike.m_globals->m_curtime;

	// current angle will be animated.
	m_angle = ctx.m_cmd->m_view_angles;

	// fix landing anim.
	if (state->m_land && !state->m_dip_air && state->m_dip_cycle > 0.f)
		m_angle.x = -12.f;

	math::clamp(m_angle.x, -90.f, 90.f);
	m_angle.normalize();

	// write angles to model.
	cstrike.m_prediction->set_local_view_angles(m_angle);

	// set lby to predicted value.
	ctx.m_local->m_flLowerBodyYawTarget() = m_body;


	// CCSGOPlayerAnimState::Update, bypass already animated checks.
	if (state->m_frame == cstrike.m_globals->m_frame)
		state->m_frame -= 1;

	// call original, bypass hook.
	if (hook_handler.m_UpdateClientSideAnimation) //not real fix but why not
		hook_handler.m_UpdateClientSideAnimation(ctx.m_local);

	// get last networked poses.
	ctx.m_local->get_pose_parameters(ctx.m_poses);

	// store updated abs yaw.
	ctx.m_abs_yaw = state->m_goal_feet_yaw;

	// we landed.
	if (!m_ground && state->m_ground) {
		m_body = m_angle.y;
		m_body_pred = m_anim_time;
	}

	// walking, delay lby update by .22.
	else if (state->m_speed > 0.1f) {
		if (state->m_ground)
			m_body = m_angle.y;

		m_body_pred = m_anim_time + 0.22f;
	}

	// standing update every 1.1s
	else if (m_anim_time > m_body_pred) {
		m_body = m_angle.y;
		m_body_pred = m_anim_time + 1.1f;
	}

	// save updated data.
	m_rotation = ctx.m_local->m_angAbsRotation();
	m_speed = state->m_speed;
	m_ground = state->m_ground;
}

bool c_bones::setup(c_base_player* player, c_bone_array* out, c_lag_record* record) {
	// if the record isnt setup yet.
	if (!record->m_setup) {
		// run setupbones rebuilt.
		if (!build_bones(player, 0x7FF00, record->m_bones, record))
			return false;

		// we have setup this record bones.
		record->m_setup = true;
	}

	// record is setup.
	if (out && record->m_setup)
		std::memcpy(out, record->m_bones, sizeof(c_bone_array) * 128);

	return true;
}

bool c_bones::build_bones(c_base_player* target, int mask, c_bone_array* out, c_lag_record* record) {
	vec3_t		     pos[128];
	quaternion_t     q[128];
	vec3_t           backup_origin;
	ang_t            backup_angles;
	float            backup_poses[24];
	c_animation_layer backup_layers[13];

	// get hdr.
	c_studio_hdr* hdr = target->get_model_ptr();
	if (!hdr)
		return false;

	// get ptr to bone accessor.
	c_bone_accessor* accessor = &target->m_BoneAccessor();
	if (!accessor)
		return false;

	// store origial output matrix.
	// likely cachedbonedata.
	c_bone_array* backup_matrix = accessor->m_pBones;
	if (!backup_matrix)
		return false;

	// prevent the game from calling ShouldSkipAnimationFrame.
	auto bSkipAnimationFrame = *reinterpret_cast<int*>(uintptr_t(target) + 0x260);
	*reinterpret_cast<int*>(uintptr_t(target) + 0x260) = NULL;

	// backup original.
	backup_origin = target->get_abs_origin();
	backup_angles = target->get_abs_angles();
	target->get_pose_parameters(backup_poses);
	target->get_anim_layers(backup_layers);

	// compute transform from raw data.
	matrix3x4_t transform;
	math::angle_matrix(record->m_abs_ang, record->m_pred_origin, transform);

	// set non interpolated data.
	target->add_effect(EF_NOINTERP);
	target->set_abs_origin(record->m_pred_origin);
	target->set_abs_angles(record->m_abs_ang);
	target->set_pose_parameters(record->m_poses);
	target->set_anim_layers(record->m_layers);

	// force game to call AccumulateLayers - pvs fix.
	m_running = true;

	// set bone array for write.
	accessor->m_pBones = out;

	// compute and build bones.
	target->standard_blending_rules(hdr, pos, q, record->m_pred_time, mask);

	uint8_t computed[0x100];
	std::memset(computed, 0, 0x100);
	target->build_transformations(hdr, pos, q, transform, mask, computed);

	// restore old matrix.
	accessor->m_pBones = backup_matrix;

	// restore original interpolated entity data.
	target->set_abs_origin(backup_origin);
	target->set_abs_angles(backup_angles);
	target->set_pose_parameters(backup_poses);
	target->set_anim_layers(backup_layers);

	// revert to old game behavior.
	m_running = false;

	// allow the game to call ShouldSkipAnimationFrame.
	*reinterpret_cast<int*>(uintptr_t(target) + 0x260) = bSkipAnimationFrame;

	return true;
}