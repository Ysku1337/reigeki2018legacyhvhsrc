#include "../project.hpp"

void c_aimbot_system::knife() {
	struct KnifeTarget_t { bool stab; ang_t angle; c_lag_record* record; };
	KnifeTarget_t target{};

	// we have no targets.
	if (m_targets.empty())
		return;

	// iterate all targets.
	for (const auto& t : m_targets) {
		// this target has no records
		// should never happen since it wouldnt be a target then.
		if (t->m_records.empty())
			continue;

		// see if target broke lagcomp.
		if (g_cfg[ XOR( "aimbot_fix_lag" ) ].get< bool >( ) && lagcomp.start_lag_compensation(t)) {
			c_lag_record* front = t->m_records.front().get();

			front->cache();

			// trace with front.
			for (const auto& a : m_knife_ang) {

				// check if we can knife.
				if (!can_knife(front, a, target.stab))
					continue;

				// set target data.
				target.angle = a;
				target.record = front;
				break;
			}
		}

		// we can history aim.
		else {

			c_lag_record* best = resolver.find_ideal_record(t);
			if (!best)
				continue;

			best->cache();

			// trace with best.
			for (const auto& a : m_knife_ang) {

				// check if we can knife.
				if (!can_knife(best, a, target.stab))
					continue;

				// set target data.
				target.angle = a;
				target.record = best;
				break;
			}

			c_lag_record* last = resolver.find_last_record(t);
			if (!last || last == best)
				continue;

			last->cache();

			// trace with last.
			for (const auto& a : m_knife_ang) {

				// check if we can knife.
				if (!can_knife(last, a, target.stab))
					continue;

				// set target data.
				target.angle = a;
				target.record = last;
				break;
			}
		}

		// target player has been found already.
		if (target.record)
			break;
	}

	// we found a target.
	// set out data and choke.
	if (target.record) {
		// set target tick.
		ctx.m_cmd->m_tick = game::time_to_ticks(target.record->m_pred_time + ctx.m_lerp);

		// set view angles.
		ctx.m_cmd->m_view_angles = target.angle;

		// set attack1 or attack2.
		ctx.m_cmd->m_buttons |= target.stab ? IN_ATTACK2 : IN_ATTACK;

		// choke. 
		*ctx.m_packet = false;
	}
}

bool c_aimbot_system::can_knife(c_lag_record* record, ang_t angle, bool& stab) {
	// convert target angle to direction.
	vec3_t forward;
	math::angle_vectors(angle, &forward);

	// see if we can hit the player with full range
	// this means no stab.
	c_game_trace trace;
	knife_trace(forward, false, &trace);

	// we hit smthing else than we were looking for.
	if (!trace.m_entity || trace.m_entity != record->m_player)
		return false;

	bool armor = record->m_player->m_ArmorValue() > 0;
	bool first = ctx.m_weapon->m_flNextPrimaryAttack() + 0.4f < cstrike.m_globals->m_curtime;
	bool back = knife_is_behind(record);

	int stab_dmg = m_knife_dmg.stab[armor][back];
	int slash_dmg = m_knife_dmg.swing[first][armor][back];
	int swing_dmg = m_knife_dmg.swing[false][armor][back];

	// smart knifebot.
	int health = record->m_player->m_iHealth();
	if (health <= slash_dmg)
		stab = false;

	else if (health <= stab_dmg)
		stab = true;

	else if (health > (slash_dmg + swing_dmg + stab_dmg))
		stab = true;

	else
		stab = false;

	// damage wise a stab would be sufficient here.
	if (stab && !knife_trace(forward, true, &trace))
		return false;

	return true;
}

bool c_aimbot_system::knife_trace(vec3_t dir, bool stab, c_game_trace* trace) {
	float range = stab ? 32.f : 48.f;

	vec3_t start = ctx.m_shoot_pos;
	vec3_t end = start + (dir * range);

	c_trace_filter_simple filter;
	filter.set_pass_entity(ctx.m_local);
	cstrike.m_engine_trace->TraceRay(Ray(start, end), MASK_SOLID, &filter, trace);

	// if the above failed try a hull trace.
	if (trace->m_fraction >= 1.f) {
		cstrike.m_engine_trace->TraceRay(Ray(start, end, { -16.f, -16.f, -18.f }, { 16.f, 16.f, 18.f }), MASK_SOLID, &filter, trace);
		return trace->m_fraction < 1.f;
	}

	return true;
}

bool c_aimbot_system::knife_is_behind(c_lag_record* record) {
	vec3_t delta{ record->m_origin - ctx.m_shoot_pos };
	delta.z = 0.f;
	delta.normalize();

	vec3_t target;
	math::angle_vectors(record->m_abs_ang, &target);
	target.z = 0.f;

	return delta.dot(target) > 0.475f;
}