#pragma once

class Chams {
public:
	enum model_type_t : uint32_t {
		invalid = 0,
		player,
		weapon,
		arms,
		view_weapon
	};

	enum color_type_t : uint32_t {
		normal,
		envmap_tint
	};

	struct Hitdata_t {
		c_bone_array* m_last_pose;
		int time;
		c_base_player* ent;
	};

public:
	void SetColor( Color col, color_type_t type );
	void SetAlpha( float alpha, i_material* mat = nullptr );
	void SetupMaterial(i_material* mat, Color col, bool z_flag );

	void init( );

	void DrawShotRecord(c_base_player* ent, uintptr_t ctx, const draw_model_state_t& state, const model_render_info_t& info, matrix3x4_t* bone );
	bool GenerateLerpedMatrix( int index, c_bone_array* out );
	void RenderHistoryChams( int index );
	void ApplyChams( std::string material, std::string color, float alpha, int material_flag, bool flag_value, uintptr_t context, const draw_model_state_t& state, const model_render_info_t& info, matrix3x4_t* bone,  bool chams_background = false );
	bool DrawModel( uintptr_t context, const draw_model_state_t& state, const model_render_info_t& info, matrix3x4_t* bone );
	void SceneEnd( );
	bool IsInViewPlane( const vec3_t& world );
	bool SortPlayers( );

public:
	std::vector< c_base_player* > m_players;
	bool m_running;
	i_material* debugambientcube;
	i_material* debugdrawflat;
	i_material* silhouette;
	std::vector< Hitdata_t > m_hits[ 65 ];
	c_bone_array m_stored_matrices[ 65 ] [ 128 ];
};

extern Chams chams;