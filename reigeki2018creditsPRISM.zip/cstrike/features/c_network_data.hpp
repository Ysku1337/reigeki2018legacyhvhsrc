#pragma once

class c_network_data {
private:
	class stored_data_t {
	public:
		int    m_tickbase;
		ang_t  m_punch;
		ang_t  m_punch_vel;
		vec3_t m_view_offset;

	public:
		__forceinline stored_data_t() : m_tickbase{}, m_punch{}, m_punch_vel{}, m_view_offset{} {};
	};

	std::array< stored_data_t, MULTIPLAYER_BACKUP > m_data;

public:
	void store();
	void apply();
	void reset();
};

extern c_network_data netdata;