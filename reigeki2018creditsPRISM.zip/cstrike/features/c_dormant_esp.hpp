#pragma once

class c_dormant_esp {
private:
	struct dormancy_data
	{
		c_base_player* m_entity;
		bool	m_prevstate;
		bool	m_set;
		int		m_flags;
		vec3_t	m_oldpos = vec3_t(0.f, 0.f, 0.f);
		struct {
			int m_time;
		} m_sound_data;
	};
public:
	void position_correction(int stage);
	bool set(const int index);

	bool is_visible(c_base_player* entity);

	void sound_dormancy();
	void adjust_player(const int index);

	CUtlVector< i_engine_sound::sound_info > soundbuffer;
	CUtlVector< i_engine_sound::sound_info > sound_list;

	dormancy_data m_players[65];

}; extern c_dormant_esp dormancy;