#include "../project.hpp"

#define range( x, a, b )    ( x >= a && x <= b )

c_dormant_esp dormancy{ };

void c_dormant_esp::position_correction(int stage)
{
	if (!ctx.m_processing)
		return;

	for (int i = 1; i <= 64; i++) {
		auto entity = reinterpret_cast<c_base_player*>(cstrike.m_entlist->get_client_entity(i));

		if (entity == ctx.m_local)
			continue;

		if (!is_visible(entity))
			continue;

		if (!entity->is_dormant() && !m_players[i].m_set)
			m_players[i].m_oldpos = entity->m_vecOrigin();

		if (!entity->is_dormant() || m_players[i].m_set)
			continue;

		entity->set_abs_origin(m_players[i].m_oldpos);
	}
}

bool c_dormant_esp::set(const int index)
{
	if (!range(index, 1, 64))
		return false;

	return m_players[index].m_set;
}

bool c_dormant_esp::is_visible(c_base_player* entity)
{
	if (!entity)
		return false;

	if (!ctx.m_processing)
		return false;

	if (!entity->alive() || entity->m_fFlags() & (1 << 6))
		return false;

	if (entity->m_iTeamNum() == ctx.m_local->m_iTeamNum())
		return false;

	//if (entity->m_bGunGameImmunity())
	//	return false;

	return true;
}

void c_dormant_esp::sound_dormancy()
{
	if (!ctx.m_processing)
		return;

	sound_list.RemoveAll();
	cstrike.m_sound->get_active_sounds(sound_list);

	if (!sound_list.Count())
		return;

	for (int i = 0; i < sound_list.Count(); i++) {
		i_engine_sound::sound_info& sound = sound_list[i];
		if (!range(sound.sound_source, 1, 64))
			continue;

		if (sound.sound_source == cstrike.m_engine->get_local_player())
			continue;

		auto entity = reinterpret_cast<c_base_player*>(cstrike.m_entlist->get_client_entity(sound.sound_source));

		if (!entity || !sound.origin->valid())
			continue;

		auto& player = m_players[sound.sound_source];
		player.m_entity = entity;


		vec3_t src_3d, dst_3d;
		c_game_trace tr;
		c_trace_filter filter;

		filter.skip_entity = entity;
		src_3d = (*sound.origin) + vec3_t(0, 0, 1);
		dst_3d = src_3d - vec3_t(0, 0, 100);

		cstrike.m_engine_trace->TraceRay(Ray(src_3d, dst_3d), MASK_PLAYERSOLID, &filter, &tr);

		if (tr.m_allsolid) // if stuck
			player.m_sound_data.m_time = -1;

		*sound.origin = ((tr.m_fraction < 0.97) ? tr.m_endpos : *sound.origin);
		player.m_flags = entity->m_fFlags();
		player.m_flags |= (tr.m_fraction < 0.50f ? (1 << 1) /*ducking*/ : 0) | (tr.m_fraction != 1 ? (1 << 0) /*on ground*/ : 0);
		player.m_flags &= (tr.m_fraction > 0.50f ? ~(1 << 1) /*ducking*/ : 0) | (tr.m_fraction == 1 ? ~(1 << 0) /*on ground*/ : 0);

		player.m_oldpos = *sound.origin;
		player.m_sound_data.m_time = GetTickCount();

		if (!entity->is_dormant())
			continue;

		adjust_player(sound.sound_source);
	}

	soundbuffer = sound_list;
}

void c_dormant_esp::adjust_player(const int index)
{
	//	if ( !g_cfg[ XOR( "esp_dormant" ) ].get< bool >( ) )
	//		return;

	if (!ctx.m_processing)
		return;

	auto& player = m_players[index];

	static int duration = 1000;
	bool expired = GetTickCount() - player.m_sound_data.m_time > duration;

	if (expired)
		player.m_set = false;

	if (!expired)
		player.m_set = true;

	// dormant check
	player.m_entity->m_fFlags() = player.m_flags;
	player.m_entity->m_vecOrigin() = player.m_oldpos;
	player.m_entity->set_abs_origin(player.m_oldpos);
}

