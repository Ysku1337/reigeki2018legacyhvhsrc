#pragma once

class c_aimbot_system {
private:
	struct target_t {
		c_base_player* m_player;
		c_aim_player* m_data;
	};

	struct knife_target_t {
		target_t     m_target;
		c_lag_record m_record;
	};

	struct table_t {
		uint8_t swing[2][2][2]; // [ first ][ armor ][ back ]
		uint8_t stab[2][2];		  // [ armor ][ back ]
	};

	const table_t m_knife_dmg{ { { { 25, 90 }, { 21, 76 } }, { { 40, 90 }, { 34, 76 } } }, { { 65, 180 }, { 55, 153 } } };

	std::array< ang_t, 12 > m_knife_ang{
		ang_t{ 0.f, 0.f, 0.f }, ang_t{ 0.f, -90.f, 0.f }, ang_t{ 0.f, 90.f, 0.f }, ang_t{ 0.f, 180.f, 0.f },
		ang_t{ -80.f, 0.f, 0.f }, ang_t{ -80.f, -90.f, 0.f }, ang_t{ -80.f, 90.f, 0.f }, ang_t{ -80.f, 180.f, 0.f },
		ang_t{ 80.f, 0.f, 0.f }, ang_t{ 80.f, -90.f, 0.f }, ang_t{ 80.f, 90.f, 0.f }, ang_t{ 80.f, 180.f, 0.f }
	};

	struct hitbox_config_t {
		bool head;
		bool neck;
		bool upper_chest;
		bool stomach;
		bool body;
		bool legs;
		bool feet;
	};

public:
	std::array< c_aim_player, 64 > m_players;
	std::vector< c_aim_player* >   m_targets;

	c_backup_record m_backup[64];

	// target selection stuff.
	float m_best_dist;
	float m_best_fov;
	float m_best_damage;
	int   m_best_hp;
	float m_best_lag;
	float m_best_height;

	// found target stuff.
	c_base_player* m_target;
	ang_t         m_angle;
	vec3_t        m_aim;
	float         m_damage;
	c_lag_record* m_record;

	// fake latency stuff.
	bool       m_fake_latency;

	bool m_stop;
	bool m_override_damage;
	bool m_force_body;

	// settings.
	int m_minimum_damage;
	int m_minimum_penetration_damage;
	int m_minimum_hitchance;
	int m_overriden_hitchance;
	int m_overriden_damage;
	bool m_enable;
	bool m_override_hitboxes;
	bool m_autostop;
	int m_headscale;
	int m_bodyscale;
	int m_autostop_mode;
	bool m_autoscope;
	bool m_between_shots;
	bool m_force_accuracy;
	bool m_in_air;
	bool m_duck;

	bool m_body_in_air;
	bool m_body_on_crouch;
	bool m_body_lethal;
	bool m_body_lethal2;

	int m_priority_hitbox;

	hitbox_config_t m_normal_hitboxes;
	hitbox_config_t m_multipoint_hitboxes;

public:
	__forceinline void reset() {
		// reset aimbot data.
		init();

		// reset all players data.
		for (auto& p : m_players)
			p.reset();
	}

	__forceinline bool is_valid_target(c_base_player* player) {
		if (!player)
			return false;

		if (!player->is_player())
			return false;

		if (!player->alive())
			return false;

		if (player->is_local_player())
			return false;

		if (!player->enemy(ctx.m_local))
			return false;

		return true;
	}

public:
	// aimbot.
	void init();
	void strip_attack();
	void think();
	void find();
	bool check_hitchance(c_base_player* player, const ang_t& angle);
	bool select_target(c_lag_record* record, const vec3_t& aim, float damage);
	void apply();
	void apply_nospread();

	void update_config();

	// knifebot.
	void knife();
	bool can_knife(c_lag_record* record, ang_t angle, bool& stab);
	bool knife_trace(vec3_t dir, bool stab, c_game_trace* trace);
	bool knife_is_behind(c_lag_record* record);
};

extern c_aimbot_system aimbot;