#include "../project.hpp"

void c_aim_player::on_net_update(c_base_player* player) {
	bool reset = (!g_cfg[XOR("aimbot_enable")].get< bool >() || player->m_lifeState() == LIFE_DEAD || !player->enemy(ctx.m_local));
	bool disable = (!reset && !ctx.m_processing);

	// if this happens, delete all the lagrecords.
	if (reset) {
		player->m_bClientSideAnimation() = true;
		m_records.clear();
		return;
	}

	// just disable anim if this is the case.
	if (disable) {
		player->m_bClientSideAnimation() = true;
		return;
	}

	// update player ptr if required.
	// reset player if changed.
	if (m_player != player)
		m_records.clear();

	// update player ptr.
	m_player = player;

	// indicate that this player has been out of pvs.
	// insert dummy record to separate records
	// to fix stuff like animation and prediction.
	if (player->is_dormant()) {
		bool insert = true;

		// we have any records already?
		if (!m_records.empty()) {

			c_lag_record* front = m_records.front().get();

			// we already have a dormancy separator.
			if (front->dormant())
				insert = false;
		}

		if (insert) {
			// add new record.
			m_records.emplace_front(std::make_shared< c_lag_record >(player));

			// get reference to newly added record.
			c_lag_record* current = m_records.front().get();

			// mark as dormant.
			current->m_dormant = true;
		}
	}

	bool update = (m_records.empty() || player->m_flSimulationTime() > m_records.front().get()->m_sim_time);

	if (!update && !player->is_dormant() && player->m_vecOrigin() != player->m_vecOldOrigin()) {
		update = true;

		// fix data.
		player->m_flSimulationTime() = game::ticks_to_time(cstrike.m_cl->m_server_tick);
	}

	// this is the first data update we are receving
	// OR we received data with a newer simulation context.
	if (update) {
		// add new record.
		m_records.emplace_front(std::make_shared< c_lag_record >(player));

		// get reference to newly added record.
		c_lag_record* current = m_records.front().get();

		// mark as non dormant.
		current->m_dormant = false;

		// update animations on current record.
		// call resolver.
		update_enemy_animations(current);

		// create bone matrix for this record.
		bonesetup.setup(m_player, nullptr, current);
	}

	// no need to store insane amt of data.
	while (m_records.size() > 256)
		m_records.pop_back();
}

void c_aim_player::on_round_start(c_base_player* player) {
	m_player = player;
	m_walk_record = c_lag_record{ };
	m_shots = 0;
	m_missed_shots = 0;

	// reset stand and body index.
	m_stand_index = 0;
	m_bruteforce_index = 0;
	m_lby_yaw_index = 0;

	m_records.clear();
	m_hitboxes.clear();

	// IMPORTANT: DO NOT CLEAR LAST HIT SHIT.
}

void c_aim_player::setup_hitboxes(c_lag_record* record, bool history) {
	if (!record)
		return;

	// reset hitboxes.
	m_hitboxes.clear();

	if (ctx.m_weapon_id == ZEUS) {
		m_hitboxes.push_back({ HITBOX_BODY, hitscan_mode::prefer_mode });
		return;
	}



		if (aimbot.m_body_in_air && !(record->m_flags & FL_ONGROUND) && (aimbot.m_normal_hitboxes.body || aimbot.m_normal_hitboxes.stomach))
			m_hitboxes.push_back({ HITBOX_BODY, hitscan_mode::prefer_mode });

		if (aimbot.m_body_on_crouch && record->m_duck == 1 && (aimbot.m_normal_hitboxes.body || aimbot.m_normal_hitboxes.stomach))
			m_hitboxes.push_back({ HITBOX_BODY, hitscan_mode::prefer_mode });

		if (aimbot.m_body_lethal && (aimbot.m_normal_hitboxes.body || aimbot.m_normal_hitboxes.stomach))
			m_hitboxes.push_back({ HITBOX_BODY, hitscan_mode::lethal_mode });

		if (aimbot.m_body_lethal2 && (aimbot.m_normal_hitboxes.body || aimbot.m_normal_hitboxes.stomach))
			m_hitboxes.push_back({ HITBOX_BODY, hitscan_mode::lethal2_mode });

		if (aimbot.m_normal_hitboxes.head)
			m_hitboxes.push_back({ HITBOX_HEAD, aimbot.m_priority_hitbox == 0 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });

		if (aimbot.m_normal_hitboxes.neck)
			m_hitboxes.push_back({ HITBOX_NECK, aimbot.m_priority_hitbox == 1 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });

		if (aimbot.m_normal_hitboxes.upper_chest)
			m_hitboxes.push_back({ HITBOX_UPPER_CHEST, aimbot.m_priority_hitbox == 2 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });

		if (aimbot.m_normal_hitboxes.body) {
			m_hitboxes.push_back({ HITBOX_THORAX, aimbot.m_priority_hitbox == 3 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });
			m_hitboxes.push_back({ HITBOX_CHEST, aimbot.m_priority_hitbox == 3 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });
		}

		if (aimbot.m_normal_hitboxes.stomach) {
			m_hitboxes.push_back({ HITBOX_PELVIS, aimbot.m_priority_hitbox == 4 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode, });
			m_hitboxes.push_back({ HITBOX_BODY, aimbot.m_priority_hitbox == 4 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });
		}

		if (aimbot.m_normal_hitboxes.legs) {
			m_hitboxes.push_back({ HITBOX_L_THIGH, aimbot.m_priority_hitbox == 5 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });
			m_hitboxes.push_back({ HITBOX_R_THIGH, aimbot.m_priority_hitbox == 5 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });
			m_hitboxes.push_back({ HITBOX_L_CALF, aimbot.m_priority_hitbox == 5 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });
			m_hitboxes.push_back({ HITBOX_R_CALF, aimbot.m_priority_hitbox == 5 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });
		}

		if (aimbot.m_normal_hitboxes.feet) {
			m_hitboxes.push_back({ HITBOX_L_FOOT, aimbot.m_priority_hitbox == 6 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });
			m_hitboxes.push_back({ HITBOX_R_FOOT, aimbot.m_priority_hitbox == 6 ? hitscan_mode::prefer_mode : hitscan_mode::normal_mode });
		}
}

bool c_aim_player::setup_hitbox_points(c_lag_record* record, c_bone_array* bones, int index, std::vector< vec3_t >& points) {
	// reset points.
	points.clear();

	const model_t* model = m_player->get_model();
	if (!model)
		return false;

	studiohdr_t* hdr = cstrike.m_model_info->get_studio_model(model);
	if (!hdr)
		return false;

	mstudiohitboxset_t* set = hdr->get_hitbox_set(m_player->m_nHitboxSet());
	if (!set)
		return false;

	mstudiobbox_t* bbox = set->get_hitbox(index);
	if (!bbox)
		return false;

	// get hitbox scales.
	float scale = aimbot.m_headscale * 0.01;

	// big inair fix.
	if (!(record->m_pred_flags) & FL_ONGROUND)
		scale = 0.7f;

	float bscale = aimbot.m_bodyscale * 0.01;

	// these indexes represent boxes.
	if (bbox->m_radius <= 0.f) {
		// references: 
		//      https://developer.valvesoftware.com/wiki/Rotation_Tutorial
		//      CBaseAnimating::GetHitboxBonePosition
		//      CBaseAnimating::DrawServerHitboxes

		// convert rotation angle to a matrix.
		matrix3x4_t rot_matrix;
		cstrike.AngleMatrix(bbox->m_angle, rot_matrix);

		// apply the rotation to the entity input space (local).
		matrix3x4_t matrix;
		math::concat_transforms(bones[bbox->m_bone], rot_matrix, matrix);

		// extract origin from matrix.
		vec3_t origin = matrix.get_origin();

		// compute raw center point.
		vec3_t center = (bbox->m_mins + bbox->m_maxs) / 2.f;

		// the feet hiboxes have a side, heel and the toe.
		if (index == HITBOX_R_FOOT || index == HITBOX_L_FOOT) {
			float d1 = (bbox->m_mins.z - center.z) * 0.875f;

			// invert.
			if (index == HITBOX_L_FOOT)
				d1 *= -1.f;

			// side is more optimal then center.
			points.push_back({ center.x, center.y, center.z + d1 });

			if (aimbot.m_multipoint_hitboxes.feet) {
				// get point offset relative to center point
				// and factor in hitbox scale.
				float d2 = (bbox->m_mins.x - center.x) * scale;
				float d3 = (bbox->m_maxs.x - center.x) * scale;

				// heel.
				points.push_back({ center.x + d2, center.y, center.z });

				// toe.
				points.push_back({ center.x + d3, center.y, center.z });
			}
		}

		// nothing to do here we are done.
		if (points.empty())
			return false;

		// rotate our bbox points by their correct angle
		// and convert our points to world space.
		for (auto& p : points) {
			// VectorRotate.
			// rotate point by angle stored in matrix.
			p = { p.dot(matrix[0]), p.dot(matrix[1]), p.dot(matrix[2]) };

			// transform point to world space.
			p += origin;
		}
	}

	// these hitboxes are capsules.
	else {
		// factor in the pointscale.
		float r = bbox->m_radius * scale;
		float br = bbox->m_radius * bscale;

		// compute raw center point.
		vec3_t center = (bbox->m_mins + bbox->m_maxs) / 2.f;

		// head has 5 points.
		if (index == HITBOX_HEAD) {
			// add center.
			points.push_back(center);

			if (aimbot.m_multipoint_hitboxes.head) {
				// rotation matrix 45 degrees.
				// https://math.stackexchange.com/questions/383321/rotating-x-y-points-45-degrees
				// std::cos( deg_to_rad( 45.f ) )
				constexpr float rotation = 0.70710678f;

				// top/back 45 deg.
				// this is the best spot to shoot at.
				points.push_back({ bbox->m_maxs.x + (rotation * r), bbox->m_maxs.y + (-rotation * r), bbox->m_maxs.z });

				// right.
				points.push_back({ bbox->m_maxs.x, bbox->m_maxs.y, bbox->m_maxs.z + r });

				// left.
				points.push_back({ bbox->m_maxs.x, bbox->m_maxs.y, bbox->m_maxs.z - r });

				// back.
				points.push_back({ bbox->m_maxs.x, bbox->m_maxs.y - r, bbox->m_maxs.z });

				// get animstate ptr.
				c_animation_state* state = record->m_player->m_PlayerAnimState();

				// add this point only under really specific circumstances.
				// if we are standing still and have the lowest possible pitch pose.
				if (state && record->m_anim_velocity.length() <= 0.1f && record->m_eye_angles.x <= state->m_min_pitch) {

					// bottom point.
					points.push_back({ bbox->m_maxs.x - r, bbox->m_maxs.y, bbox->m_maxs.z });
				}
			}
		}

		// body has 5 points.
		else if ( index == HITBOX_BODY ) {
			// center.
			points.push_back( center );

			// back.
			if ( aimbot.m_multipoint_hitboxes.stomach )
				points.push_back( { center.x, bbox->m_maxs.y - br, center.z } );
		}

		else if ( index == HITBOX_PELVIS ) {
			// back.
			if ( aimbot.m_multipoint_hitboxes.stomach )
				points.push_back( { center.x, bbox->m_maxs.y - br, center.z } );
		}
		else if ( index == HITBOX_UPPER_CHEST ) {
			// back.
			if ( aimbot.m_multipoint_hitboxes.upper_chest )
				points.push_back( { center.x, bbox->m_maxs.y - br, center.z } );
		}
		// other stomach/chest hitboxes have 2 points.
		else if ( index == HITBOX_THORAX || index == HITBOX_CHEST ) {
			// add center.
			points.push_back( center );

			// add extra point on back.
			if ( aimbot.m_multipoint_hitboxes.body )
				points.push_back( { center.x, bbox->m_maxs.y - br, center.z } );
		}

		else if ( index == HITBOX_R_CALF || index == HITBOX_L_CALF ) {
			// add center.
			points.push_back( center );

			// half bottom.
			if ( aimbot.m_multipoint_hitboxes.legs )
				points.push_back( { bbox->m_maxs.x - ( bbox->m_radius / 2.f ), bbox->m_maxs.y, bbox->m_maxs.z } );
		}

		else if ( index == HITBOX_R_THIGH || index == HITBOX_L_THIGH ) {
			// add center.
			if ( aimbot.m_multipoint_hitboxes.feet ) //should be legs but uh....
				points.push_back( center );
		}

		// arms get only one point.
		else if ( false && (index == HITBOX_R_UPPER_ARM || index == HITBOX_L_UPPER_ARM) ) { //ignore arms
			// elbow.
			points.push_back( { bbox->m_maxs.x + bbox->m_radius, center.y, center.z } );
		}

		// nothing left to do here.
		if (points.empty())
			return false;

		// transform capsule points.
		for (auto& p : points)
			math::vector_transform(p, bones[bbox->m_bone], p);
	}

	return true;
}

bool c_aim_player::get_best_aim_position(vec3_t& aim, float& damage, c_lag_record* record) {
	bool                   done, pen;
	float                  dmg, pendmg;
	hitscan_data_t         scan;
	std::vector< vec3_t >  points;

	// get player hp.
	int hp = std::min(100, m_player->m_iHealth());

	if (ctx.m_weapon_id == ZEUS) {
		dmg = pendmg = hp;
		pen = true;
	}

	else {
		dmg = aimbot.m_override_damage ? aimbot.m_overriden_damage : aimbot.m_minimum_damage;

		if (dmg > hp)
			dmg = hp;

		pendmg = aimbot.m_override_damage ? aimbot.m_overriden_damage : aimbot.m_minimum_penetration_damage;

		if (pendmg > hp)
			pendmg = hp;

		pen = true;
	}

	// write all data of this record l0l.
	record->cache();

	// iterate hitboxes.
	for (const auto& it : m_hitboxes) {
		done = false;

		// setup points on hitbox.
		if (!setup_hitbox_points(record, record->m_bones, it.m_index, points))
			continue;

		// iterate points on hitbox.
		for (const auto& point : points) {
			penetration::PenetrationInput_t in;

			in.m_damage = dmg;
			in.m_damage_pen = pendmg;
			in.m_can_pen = pen;
			in.m_target = m_player;
			in.m_from = ctx.m_local;
			in.m_pos = point;

			// ignore mindmg.
			if (it.m_mode == hitscan_mode::lethal_mode || it.m_mode == hitscan_mode::lethal2_mode)
				in.m_damage = in.m_damage_pen = 1.f;

			penetration::PenetrationOutput_t out;

			// we can hit p!
			if (penetration::run(&in, &out)) {

				// nope we did not hit head..
				if (it.m_index == HITBOX_HEAD && out.m_hitgroup != HITGROUP_HEAD)
					continue;

				// prefered hitbox, just stop now.
				if (it.m_mode == hitscan_mode::prefer_mode)
					done = true;

				// this hitbox requires lethality to get selected, if that is the case.
				// we are done, stop now.
				else if (it.m_mode == hitscan_mode::lethal_mode && out.m_damage >= m_player->m_iHealth())
					done = true;

				// 2 shots will be sufficient to kill.
				else if (it.m_mode == hitscan_mode::lethal2_mode && (out.m_damage * 2.f) >= m_player->m_iHealth())
					done = true;

				// this hitbox has normal selection, it needs to have more damage.
				else if (it.m_mode == hitscan_mode::normal_mode) {
					// we did more damage.
					if (out.m_damage > scan.m_damage) {
						// save new best data.
						scan.m_damage = out.m_damage;
						scan.m_pos = point;

						// if the first point is lethal
						// screw the other ones.
						if (point == points.front() && out.m_damage >= m_player->m_iHealth())
							break;
					}
				}

				// we found a preferred / lethal hitbox.
				if (done) {
					// save new best data.
					scan.m_damage = out.m_damage;
					scan.m_pos = point;
					break;
				}
			}
		}

		// ghetto break out of outer loop.
		if (done)
			break;
	}

	// we found something that we can damage.
	// set out vars.
	if (scan.m_damage > 0.f) {
		aim = scan.m_pos;
		damage = scan.m_damage;
		return true;
	}

	return false;
}