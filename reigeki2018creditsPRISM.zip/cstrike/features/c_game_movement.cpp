#include "../project.hpp"

c_game_move game_movement{ };

void c_game_move::player_movement(c_lag_record* record) {
	vec3_t                     start, end, normal;
	c_game_trace               trace;
	c_trace_filter_world_only  filter;

	// define trace start.
	start = record->m_origin;

	// move trace end one tick into the future using predicted velocity.
	end = start + (record->m_pred_velocity * cstrike.m_globals->m_interval);

	// trace.
	cstrike.m_engine_trace->TraceRay(Ray(start, end, record->m_mins, record->m_maxs), CONTENTS_SOLID, &filter, &trace);

	// we hit shit
	// we need to fix hit.
	if (trace.m_fraction != 1.f) {

		// fix sliding on planes.
		for (int i{}; i < 2; ++i) {
			record->m_pred_velocity -= trace.m_plane.m_normal * record->m_pred_velocity.dot(trace.m_plane.m_normal);

			float adjust = record->m_pred_velocity.dot(trace.m_plane.m_normal);
			if (adjust < 0.f)
				record->m_pred_velocity -= (trace.m_plane.m_normal * adjust);

			start = trace.m_endpos;
			end = start + (record->m_pred_velocity * (cstrike.m_globals->m_interval * (1.f - trace.m_fraction)));

			cstrike.m_engine_trace->TraceRay(Ray(start, end, record->m_mins, record->m_maxs), CONTENTS_SOLID, &filter, &trace);
			if (trace.m_fraction == 1.f)
				break;
		}
	}

	// set new final origin.
	start = end = record->m_pred_origin = trace.m_endpos;

	// move endpos 2 units down.
	// this way we can check if we are in/on the ground.
	end.z -= 2.f;

	// trace.
	cstrike.m_engine_trace->TraceRay(Ray(start, end, record->m_mins, record->m_maxs), CONTENTS_SOLID, &filter, &trace);

	// strip onground flag.
	record->m_pred_flags &= ~FL_ONGROUND;

	// add back onground flag if we are onground.
	if (trace.m_fraction != 1.f && trace.m_plane.m_normal.z > 0.7f)
		record->m_pred_flags |= FL_ONGROUND;
}

void c_game_move::air_accelerate(c_lag_record* record, ang_t angle, float fmove, float smove) {
	vec3_t fwd, right, wishvel, wishdir;
	float  maxspeed, wishspd, wishspeed, currentspeed, addspeed, accelspeed;

	// determine movement angles.
	math::angle_vectors(angle, &fwd, &right);

	// zero out z components of movement vectors.
	fwd.z = 0.f;
	right.z = 0.f;

	// normalize remainder of vectors.
	fwd.normalize();
	right.normalize();

	// determine x and y parts of velocity.
	for (int i{}; i < 2; ++i)
		wishvel[i] = (fwd[i] * fmove) + (right[i] * smove);

	// zero out z part of velocity.
	wishvel.z = 0.f;

	// determine maginitude of speed of move.
	wishdir = wishvel;
	wishspeed = wishdir.normalize();

	// get maxspeed.
	// TODO; maybe global this or whatever its 260 anyway always.
	maxspeed = record->m_player->m_flMaxspeed();

	// clamp to server defined max speed.
	if (wishspeed != 0.f && wishspeed > maxspeed)
		wishspeed = maxspeed;

	// make copy to preserve original variable.
	wishspd = wishspeed;

	// cap speed.
	if (wishspd > 30.f)
		wishspd = 30.f;

	// determine veer amount.
	currentspeed = record->m_pred_velocity.dot(wishdir);

	// see how much to add.
	addspeed = wishspd - currentspeed;

	// if not adding any, done.
	if (addspeed <= 0.f)
		return;

	// Determine acceleration speed after acceleration
	accelspeed = cstrike.sv_airaccelerate->get_float() * wishspeed * cstrike.m_globals->m_interval;

	// cap it.
	if (accelspeed > addspeed)
		accelspeed = addspeed;

	// add accel.
	record->m_pred_velocity += (wishdir * accelspeed);
}

void c_game_move::extrapolate_movement(c_base_player* player, vec3_t& origin, vec3_t& velocity, int& flags, bool on_ground)
{
	static const auto sv_gravity = cstrike.m_cvar->find_var(HASH("sv_gravity"));
	static const auto sv_jump_impulse = cstrike.m_cvar->find_var(HASH("sv_jump_impulse"));

	if (!(flags & FL_ONGROUND))
		velocity.z -= game::ticks_to_time(sv_gravity->get_float());
	else if (player->m_fFlags() & FL_ONGROUND && !on_ground)
		velocity.z = sv_jump_impulse->get_float();

	const auto src = origin;
	auto end = src + velocity * cstrike.m_globals->m_interval;

	//ray_t r;
	//r.init(src, end, player->get_collideable()->mins(), player->get_collideable()->maxs());

	c_game_trace t{ };
	c_trace_filter_simple filter;
	filter.m_pass_ent1 = player;

	cstrike.m_engine_trace->TraceRay(Ray(src, end, player->m_vecMins(), player->m_vecMaxs()), MASK_PLAYERSOLID, &filter, &t);

	if (t.m_fraction != 1.f) {
		for (auto i = 0; i < 2; i++) {
			velocity -= t.m_plane.m_normal * velocity.dot(t.m_plane.m_normal);

			const auto dot = velocity.dot(t.m_plane.m_normal);
			if (dot < 0.f)
				velocity -= vec3_t(dot * t.m_plane.m_normal.x,
					dot * t.m_plane.m_normal.y, dot * t.m_plane.m_normal.z);

			end = t.m_endpos + velocity * game::ticks_to_time(1.f - t.m_fraction);

			//r.init(t.m_endpos, end, player->get_collideable()->mins(), player->get_collideable()->maxs());
			cstrike.m_engine_trace->TraceRay(Ray(t.m_endpos, end, player->m_vecMins(), player->m_vecMaxs()), MASK_PLAYERSOLID, &filter, &t);

			if (t.m_fraction == 1.f)
				break;
		}
	}
	origin = end = t.m_endpos;
	end.z -= 2.f;

	//	r.init(origin, end, player->get_collideable()->mins(), player->get_collideable()->maxs());
	cstrike.m_engine_trace->TraceRay(Ray(origin, end, player->m_vecMins(), player->m_vecMaxs()), MASK_PLAYERSOLID, &filter, &t);

	flags &= FL_ONGROUND;

	if (t.hit() && t.m_plane.m_normal.z > .7f)
		flags |= FL_ONGROUND;
}