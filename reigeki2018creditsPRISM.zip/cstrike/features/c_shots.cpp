#include "../project.hpp"

c_shots shots{ };

void c_shots::on_shot_fire(c_base_player* target, float damage, int bullets, c_lag_record* record) {

	// iterate all bullets in this shot.
	for (int i{ }; i < bullets; ++i) {
		// setup new shot data.
		shot_record_t shot;
		shot.m_target = target;
		shot.m_record = record;
		shot.m_time = game::ticks_to_time(ctx.m_local->m_nTickBase());
		shot.m_lat = ctx.m_latency;
		shot.m_damage = damage;
		shot.m_pos = ctx.m_local->get_shoot_position();

		// we are not shooting manually.
		// and this is the first bullet, only do this once.
		if (target && i == 0) {
			// increment total shots on this player.
			c_aim_player* data = &aimbot.m_players[target->index() - 1];
			if (data)
				++data->m_shots;
		}

		// add to tracks.
		m_shots.push_front(shot);
	}

	// no need to keep an insane amount of shots.
	while (m_shots.size() > 128)
		m_shots.pop_back();
}

void c_shots::on_impact(i_game_event* evt) {
	int        attacker;
	vec3_t        pos, dir, start, end;
	float        time;
	c_game_trace trace;

	// screw this.
	if (!evt || !ctx.m_local)
		return;

	// get attacker, if its not us, screw it.
	attacker = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());
	if (attacker != cstrike.m_engine->get_local_player())
		return;

	// draw client impacts.
	visuals.ClientImpacts();

	// decode impact coordinates and convert to vec3.
	pos = {
		evt->m_keys->find_key(HASH("x"))->get_float(),
		evt->m_keys->find_key(HASH("y"))->get_float(),
		evt->m_keys->find_key(HASH("z"))->get_float()
	};

	// get prediction time at this point.
	time = game::ticks_to_time(ctx.m_local->m_nTickBase());

	// add to visual impacts if we have features that rely on it enabled.
	// todo - dex; need to match shots for this to have proper GetShootPosition, don't really care to do it anymore.
	if (g_cfg[XOR("visuals_misc_bullet_beam")].get< bool >())
		m_vis_impacts.push_back({ pos, ctx.m_local->get_shoot_position(), ctx.m_local->m_nTickBase() });

	// we did not take a shot yet.
	if (m_shots.empty())
		return;

	struct shot_match_t { float delta; shot_record_t* shot; };
	shot_match_t match;
	match.delta = std::numeric_limits< float >::max();
	match.shot = nullptr;

	// iterate all shots.
	for (auto& s : m_shots) {

		// this shot was already matched
		// with a 'bullet_impact' event.
		if (s.m_matched)
			continue;

		// add the latency to the time when we shot.
		// to predict when we would receive this event.
		float predicted = s.m_time + s.m_lat;

		// get the delta between the current time
		// and the predicted arrival time of the shot.
		float delta = std::abs(time - predicted);

		// fuck this.
		if (delta > 1.f)
			continue;

		// store this shot as being the best for now.
		if (delta < match.delta) {
			match.delta = delta;
			match.shot = &s;
		}
	}

	// no valid shotrecord was found.
	shot_record_t* shot = match.shot;
	if (!shot)
		return;

	// this shot was matched.
	shot->m_matched = true;

	// create new impact instance that we can match with a player hurt.
	impact_record_t impact;
	impact.m_shot = shot;
	impact.m_tick = ctx.m_local->m_nTickBase();
	impact.m_pos = pos;

	//ctx.print( "imp %x time: %f lat: %f dmg: %f\n", shot->m_record, shot->m_time, shot->m_lat, shot->m_damage );

	// add to track.
	m_impacts.push_front(impact);

	// no need to keep an insane amount of impacts.
	while (m_impacts.size() > 128)
		m_impacts.pop_back();

	// nospread mode.
	//if (g_menu.main.config.mode.get() == 1)
	//	return;

	// not in nospread mode, see if the shot missed due to spread.
	c_base_player* target = shot->m_target;
	if (!target)
		return;

	// not gonna bother anymore.
	if (!target->alive())
		return;

	c_aim_player* data = &aimbot.m_players[target->index() - 1];
	if (!data)
		return;

	// this record was deleted already.
	if (!shot->m_record->m_bones)
		return;

	// we are going to alter this player.
	// store all his og data.
	c_backup_record backup;
	backup.store(target);

	// write historical matrix of the time that we shot
	// into the games bone cache, so we can trace against it.
	shot->m_record->cache();

	// start position of trace is where we took the shot.
	start = shot->m_pos;

	// the impact pos contains the spread from the server
	// which is generated with the server seed, so this is where the bullet
	// actually went, compute the direction of this from where the shot landed
	// and from where we actually took the shot.
	dir = (pos - start).normalized();

	// get end pos by extending direction forward.
	// todo; to do this properly should save the weapon range at the moment of the shot, cba..
	end = start + (dir * 8192.f);

	// intersect our historical matrix with the path the shot took.
	cstrike.m_engine_trace->clip_ray_to_entity(Ray(start, end), MASK_SHOT, target, &trace);

	// we did not hit jackshit, or someone else.
	if (!trace.m_entity || !trace.m_entity->is_player() || trace.m_entity != target)
		notify.add(XOR("[miss] reason: spread\n"), colors::light_red);


	// we should have 100% hit this player..
	// this is a miss due to wrong angles.
	else if (trace.m_entity == target) {
		size_t mode = shot->m_record->m_mode;

		// if we miss a shot on body update.
		// we can chose to stop shooting at them.
		if (mode == c_aim_resolver::resolver_mode::lby_yaw_mode) {
			++data->m_lby_yaw_index;
		}

		else if (mode == c_aim_resolver::resolver_mode::lastmove_mode) {
			++data->m_last_move;
		}

		else if (mode == c_aim_resolver::resolver_mode::freestand_mode) {
			++data->m_unknown_move;
		}

		else if (mode == c_aim_resolver::resolver_mode::standing_mode) {
			++data->m_stand_index;
		}

		else if (mode == c_aim_resolver::resolver_mode::bruteforce_mode) {
			++data->m_bruteforce_index;
		}

		++data->m_missed_shots;
	}


	// restore player to his original state.
	backup.restore(target);
}

void c_shots::on_hurt(i_game_event* evt) {
	int         attacker, victim, group, hp;
	float       damage;
	std::string name;

	if (!evt || !ctx.m_local)
		return;

	attacker = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("attacker"))->get_int());
	victim = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());

	// skip invalid player indexes.
	// should never happen? world entity could be attacker, or a nade that hits you.
	if (attacker < 1 || attacker > 64 || victim < 1 || victim > 64)
		return;

	// we were not the attacker or we hurt ourselves.
	else if (attacker != cstrike.m_engine->get_local_player() || victim == cstrike.m_engine->get_local_player())
		return;

	// get hitgroup.
	// players that get naded ( DMG_BLAST ) or stabbed seem to be put as HITGROUP_GENERIC.
	group = evt->m_keys->find_key(HASH("hitgroup"))->get_int();

	// invalid hitgroups ( note - dex; HITGROUP_GEAR isn't really invalid, seems to be set for hands and stuff? ).
	if (group == HITGROUP_GEAR)
		return;

	// get the player that was hurt.
	c_base_player* target = cstrike.m_entlist->get_client_entity< c_base_player* >(victim);
	if (!target)
		return;

	// get player info.
	player_info_t info;
	if (!cstrike.m_engine->get_player_info(victim, &info))
		return;

	// get player name;
	name = std::string(info.m_name).substr(0, 24);

	// get damage reported by the server.
	damage = (float)evt->m_keys->find_key(HASH("dmg_health"))->get_int();

	// get remaining hp.
	hp = evt->m_keys->find_key(HASH("health"))->get_int();

	// hitmarker.
	if (g_cfg[XOR("misc_hitmarker")].get< bool >()) {
		visuals.m_hit_duration = 1.f;
		visuals.m_hit_start = cstrike.m_globals->m_curtime;
		visuals.m_hit_end = visuals.m_hit_start + visuals.m_hit_duration;

		cstrike.m_sound->emit_ambient_sound(XOR("buttons/arena_switch_press_02.wav"), 1.f);
	}

	// print this shit.
	//if (g_menu.main.misc.notifications.get(1)) {
	//	std::string out = tfm::format(XOR("[registered] player: %s hitbox: %s damage: %i [ %i remaining ]\n"), name, m_groups[group], (int)damage, hp);
	//	notify.add(out, colors::light_green);
	//}

	if (group == HITGROUP_GENERIC)
		return;

	// if we hit a player, mark vis impacts.
	if (!m_vis_impacts.empty()) {
		for (auto& i : m_vis_impacts) {
			if (i.m_tickbase == ctx.m_local->m_nTickBase())
				i.m_hit_player = true;
		}
	}

	// no impacts to match.
	if (m_impacts.empty())
		return;

	impact_record_t* impact{ nullptr };

	// iterate stored impacts.
	for (auto& i : m_impacts) {

		// this impact doesnt match with our current hit.
		if (i.m_tick != ctx.m_local->m_nTickBase())
			continue;

		// wrong player.
		if (i.m_shot->m_target != target)
			continue;

		// shit fond.
		impact = &i;
		break;
	}

	// no impact matched.
	if (!impact)
		return;

	// setup new data for hit track and push to hit track.
	hit_record_t hit;
	hit.m_impact = impact;
	hit.m_group = group;
	hit.m_damage = damage;

	//ctx.print( "hit %x time: %f lat: %f dmg: %f\n", impact->m_shot->m_record, impact->m_shot->m_time, impact->m_shot->m_lat, impact->m_shot->m_damage );

	m_hits.push_front(hit);

	while (m_hits.size() > 128)
		m_hits.pop_back();

	c_aim_player* data = &aimbot.m_players[target->index() - 1];
	if (!data)
		return;

	// we hit, reset missed shots counter.
	data->m_missed_shots = 0;

	size_t mode = impact->m_shot->m_record->m_mode;

	// if we miss a shot on body update.
	// we can chose to stop shooting at them.
	if (mode == c_aim_resolver::resolver_mode::lby_yaw_mode && data->m_lby_yaw_index > 0)
		--data->m_lby_yaw_index;

	else if (mode == c_aim_resolver::resolver_mode::standing_mode && data->m_stand_index > 0)
		--data->m_stand_index;

	else if (mode == c_aim_resolver::resolver_mode::bruteforce_mode && data->m_bruteforce_index > 0)
		--data->m_bruteforce_index;

	else if (mode == c_aim_resolver::resolver_mode::lastmove_mode && data->m_last_move > 0) {
		--data->m_last_move;
	}

	else if (mode == c_aim_resolver::resolver_mode::freestand_mode && data->m_unknown_move > 0) {
		--data->m_unknown_move;
	}

	// if we hit head
	// shoot at this 5 more times.
	if (group == HITGROUP_HEAD) {
		c_lag_record* record = hit.m_impact->m_shot->m_record;

		//switch( record->m_mode ) {
		//case Resolver::Modes::RESOLVE_STAND:
		//	data->m_prefer_stand.clear( );
		//	data->m_prefer_stand.push_front( math::NormalizedAngle( record->m_eye_angles.y - record->m_lbyt ) );
		//	break;

		//case Resolver::Modes::RESOLVE_AIR:
		//	if( g_menu.main.config.mode.get( ) == 1 ) {
		//		data->m_prefer_air.clear( );
		//		data->m_prefer_air.push_front( math::NormalizedAngle( record->m_eye_angles.y - record->m_away ) );
		//
		//		g_notify.add( tfm::format( "air hit %f\n", data->m_prefer_air.front( ) ) );
		//	}
		//
		//	break;

		//default:
		//	break;
		//}
	}
}