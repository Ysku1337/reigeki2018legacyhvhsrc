#include "../project.hpp"

Chams chams{ };;

void Chams::SetColor(Color col, color_type_t type) {

	if (type == color_type_t::envmap_tint) {

		bool did_find = false;
		auto material = silhouette->find_var(XOR("$envmaptint"), &did_find);

		if (did_find) {
			(*(void(__thiscall**)(int, float, float, float))(*(DWORD*)material + 44))((uintptr_t)material, col.r() / 255.f, col.g() / 255.f, col.b() / 255.f);
		}
	}
	else {
		cstrike.m_render_view->set_color_modlation(col);
	}
}

void Chams::SetAlpha(float alpha, i_material* mat) {
	if (mat)
		mat->alpha_modulate(alpha);

	else
		cstrike.m_render_view->set_blend(alpha);
}

void Chams::SetupMaterial(i_material* mat, Color col, bool z_flag) {
	cstrike.m_render_view->set_color_modlation(col);


	// mat->SetFlag( MATERIAL_VAR_HALFLAMBERT, flags );
	mat->set_flag(MATERIAL_VAR_ZNEARER, z_flag);
	mat->set_flag(MATERIAL_VAR_NOFOG, z_flag);
	mat->set_flag(MATERIAL_VAR_IGNOREZ, z_flag);

	cstrike.m_studio_render->forced_material_override(mat);
}

void Chams::init() {
	// find stupid materials.
	debugambientcube = cstrike.m_material_system->find_material(XOR("debug/debugambientcube"), XOR("Model textures"));
	debugdrawflat = cstrike.m_material_system->find_material(XOR("debug/debugdrawflat"), nullptr);
	silhouette = cstrike.m_material_system->find_material(XOR("dev/glow_armsrace.vmt"), nullptr);
}

void Chams::DrawShotRecord(c_base_player* ent, uintptr_t ctx, const draw_model_state_t& state, const model_render_info_t& info, matrix3x4_t* bone) {

	for (int i{ }; i < m_hits->size(); i++) {
		auto data = m_hits->at(i);

		if (ent != data.ent)
			continue;

		if (!data.time || data.time + game::time_to_ticks(1) < cstrike.m_globals->m_tick_count)
			continue;

		cstrike.m_studio_render->forced_material_override(silhouette);
		cstrike.m_render_view->set_blend(1.0f);
		SetColor({ 255, 255, 255, 255 }, color_type_t::envmap_tint);

		hook_handler.m_model_render.get_method< c_hook_handler::draw_model_execute_t >(iv_model_render::DRAWMODELEXECUTE)(cstrike.m_model_render, ctx, state, info, data.m_last_pose);
		hook_handler.m_model_render.get_method< c_hook_handler::draw_model_execute_t >(iv_model_render::DRAWMODELEXECUTE)(cstrike.m_model_render, ctx, state, info, bone);
		cstrike.m_studio_render->forced_material_override(nullptr);
	}

}

bool Chams::GenerateLerpedMatrix(int index, c_bone_array* out) {
	//if (!ctx.m_processing)
	//	return false;

	//auto player = cstrike.m_entlist->get_client_entity<c_base_player*>(index);
	//if (!player)
	//	return false;

	//const auto LastRecord = g_lagcompensation.GetViableRecords(player, 1.0f);

	//if (!LastRecord.has_value())
	//	return false;

	//const auto& FirstInvalid = LastRecord.value().first;
	//const auto& LastInvalid = LastRecord.value().second;

	//if (FirstInvalid->m_bDormant)
	//	return false;

	//if (LastInvalid->m_flSimulationTime - FirstInvalid->m_flSimulationTime > 0.5f)
	//	return false;

	//const auto NextOrigin = LastInvalid->m_vecOrigin;
	//const auto curtime = g_csgo.m_globals->m_curtime;

	//auto flDelta = 1.f - (curtime - LastInvalid->m_flInterpTime) / (LastInvalid->m_flSimulationTime - FirstInvalid->m_flSimulationTime);
	//if (flDelta < 0.f || flDelta > 1.f)
	//	LastInvalid->m_flInterpTime = curtime;

	//flDelta = 1.f - (curtime - LastInvalid->m_flInterpTime) / (LastInvalid->m_flSimulationTime - FirstInvalid->m_flSimulationTime);

	//const auto lerp = math::Interpolate(NextOrigin, FirstInvalid->m_vecOrigin, std::clamp(flDelta, 0.f, 1.f));

	//BoneArray ret[128];
	//memcpy(ret, FirstInvalid->m_pMatrix_Resolved, sizeof(BoneArray[128]));

	//for (size_t i{ }; i < 128; ++i) {
	//	const auto matrix_delta = math::MatrixGetOrigin(FirstInvalid->m_pMatrix_Resolved[i]) - FirstInvalid->m_vecOrigin;
	//	math::MatrixSetOrigin(matrix_delta + lerp, ret[i]);
	//}

	//memcpy(out, ret, sizeof(BoneArray[128]));
	return false;
}

void Chams::RenderHistoryChams(int index) {
	c_aim_player* data;

	c_base_player* player = cstrike.m_entlist->get_client_entity< c_base_player* >(index);
	if (!player)
		return;

	if (player->is_dormant())
		return;

	if (!aimbot.is_valid_target(player))
		return;

	bool enemy = ctx.m_local && player->enemy(ctx.m_local);
	if (enemy) {
		data = &aimbot.m_players[index - 1];
		if (!data)
			return;

		// get color.
		Color color = g_cfg[XOR("esp_chams_enemies_history_color")].get_color();

		i_material* material;

		switch (g_cfg[XOR("esp_chams_history_enemies")].get< int >())
		{
		case 1:
			material = debugdrawflat; break;
		case 2:
			material = debugambientcube; break;
		case 3:
			material = silhouette; break;
		default:
			material = debugdrawflat; break;
		}

		material->color_modulate(color);

		// override blend.
		SetAlpha(color.a() / 255.f);

		// set material and color.
		cstrike.m_studio_render->forced_material_override(material);

		// was the matrix properly setup?
		//c_bone_array arr[128];
		//if (Chams::GenerateLerpedMatrix(index, arr)) {
		//	// backup the bone cache before we fuck with it.
		//	auto backup_bones = player->m_BoneCache().m_pCachedBones;

		//	// replace their bone cache with our custom one.
		//	player->m_BoneCache().m_pCachedBones = arr;

		//	// manually draw the model.
		//	player->DrawModel();

		//	// reset their bone cache to the previous one.
		//	player->m_BoneCache().m_pCachedBones = backup_bones;
		//}
	}
}

void Chams::ApplyChams(std::string material, std::string color, float alpha, int material_flag, bool flag_value, uintptr_t context, const draw_model_state_t& state, const model_render_info_t& info, matrix3x4_t* bone, bool chams_background) {

	if (!ctx.m_processing)
		return;

	if (g_cfg[material].get< int >() == 3) {

		// normal chams.
		if (!chams_background)
			ApplyChams(XOR("force_render_unlit"), color, alpha, material_flag, flag_value, context, state, info, bone);

		// original.
		hook_handler.m_model_render.get_method< c_hook_handler::draw_model_execute_t >(iv_model_render::DRAWMODELEXECUTE)(cstrike.m_model_render, context, state, info, bone);

		// overlay.
		g_cfg[material].get< int >() == 1 ? debugdrawflat->set_flag(material_flag, flag_value) : g_cfg[material].get< int >() == 2 ? debugambientcube->set_flag(material_flag, flag_value) : g_cfg[material].get< int >() == 3 ? silhouette->set_flag(material_flag, flag_value) : 0;
		cstrike.m_studio_render->forced_material_override(g_cfg[material].get< int >() == 1 ? debugdrawflat : g_cfg[material].get< int >() == 2 ? debugambientcube : g_cfg[material].get< int >() == 3 ? silhouette : nullptr);
		cstrike.m_render_view->set_blend(1.0f); // force max opacity!
		SetColor({ 255, 255, 255, 255 }, g_cfg[material].get< int >() == 3 ? color_type_t::envmap_tint : color_type_t::normal);

		// we don't wanna call the rest.
		return;
	}

	// last was silhouette, let's draw normal chams.
	if (material == XOR("force_render_unlit")) {

		debugambientcube->set_flag(material_flag, flag_value);
		cstrike.m_studio_render->forced_material_override(debugambientcube);
		cstrike.m_render_view->set_blend(g_cfg[color].get_color().a() / 255.f);
		SetColor(g_cfg[color].get_color(), color_type_t::normal);

		// don't override it.
		return;
	}

	g_cfg[material].get< int >() == 1 ? debugdrawflat->set_flag(material_flag, flag_value) : g_cfg[material].get< int >() == 2 ? debugambientcube->set_flag(material_flag, flag_value) : g_cfg[material].get< int >() == 3 ? silhouette->set_flag(material_flag, flag_value) : 0;
	cstrike.m_studio_render->forced_material_override(g_cfg[material].get< int >() == 1 ? debugdrawflat : g_cfg[material].get< int >() == 2 ? debugambientcube : g_cfg[material].get< int >() == 3 ? silhouette : nullptr);
	cstrike.m_render_view->set_blend(g_cfg[color].get_color().a() / 255.f);
	SetColor(g_cfg[color].get_color(), g_cfg[material].get< int >() == 3 ? color_type_t::envmap_tint : color_type_t::normal);
}

bool Chams::DrawModel(uintptr_t context, const draw_model_state_t& state, const model_render_info_t& info, matrix3x4_t* bone) {

	if (!cstrike.m_engine->is_in_game()) {
		m_running = false;
		return true;
	}

	//local weapon
	//if( !g_cl.m_weapon )
		//return true;

	if (ctx.m_processing)
		m_running = true;

	if (!m_running)
		return true;

	// store the model name for later use.
	const char* name = cstrike.m_model_info->get_model_name(info.m_model);

	// perform arm chams, users can chose from flat, normal, silhouette.
	if (strstr(name, XOR("arms")) && g_cfg[XOR("chams_hand")].get< bool >()) {
		ApplyChams(XOR("hand_chams_material"), XOR("hand_chams_color"), g_cfg[XOR("hand_chams_color")].get_color().a() / 255.f, MATERIAL_VAR_IGNOREZ, false, context, state, info, bone);
	}


	// not sure if this is right.
	c_base_player* player = reinterpret_cast<c_base_player*>(cstrike.m_entlist->get_client_entity(info.m_index));

	if (!player)
		return true;


	if (strstr(name, XOR("models/player")) && !player->is_dormant()) {

		// is an enemy.
		if (player->m_iTeamNum() != ctx.m_local->m_iTeamNum()) {

			if (player->alive()) {

				// on hit chams.
				if (g_cfg[XOR("chams_enemy_hit")].get< bool >()) {
					chams.DrawShotRecord(player, context, state, info, bone);
				}

				// hidden
				if (g_cfg[XOR("chams_enemy_hidden")].get< bool >()) {
					ApplyChams(XOR("esp_chams_invis_enemies"), XOR("esp_chams_enemies_invis_color"), g_cfg[XOR("esp_chams_enemies_invis_color")].get_color().a() / 255.f, MATERIAL_VAR_IGNOREZ, true, context, state, info, bone);

					// IMPORTANT: if we don't call the original this material will get overriden.
					hook_handler.m_model_render.get_method< c_hook_handler::draw_model_execute_t >(iv_model_render::DRAWMODELEXECUTE)(cstrike.m_model_render, context, state, info, bone);
				}

				// visible
				if (g_cfg[XOR("chams_enemy")].get< bool >()) {
					ApplyChams(XOR("esp_chams_visible_enemies"), XOR("esp_chams_enemies_color"), g_cfg[XOR("esp_chams_enemies_color")].get_color().a() / 255.f, MATERIAL_VAR_IGNOREZ, false, context, state, info, bone);
				}
			}

			// now we can do corpse chams.
			else {
				if (g_cfg[XOR("chams_enemy_ragdoll")].get< bool >()) {
					ApplyChams(XOR("esp_chams_corpse_enemies"), XOR("esp_chams_enemies_corpse_color"), g_cfg[XOR("esp_chams_enemies_corpse_color")].get_color().a() / 255.f, MATERIAL_VAR_IGNOREZ, false, context, state, info, bone);
				}
			}

			// do local player chams.
		}
		else if (player == ctx.m_local) {

			//if (g_cfg[XOR("chams_desync")].get< bool >() && !(cstrike.m_globals->m_curtime < (ctx.m_local->m_flSpawnTime() + 0.5f))) {

			//	ApplyChams(XOR("desyc_chams_material"), XOR("desync_chams_color"), g_cfg[XOR("desync_chams_color")].get_color().a() / 255.f, MATERIAL_VAR_IGNOREZ, false, context, state, info, bone);

			//	// manually draw the model.
			//	hook_handler.m_model_render.get_method< c_hook_handler::draw_model_execute_t >(iv_model_render::DRAWMODELEXECUTE)(cstrike.m_model_render, context, state, info, ctx.m_fake_matrix);

			//}

			if (g_cfg[XOR("chams_local")].get< bool >()) {

				ApplyChams(XOR("local_chams_material"), XOR("local_chams_color"), g_cfg[XOR("local_chams_color")].get_color().a() / 255.f, MATERIAL_VAR_IGNOREZ, false, context, state, info, bone);

			}

			//if (ctx.m_local->m_bIsScoped() || ctx.m_weapon_type == WEAPONTYPE_EQUIPMENT) {
			//	g_csgo.m_render_view->SetBlend(g_cfg[XOR("chams_local")].get< bool >() ? (g_cfg[XOR("local_chams_color")].get_color().a() / 255.f) / 2.0f : 0.5f);
			//}
		}

	}


	return true;
}

void Chams::SceneEnd() {

	if (!ctx.m_processing)
		return;

	// restore.
	cstrike.m_studio_render->forced_material_override(nullptr);
	cstrike.m_render_view->set_color_modlation(colors::white);
	cstrike.m_render_view->set_blend(1.f);

	// store and sort ents by distance.
	if (SortPlayers()) {
		// iterate each player and render them.
		for (const auto& p : m_players) {
			// check if is an enemy.
			bool enemy = ctx.m_local && p->enemy(ctx.m_local);

			if (enemy && g_cfg[XOR("chams_enemy_history")].get< bool >()) {
				RenderHistoryChams(p->index());
			}
		}
	}

	// restore.
	cstrike.m_studio_render->forced_material_override(nullptr);
	cstrike.m_render_view->set_color_modlation(colors::white);
	cstrike.m_render_view->set_blend(1.f);
}

bool Chams::IsInViewPlane(const vec3_t& world) {
	float w;

	const v_matrix& matrix = cstrike.m_engine->world_to_screen_matrix();

	w = matrix[3][0] * world.x + matrix[3][1] * world.y + matrix[3][2] * world.z + matrix[3][3];

	return w > 0.001f;
}

bool Chams::SortPlayers() {
	// lambda-callback for std::sort.
	// to sort the players based on distance to the local-player.
	static auto distance_predicate = [](entity_t* a, entity_t* b) {
		vec3_t local = ctx.m_local->get_abs_origin();

		// note - dex; using squared length to save out on sqrt calls, we don't care about it anyway.
		float len1 = (a->get_abs_origin() - local).length_sqr();
		float len2 = (b->get_abs_origin() - local).length_sqr();

		return len1 < len2;
	};

	// reset player container.
	m_players.clear();

	// find all players that should be rendered.
	for (int i{ 1 }; i <= cstrike.m_globals->m_max_clients; ++i) {
		// get player ptr by idx.
		c_base_player* player = cstrike.m_entlist->get_client_entity< c_base_player* >(i);

		// validate.
		if (!player || !player->is_player() || !player->alive() || player->is_dormant())
			continue;

		// do not draw players occluded by view plane.
		if (!IsInViewPlane(player->world_space_center()))
			continue;

		m_players.push_back(player);
	}

	// any players?
	if (m_players.empty())
		return false;

	// sorting fixes the weird weapon on back flickers.
	// and all the other problems regarding Z-layering in this shit game.
	std::sort(m_players.begin(), m_players.end(), distance_predicate);

	return true;
}