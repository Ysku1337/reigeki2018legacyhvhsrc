#include "../project.hpp"

Listener listener{};;

void events::round_start(i_game_event* evt) {
	// new round has started. no longer round end.
	ctx.m_round_end = false;

	// remove notices.
	ctx.m_round_flags = 0;

	// update skins.
//	g_skins.m_update = true;

	// reset bomb stuff.
	visuals.m_c4_planted = false;
	visuals.m_planted_c4 = nullptr;

	// reset dormant esp.
	visuals.m_draw.fill(false);
	visuals.m_opacities.fill(0.f);
	visuals.m_offscreen_damage.fill(offscreen_damage_data_t());

	// update all players.
	for (int i{ 1 }; i <= cstrike.m_globals->m_max_clients; ++i) {
		c_base_player* player = cstrike.m_entlist->get_client_entity< c_base_player* >(i);
		if (!player || player->is_local_player())
			continue;

		c_aim_player* data = &aimbot.m_players[i - 1];
		data->on_round_start(player);
	}

	shots.m_hits.clear();
	shots.m_impacts.clear();
	shots.m_shots.clear();

	// clear origins.
	ctx.m_net_pos.clear();

	// buybot.
	ctx.purchase_bot( );

}

void events::round_end(i_game_event* evt) {
	if (!ctx.m_local)
		return;

	// get the reason for the round end.
	int reason = evt->m_keys->find_key(HASH("reason"))->get_int();

	// reset.
	ctx.m_round_end = false;

	if (ctx.m_local->m_iTeamNum() == TEAM_COUNTERTERRORISTS && reason == cs_round_end_reason::CT_WIN)
		ctx.m_round_end = true;

	else if (ctx.m_local->m_iTeamNum() == TEAM_TERRORISTS && reason == cs_round_end_reason::T_WIN)
		ctx.m_round_end = true;
}

void events::player_hurt(i_game_event* evt) {
	int attacker, victim;

	// forward event to resolver / shots hurt processing.
	// g_resolver.hurt( evt );
	shots.on_hurt(evt);

	// offscreen esp damage stuff.
	if (evt) {
		attacker = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("attacker"))->get_int());
		victim = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());

		// a player damaged the local player.
		if (attacker > 0 && attacker < 64 && victim == cstrike.m_engine->get_local_player())
			visuals.m_offscreen_damage[attacker] = { 3.f, 0.f, colors::red };
	}
}

void events::bullet_impact(i_game_event* evt) {
	int        attacker;

	// forward event to resolver impact processing.
	shots.on_impact(evt);

	// decode impact coordinates and convert to vec3
	vec3_t pos = {
			evt->m_keys->find_key(HASH("x"))->get_float(),
			evt->m_keys->find_key(HASH("y"))->get_float(),
			evt->m_keys->find_key(HASH("z"))->get_float()
	};

	// screw this.
	if (!evt || !ctx.m_local)
		return;

	// get attacker, if its not us, screw it.
	attacker = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());
	if (attacker != cstrike.m_engine->get_local_player())
		return;

	movement.m_shot = true;

	if (g_cfg[XOR("misc_bullet_impacts_server")].get< bool >()) {
		if (g_cfg[XOR("misc_bullet_impacts_server_override")].get< bool >())
			cstrike.m_debug_overlay->add_box_overlay(pos, vec3_t(-2, -2, -2), vec3_t(2, 2, 2), ang_t(0, 0, 0), g_cfg[XOR("misc_bullet_impacts_server_color")].get_color().r(), g_cfg[XOR("misc_bullet_impacts_server_color")].get_color().g(), g_cfg[XOR("misc_bullet_impacts_server_color")].get_color().b(), g_cfg[XOR("misc_bullet_impacts_server_color")].get_color().a(), 3);
		else
			cstrike.m_debug_overlay->add_box_overlay(pos, vec3_t(-2, -2, -2), vec3_t(2, 2, 2), ang_t(0, 0, 0), 255, 0, 0, 127, 3);
	}
}

void events::item_purchase(i_game_event* evt) {
	int           team, purchaser;
	player_info_t info;

	if (!ctx.m_local || !evt)
		return;

	if (!g_cfg[XOR("misc_log_purchases")].get< bool >())
		return;

	// only log purchases of the enemy team.
	team = evt->m_keys->find_key(HASH("team"))->get_int();
	if (team == ctx.m_local->m_iTeamNum())
		return;

	// get the player that did the purchase.
	purchaser = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());

	// get player info of purchaser.
	if (!cstrike.m_engine->get_player_info(purchaser, &info))
		return;

	std::string weapon = evt->m_keys->find_key(HASH("weapon"))->m_string;
	if (weapon == XOR("weapon_unknown"))
		return;

	std::string out = tfm::format(XOR("%s bought %s\n"), std::string{ info.m_name }.substr(0, 24), weapon);
	notify.add(out);
}

void events::player_death(i_game_event* evt) {
	// get index of player that died.
	int index = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());

	// reset opacity scale.
	visuals.m_opacities[index - 1] = 0.f;
	visuals.m_draw[index - 1] = false;
}

void events::player_given_c4(i_game_event* evt) {
	player_info_t info;

	if (!g_cfg[XOR("misc_log_bomb")].get< bool >())
		return;

	// get the player who received the bomb.
	int index = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());
	if (index == cstrike.m_engine->get_local_player())
		return;

	if (!cstrike.m_engine->get_player_info(index, &info))
		return;

	std::string out = tfm::format(XOR("%s received the bomb\n"), std::string{ info.m_name }.substr(0, 24));
	notify.add(out);
}

void events::bomb_beginplant(i_game_event* evt) {
	player_info_t info;

	if (!g_cfg[XOR("misc_log_bomb")].get< bool >())
		return;

	// get the player who played the bomb.
	int index = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());
	if (index == cstrike.m_engine->get_local_player())
		return;

	// get player info of purchaser.
	if (!cstrike.m_engine->get_player_info(index, &info))
		return;

	std::string out = tfm::format(XOR("%s started planting the bomb\n"), std::string{ info.m_name }.substr(0, 24));
	notify.add(out);
}

void events::bomb_abortplant(i_game_event* evt) {
	player_info_t info;

	if (!g_cfg[XOR("misc_log_bomb")].get< bool >())
		return;

	// get the player who stopped planting the bomb.
	int index = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());
	if (index == cstrike.m_engine->get_local_player())
		return;

	// get player info of purchaser.
	if (!cstrike.m_engine->get_player_info(index, &info))
		return;

	std::string out = tfm::format(XOR("%s stopped planting the bomb\n"), std::string{ info.m_name }.substr(0, 24));
	notify.add(out);
}

void events::bomb_planted(i_game_event* evt) {
	entity_t* bomb_target;
	std::string   site_name;
	int           player_index;
	player_info_t info;
	std::string   out;

	// get the func_bomb_target entity and store info about it.
	bomb_target = cstrike.m_entlist->get_client_entity(evt->m_keys->find_key(HASH("site"))->get_int());
	if (bomb_target) {
		site_name = bomb_target->get_bombsite_name();
		visuals.m_last_bombsite = site_name;
	}

	if (!g_cfg[XOR("misc_log_bomb")].get< bool >())
		return;

	player_index = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());
	if (player_index == cstrike.m_engine->get_local_player())
		out = tfm::format(XOR("you planted the bomb at %s\n"), site_name.c_str());

	else {
		cstrike.m_engine->get_player_info(player_index, &info);

		out = tfm::format(XOR("the bomb was planted at %s by %s\n"), site_name.c_str(), std::string(info.m_name).substr(0, 24));
	}

	notify.add(out);
}

void events::bomb_beep(i_game_event* evt) {
	entity_t* c4;
	vec3_t                explosion_origin, explosion_origin_adjusted;
	c_trace_filter_simple filter;
	c_game_trace          tr;

	// we have a bomb ent already, don't do anything else.
	if (visuals.m_c4_planted)
		return;

	// bomb_beep is called once when a player plants the c4 and contains the entindex of the C4 weapon itself, we must skip that here.
	c4 = cstrike.m_entlist->get_client_entity(evt->m_keys->find_key(HASH("entindex"))->get_int());
	if (!c4 || !c4->is(HASH("CPlantedC4")))
		return;

	// planted bomb is currently active, grab some extra info about it and set it for later.
	visuals.m_c4_planted = true;
	visuals.m_planted_c4 = c4;
	visuals.m_planted_c4_explode_time = c4->m_flC4Blow();

	// the bomb origin is adjusted slightly inside CPlantedC4::C4Think, right when it's about to explode.
	// we're going to do that here.
	explosion_origin = c4->get_abs_origin();
	explosion_origin_adjusted = explosion_origin;
	explosion_origin_adjusted.z += 8.f;

	// setup filter and do first trace.
	filter.set_pass_entity(c4);

	cstrike.m_engine_trace->TraceRay(
		Ray(explosion_origin_adjusted, explosion_origin_adjusted + vec3_t(0.f, 0.f, -40.f)),
		MASK_SOLID,
		&filter,
		&tr
	);

	// pull out of the wall a bit.
	if (tr.m_fraction != 1.f)
		explosion_origin = tr.m_endpos + (tr.m_plane.m_normal * 0.6f);

	// this happens inside CCSGameRules::RadiusDamage.
	explosion_origin.z += 1.f;

	// set all other vars.
	visuals.m_planted_c4_explosion_origin = explosion_origin;

	// todo - dex;  get this radius dynamically... seems to only be available in map bsp file, search string: "info_map_parameters"
	//              info_map_parameters is an entity created on the server, it doesnt seem to have many useful networked vars for clients.
	//
	//              swapping maps between de_dust2 and de_nuke and scanning for 500 and 400 float values will leave you one value.
	//              need to figure out where it's written from.
	//
	// server.dll uses starting 'radius' as damage... the real radius passed to CCSGameRules::RadiusDamage is actually multiplied by 3.5.
	visuals.m_planted_c4_damage = 500.f;
	visuals.m_planted_c4_radius = visuals.m_planted_c4_damage * 3.5f;
	visuals.m_planted_c4_radius_scaled = visuals.m_planted_c4_radius / 3.f;
}

void events::bomb_begindefuse(i_game_event* evt) {
	player_info_t info;

	if (!g_cfg[XOR("misc_log_bomb")].get< bool >())
		return;

	// get index of player that started defusing the bomb.
	int index = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());
	if (index == cstrike.m_engine->get_local_player())
		return;

	if (!cstrike.m_engine->get_player_info(index, &info))
		return;

	bool kit = evt->m_keys->find_key(HASH("haskit"))->get_bool();

	if (kit) {
		std::string out = tfm::format(XOR("%s started defusing with a kit\n"), std::string(info.m_name).substr(0, 24));
		notify.add(out);
	}

	else {
		std::string out = tfm::format(XOR("%s started defusing without a kit\n"), std::string(info.m_name).substr(0, 24));
		notify.add(out);
	}
}

void events::bomb_abortdefuse(i_game_event* evt) {
	player_info_t info;

	if (!g_cfg[XOR("misc_log_bomb")].get< bool >())
		return;

	// get index of player that stopped defusing the bomb.
	int index = cstrike.m_engine->get_player_for_userid(evt->m_keys->find_key(HASH("userid"))->get_int());
	if (index == cstrike.m_engine->get_local_player())
		return;

	if (!cstrike.m_engine->get_player_info(index, &info))
		return;

	std::string out = tfm::format(XOR("%s stopped defusing\n"), std::string(info.m_name).substr(0, 24));
	notify.add(out);
}

void events::bomb_exploded(i_game_event* evt) {
	visuals.m_c4_planted = false;
	visuals.m_planted_c4 = nullptr;
}

void events::bomb_defused(i_game_event* evt) {
	visuals.m_c4_planted = false;
	visuals.m_planted_c4 = nullptr;
}

void Listener::init() {
	// link events with callbacks.
	add(XOR("round_start"), events::round_start);
	add(XOR("round_end"), events::round_end);
	add(XOR("player_hurt"), events::player_hurt);
	add(XOR("bullet_impact"), events::bullet_impact);
	add(XOR("item_purchase"), events::item_purchase);
	add(XOR("player_death"), events::player_death);
	add(XOR("player_given_c4"), events::player_given_c4);
	add(XOR("bomb_beginplant"), events::bomb_beginplant);
	add(XOR("bomb_abortplant"), events::bomb_abortplant);
	add(XOR("bomb_planted"), events::bomb_planted);
	add(XOR("bomb_beep"), events::bomb_beep);
	add(XOR("bomb_begindefuse"), events::bomb_begindefuse);
	add(XOR("bomb_abortdefuse"), events::bomb_abortdefuse);
	add(XOR("bomb_exploded"), events::bomb_exploded);
	add(XOR("bomb_defused"), events::bomb_defused);

	register_events();
}