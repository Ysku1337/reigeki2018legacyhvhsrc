#pragma once

class c_simulation_data
{
public:
	c_simulation_data() : entity(nullptr), flags(0), simtime(0.f)
	{
	}

	/*~C_Simulationdata()
	{
	}*/

	c_base_player* entity;

	vec3_t origin;
	vec3_t velocity;
	vec3_t mins;
	vec3_t maxs;
	float simtime;

	int flags;
	bool on_ground = false;
	bool extrapolation = false;

	bool data_filled = false;
};


class c_lag_compensation {
public:
	enum lag_type : size_t {
		invalid = 0,
		constant,
		adaptive,
		random,
	};

public:
	bool start_lag_compensation(c_aim_player* player);
	int fix_tickcount(const float& simtime);
	float get_lerp_time();
	void update_lerp();
	bool valid_simtime(const float& simtime);
	bool is_tick_valid(int tick);
	void overwrite_tick(c_aim_player* data, c_base_player* player, c_lag_record* overwrite_record, ang_t angles, float_t correct_time);
	void simulate_movement(c_simulation_data& data);
	bool extrapolate(c_base_player* entity, c_lag_record* record, float time, c_aim_player* data);

};

extern c_lag_compensation lagcomp;