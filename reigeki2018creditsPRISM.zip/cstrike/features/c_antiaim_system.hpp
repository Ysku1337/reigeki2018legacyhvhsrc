//#pragma once
//
//class c_adaptive_angle {
//public:
//	float m_yaw;
//	float m_dist;
//
//public:
//	// ctor.
//	__forceinline c_adaptive_angle(float yaw, float penalty = 0.f) {
//		// set yaw.
//		m_yaw = math::normalized_angle(yaw);
//
//		// init distance.
//		m_dist = 0.f;
//
//		// remove penalty.
//		m_dist -= penalty;
//	}
//};
//
//enum antiaim_mode : size_t {
//	stand = 0,
//	walk,
//	air,
//};
//
//struct auto_target_t { float fov; c_base_player* player; };
//
//class c_antiaim_system {
//public:
//	size_t m_mode;
//	int    m_pitch;
//	int    m_yaw;
//	float  m_jitter_range;
//	float  m_rot_range;
//	float  m_rot_speed;
//	float  m_rand_update;
//	int    m_dir;
//	float  m_dir_custom;
//	size_t m_base_angle;
//	float  m_auto_time;
//
//	bool   m_step_switch;
//	int    m_random_lag;
//	float  m_next_random_update;
//	float  m_random_angle;
//	float  m_direction;
//	float  m_auto;
//	float  m_auto_dist;
//	float  m_auto_last;
//	float  m_view;
//
//public:
//	void ideal_pitch();
//	void init_pitch();
//	void run_auto_direction();
//	void get_anti_aim_direction();
//	bool run_edge_anti_aim(c_base_player* player, ang_t& out);
//	void run_real_anti_aim();
//	void run_fake_anti_aim();
//	void anti_aim_init();
//	void sendpacket();
//};
//
//extern c_antiaim_system antiaim;