#pragma once

namespace penetration {
	struct PenetrationInput_t {
		c_base_player* m_from;
		c_base_player* m_target;
		vec3_t  m_pos;
		float	m_damage;
		float   m_damage_pen;
		bool	m_can_pen;
	};

	struct PenetrationOutput_t {
		c_base_player* m_target;
		float   m_damage;
		int     m_hitgroup;
		bool    m_pen;

		__forceinline PenetrationOutput_t() : m_target{ nullptr }, m_damage{ 0.f }, m_hitgroup{ -1 }, m_pen{ false } {}
	};

	float scale(c_base_player* player, float damage, float armor_ratio, int hitgroup);
	bool  trace_to_exit(const vec3_t& start, const vec3_t& dir, vec3_t& out, c_game_trace* enter_trace, c_game_trace* exit_trace);
	void  clip_trace_to_player(const vec3_t& start, const vec3_t& end, uint32_t mask, c_game_trace* tr, c_base_player* player, float min);
	bool  run(PenetrationInput_t* in, PenetrationOutput_t* out);
}