#include "../project.hpp"

c_aimbot_system aimbot{ };;

void c_aimbot_system::init() {
	// clear old targets.
	m_targets.clear();

	m_target = nullptr;
	m_aim = vec3_t{ };
	m_angle = ang_t{ };
	m_damage = 0.f;
	m_record = nullptr;
	m_stop = false;

	m_best_dist = std::numeric_limits< float >::max();
	m_best_fov = 180.f + 1.f;
	m_best_damage = 0.f;
	m_best_hp = 100 + 1;
	m_best_lag = std::numeric_limits< float >::max();
	m_best_height = std::numeric_limits< float >::max();
}

void c_aimbot_system::strip_attack() {
	if (ctx.m_weapon_id == REVOLVER)
		return;
	else
		ctx.m_cmd->m_buttons &= ~IN_ATTACK;
}

void c_aimbot_system::think() {

	// update config values.
	update_config();

	// do all startup routines.
	init();

	// sanity.
	if (!ctx.m_weapon)
		return;

	// no grenades or bomb.
	if (ctx.m_weapon_type == WEAPONTYPE_GRENADE || ctx.m_weapon_type == WEAPONTYPE_C4)
		return;

	if (!ctx.m_weapon_fire)
		strip_attack();

	// we have no aimbot enabled.
	if (!g_cfg[XOR("aimbot_enable")].get< bool >())
		return;

	// animation silent aim, prevent the ticks with the shot in it to become the tick that gets processed.
	// we can do this by always choking the tick before we are able to shoot.
	bool revolver = ctx.m_weapon_id == REVOLVER && ctx.m_revolver_cock != 0;

	// one tick before being able to shoot.
	if (revolver && ctx.m_revolver_cock > 0 && ctx.m_revolver_cock == ctx.m_revolver_query) {
		*ctx.m_packet = false;
		return;
	}

	// we have a normal weapon or a non cocking revolver
	// choke if its the processing tick.
	if (ctx.m_weapon_fire && !ctx.m_lag && !revolver) {
		*ctx.m_packet = false;
		strip_attack();
		return;
	}

	// no point in aimbotting if we cannot fire this tick.
	if (!ctx.m_weapon_fire)
		return;

	// setup bones for all valid targets.
	for (int i{ 1 }; i <= cstrike.m_globals->m_max_clients; ++i) {
		c_base_player* player = cstrike.m_entlist->get_client_entity< c_base_player* >(i);

		if (!is_valid_target(player))
			continue;

		c_aim_player* data = &m_players[i - 1];
		if (!data)
			continue;

		// store player as potential target this tick.
		m_targets.emplace_back(data);
	}

	// run knifebot.
	if (ctx.m_weapon_type == WEAPONTYPE_KNIFE && ctx.m_weapon_id != ZEUS) {

		if (g_cfg[XOR("aimbot_zeusbot")].get< bool >())
			knife();

		return;
	}

	// scan available targets... if we even have any.
	find();

	// finally set data when shooting.
	apply();
}

void c_aimbot_system::find() {
	struct BestTarget_t { c_base_player* player; vec3_t pos; float damage; c_lag_record* record; };

	vec3_t       tmp_pos;
	float        tmp_damage;
	BestTarget_t best;
	best.player = nullptr;
	best.damage = -1.f;
	best.pos = vec3_t{ };
	best.record = nullptr;

	if (m_targets.empty())
		return;

	if (ctx.m_weapon_id == ZEUS && !g_cfg[XOR("aimbot_zeusbot")].get< bool >())
		return;

	// iterate all targets.
	for (const auto& t : m_targets) {
		if (t->m_records.empty())
			continue;

		// this player broke lagcomp.
		// his bones have been resetup by our lagcomp.
		// therfore now only the front record is valid.
		if (g_cfg[XOR("aimbot_zeusbot")].get< bool >() && lagcomp.start_lag_compensation(t)) {
			c_lag_record* front = t->m_records.front().get();

			t->setup_hitboxes(front, false);
			if (t->m_hitboxes.empty())
				continue;

			// rip something went wrong..
			if (t->get_best_aim_position(tmp_pos, tmp_damage, front) && select_target(front, tmp_pos, tmp_damage)) {

				// if we made it so far, set shit.
				best.player = t->m_player;
				best.pos = tmp_pos;
				best.damage = tmp_damage;
				best.record = front;
			}
		}

		// player did not break lagcomp.
		// history aim is possible at this point.
		else {
			c_lag_record* ideal = resolver.find_ideal_record(t);
			if (!ideal)
				continue;

			t->setup_hitboxes(ideal, false);
			if (t->m_hitboxes.empty())
				continue;

			// try to select best record as target.
			if (t->get_best_aim_position(tmp_pos, tmp_damage, ideal) && select_target(ideal, tmp_pos, tmp_damage)) {
				// if we made it so far, set shit.
				best.player = t->m_player;
				best.pos = tmp_pos;
				best.damage = tmp_damage;
				best.record = ideal;
			}

			c_lag_record* last = resolver.find_last_record(t);
			if (!last || last == ideal)
				continue;

			t->setup_hitboxes(last, true);
			if (t->m_hitboxes.empty())
				continue;

			// rip something went wrong..
			if (t->get_best_aim_position(tmp_pos, tmp_damage, last) && select_target(last, tmp_pos, tmp_damage)) {
				// if we made it so far, set shit.
				best.player = t->m_player;
				best.pos = tmp_pos;
				best.damage = tmp_damage;
				best.record = last;
			}
		}
	}

	// verify our target and set needed data.
	if (best.player && best.record) {
		// calculate aim angle.
		math::vector_angles(best.pos - ctx.m_shoot_pos, m_angle);

		// set member vars.
		m_target = best.player;
		m_aim = best.pos;
		m_damage = best.damage;
		m_record = best.record;

		// write data, needed for traces / etc.
		m_record->cache();

		// set autostop shit.
		m_stop = !(ctx.m_buttons & IN_JUMP);

		bool on = true;
		bool hit = (!ctx.m_ground && ctx.m_weapon && ctx.m_weapon_id == SSG08 && g_cfg[XOR("aimbot_jumpscout")].get< bool >() && ctx.m_weapon->get_innacuracy() < 0.009f) 
			|| (on && aimbot.check_hitchance(m_target, m_angle));


		// if we can scope.
		bool can_scope = !ctx.m_local->m_bIsScoped() && (ctx.m_weapon_id == AUG || ctx.m_weapon_id == SG553 || ctx.m_weapon_type == WEAPONTYPE_SNIPER_RIFLE);

		if (can_scope) {
			// always.
			if (m_autoscope) {
				ctx.m_cmd->m_buttons |= IN_ATTACK2;
				return;
			}
		}


		if (hit || !on) {
			//// right click attack.
			//if (g_menu.main.config.mode.get() == 1 && ctx.m_weapon_id == REVOLVER)
			//	ctx.m_cmd->m_buttons |= IN_ATTACK2;

			//// left click attack.
			//else
				ctx.m_cmd->m_buttons |= IN_ATTACK;
		}
	}
}

bool c_aimbot_system::check_hitchance(c_base_player* player, const ang_t& angle) {
	auto weapon = ctx.m_weapon;
	auto chance = m_minimum_hitchance;

	if (!weapon)
		return false;

	if (chance < 1.f)
		return true;

	auto weap_data = weapon->get_weapon_data();

	vec3_t forward, right, up, eye_position;
	ctx.m_local->get_eye_position(&eye_position);
	math::angle_vectors(angle, &forward, &right, &up);

	int trace_hits = 0;
	int needed_hits = static_cast<int>(128.f * (chance / 100.f));

	weapon->update_accuracy_penalty();
	float weapon_spread = weapon->get_spread();
	float weapon_innacuracy = weapon->get_innacuracy();
	auto recoil_index = weapon->m_flRecoilIndex();

	if (weapon_spread <= 0.f)
		return true;

	for (int i = 0; i < 128; i++)
	{
		float a = cstrike.RandomFloat(0.f, 1.f);
		float b = cstrike.RandomFloat(0.f, 6.2831855f);
		float c = cstrike.RandomFloat(0.f, 1.f);
		float d = cstrike.RandomFloat(0.f, 6.2831855f);

		float inac = a * weapon_innacuracy;
		float sir = c * weapon_spread;

		if (weapon->m_iItemDefinitionIndex() == 64)
		{
			a = 1.f - a * a;
			a = 1.f - c * c;
		}
		else if (weapon->m_iItemDefinitionIndex() == 28 && recoil_index < 3.0f)
		{
			for (int i = 3; i > recoil_index; i--)
			{
				a *= a;
				c *= c;
			}

			a = 1.0f - a;
			c = 1.0f - c;
		}


		else if (!(ctx.m_local->m_fFlags() & FL_ONGROUND) && weapon->m_iItemDefinitionIndex() == 40)
		{
			if (weapon->get_innacuracy() < 0.009f)
			{
				return true;
			}
		}

		vec3_t sir_vec((cos(b) * inac) + (cos(d) * sir), (sin(b) * inac) + (sin(d) * sir), 0), direction;

		direction.x = forward.x + (sir_vec.x * right.x) + (sir_vec.y * up.x);
		direction.y = forward.y + (sir_vec.x * right.y) + (sir_vec.y * up.y);
		direction.z = forward.z + (sir_vec.x * right.z) + (sir_vec.y * up.z);
		direction.normalize();

		ang_t view_angles_spread;
		math::vector_angles(direction, view_angles_spread, &up);
		view_angles_spread.normalize();

		vec3_t view_forward;
		math::angle_vectors(view_angles_spread, &view_forward);
		view_forward.normalized();

		view_forward = eye_position + (view_forward * weap_data->m_range);

		c_game_trace tr;

		// glass fix
		cstrike.m_engine_trace->clip_ray_to_entity(Ray(eye_position, view_forward), MASK_SHOT | CONTENTS_GRATE | CONTENTS_WINDOW, player, &tr);

		// additional checks if we are actually hitting that specific hitbox.
		if (tr.m_entity == player)
			++trace_hits;

		// adding manual accuracy boost calculation here
		//if (static_cast<int>((static_cast<float>(trace_hits) / 128.f) * 100.f) >= chance) {
		//	if (((static_cast<float>(trace_hits) / static_cast<float>(128.f)) >= (g_menu.main.aimbot.accuracy_boost_amount.get() / 100.f)) || g_menu.main.aimbot.accuracy_boost_amount.get() <= 1.f)
		//		return true;
		//}

		if ((128 - i + trace_hits) < needed_hits)
			return false;
	}
	return false;
}

bool c_aimbot_system::select_target(c_lag_record* record, const vec3_t& aim, float damage) {
	float dist, fov;

	switch (g_cfg[XOR("aimbot_target_selection")].get<int>()) {

		// crosshair.
	case 0:
		fov = math::get_fov(ctx.m_view_angles, ctx.m_shoot_pos, aim);

		if (fov < m_best_fov) {
			m_best_fov = fov;
			return true;
		}

		break;

		// distance.
	case 1:
		dist = ctx.m_shoot_pos.dist_to(record->m_old_origin);

		if (dist < m_best_dist) {
			m_best_dist = dist;
			return true;
		}

		break;

		// damage.
	case 2:
		if (damage > m_best_damage) {
			m_best_damage = damage;
			return true;
		}

		break;

	default:
		return false;
	}

	return false;
}

void c_aimbot_system::apply() {
	bool attack, attack2;

	// attack states.
	attack = (ctx.m_cmd->m_buttons & IN_ATTACK);
	attack2 = (ctx.m_weapon_id == REVOLVER && ctx.m_cmd->m_buttons & IN_ATTACK2);

	// ensure we're attacking.
	if (attack || attack2) {
		// choke every shot.
		*ctx.m_packet = false;

		if (m_target) {
			// make sure to aim at un-interpolated data.
			// do this so BacktrackEntity selects the exact record.
			if (m_record && !m_record->m_broke_lc)
				ctx.m_cmd->m_tick = game::time_to_ticks(m_record->m_sim_time + ctx.m_lerp);

			// set angles to target.
			ctx.m_cmd->m_view_angles = m_angle;

			// if not silent aim, apply the viewangles.
			if (!g_cfg[XOR("aimbot_silent")].get<bool>())
				cstrike.m_engine->set_view_angles(m_angle);

			//visuals.draw_hitgroup(m_record, colors::white, 10.f);
		}


		    // norecoil.
			ctx.m_cmd->m_view_angles -= ctx.m_local->m_aimPunchAngle() * cstrike.weapon_recoil_scale->get_float();

		// store fired shot.
		shots.on_shot_fire(m_target ? m_target : nullptr, m_target ? m_damage : -1.f, ctx.m_weapon_info->m_bullets, m_target ? m_record : nullptr);

		// set that we fired.
		ctx.m_shot = true;
	}
}

void c_aimbot_system::apply_nospread() {
	bool    attack2;
	vec3_t  spread, forward, right, up, dir;

	// revolver state.
	attack2 = (ctx.m_weapon_id == REVOLVER && (ctx.m_cmd->m_buttons & IN_ATTACK2));

	// get spread.
	spread = ctx.m_weapon->calculate_spread(ctx.m_cmd->m_random_seed, attack2);

	// compensate.
	ctx.m_cmd->m_view_angles -= { -math::rad_to_deg(std::atan(spread.length_2d())), 0.f, math::rad_to_deg(std::atan2(spread.x, spread.y)) };
}

void c_aimbot_system::update_config() {

	const char* weapon_name = XOR("gen");

	if (!ctx.m_local || !ctx.m_weapon)
		goto GENERAL;

	// get weapon name.
	if (g_cfg[XOR("aimbot_adaptive_config")].get< bool >()) {
		switch (ctx.m_local->get_active_weapon()->m_iItemDefinitionIndex()) {
		case weapons_t::GLOCK: case weapons_t::USPS: case weapons_t::FIVESEVEN:
		case weapons_t::P250: case weapons_t::TEC9:
		case weapons_t::ELITE: weapon_name = XOR("pistol"); break;
		case weapons_t::REVOLVER: case weapons_t::DEAGLE: weapon_name = XOR("r8"); break;
		case weapons_t::SSG08: weapon_name = XOR("ssg08"); break;
		case weapons_t::SCAR20: case weapons_t::G3SG1: weapon_name = XOR("auto");  break;
		case weapons_t::AWP: weapon_name = XOR("awp"); break;
		default: weapon_name = XOR("other"); break;
		}
	}
GENERAL:

	m_autostop = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("autostop")))].get<bool>();
	m_minimum_hitchance = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("hc")))].get<int>();
	m_overriden_hitchance = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("overriden_hc")))].get<int>();
	m_minimum_damage = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("min_dmg")))].get<int>();
	m_minimum_penetration_damage = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("min_penetration_dmg")))].get<int>();
	m_overriden_damage = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("overriden_min_dmg")))].get<int>();
	m_autoscope = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("autoscope")))].get<bool>();
	m_between_shots = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("autostop_between")))].get<bool>();
	m_force_accuracy = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("autostop_force")))].get<bool>();
	m_in_air = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("autostop_air")))].get<bool>();
	m_duck = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("autostop_duck")))].get<bool>();

	m_bodyscale = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("bodyscale")))].get<int>();
	m_headscale = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("headscale")))].get<int>();

	m_normal_hitboxes.head = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("hitbox_head")))].get<bool>();
	m_normal_hitboxes.neck = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("hitbox_upper_body")))].get<bool>();
	m_normal_hitboxes.upper_chest = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("hitbox_upper_chest")))].get<bool>();
	m_normal_hitboxes.body = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("hitbox_lower_body")))].get<bool>();
	m_normal_hitboxes.stomach = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("hitbox_stomach")))].get<bool>();
	m_normal_hitboxes.feet = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("hitbox_legs")))].get<bool>();
	m_normal_hitboxes.legs = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("hitbox_feet")))].get<bool>();

	m_multipoint_hitboxes.head = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("mutlipoint_hitbox_head")))].get<bool>();
	m_multipoint_hitboxes.neck = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("mutlipoint_hitbox_upper_body")))].get<bool>();
	m_multipoint_hitboxes.upper_chest = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("mutlipoint_hitbox_upper_chest")))].get<bool>();
	m_multipoint_hitboxes.body = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("mutlipoint_hitbox_lower_body")))].get<bool>();
	m_multipoint_hitboxes.stomach = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("mutlipoint_hitbox_stomach")))].get<bool>();
	m_multipoint_hitboxes.feet = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("mutlipoint_hitbox_legs")))].get<bool>();
	m_multipoint_hitboxes.legs = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("mutlipoint_hitbox_feet")))].get<bool>();

	m_priority_hitbox = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("priority_hitbox")))].get<int>();

	m_body_in_air = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("body_in_air")))].get<bool>();
	m_body_on_crouch = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("body_on_crouch")))].get<bool>();
	m_body_lethal = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("body_lethal")))].get<bool>();
	m_body_lethal2 = g_cfg[std::string(XOR("aimbot_") + std::string(weapon_name) + std::string(XOR("_")) + std::string(XOR("body_lethal2")))].get<bool>();

}