#pragma once

// pre-declares.
class c_recv_proxy_data;
class recv_prop;
class recv_table;

// prototypes.
// these are networkable entity ptrs.
using create_client_class_t = void*( __cdecl* )( int index, int serial );
using create_event_t       = void*( __cdecl* )( );

// other prototypes.
using array_length_recv_proxy_t  = void( __cdecl* )( void* ptr, int id, int len );
using recv_var_proxy_t          = void( __cdecl* )( c_recv_proxy_data* data, void* struct_ptr, void* out );
using data_table_recv_var_proxy_t = void( __cdecl* )( recv_prop* prop, void** out, void* data, int id );

// types of props.
enum send_prop_type {
	DPT_Int = 0,
	DPT_Float,
	DPT_Vector,
	DPT_String,
	DPT_Array,
	DPT_DataTable
};

class recv_prop {
public:
	char					*m_pVarName;
	int						 m_RecvType;
	int						 m_Flags;
	int						 m_StringBufferSize;
	bool					 m_bInsideArray;
	const void*				 m_pExtraData;
	recv_prop				    *m_pArrayProp;
	array_length_recv_proxy_t	 m_ArrayLengthProxy;
	recv_var_proxy_t			 m_ProxyFn;
	data_table_recv_var_proxy_t	 m_DataTableProxyFn;
	recv_table				*m_pDataTable;
	int						 m_Offset;
	int						 m_ElementStride;
	int						 m_nElements;
	const char				*m_pParentArrayPropName;
};

class recv_table {
public:
	recv_prop		*m_pProps;
	int				 m_nProps;
	void*			 m_pDecoder;
	char			*m_pNetTableName;
	bool			 m_bInitialized;
	bool			 m_bInMainList;
};

class client_class {
public:
	create_client_class_t   m_pCreate;
	create_event_t	        m_pCreateEvent;
	char*			    	m_pNetworkName;
	recv_table*		    	m_pRecvTable;
	client_class*		    m_pNext;
	int					    m_ClassID;
};

class d_variant {
public:
	union {
		float	     m_Float;
		long	     m_Int;
		char		*m_pString;
		void		*m_pData;
		float	     m_Vector[ 3 ];
		long long	 m_Int64;
	};

	send_prop_type     m_Type;
};

class c_recv_proxy_data {
public:
	const recv_prop	*m_pRecvProp;
	d_variant		 m_Value;
	int				 m_iElement;
	int				 m_ObjectID;
};