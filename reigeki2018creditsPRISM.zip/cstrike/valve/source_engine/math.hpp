#pragma once

namespace math {
    // pi constants.
    constexpr float pi   = 3.1415926535897932384f; // pi
    constexpr float pi_2 = pi * 2.f;               // pi * 2

    // degrees to radians.
    __forceinline constexpr float deg_to_rad( float val ) {
        return val * ( pi / 180.f );
    }

    // radians to degrees.
    __forceinline constexpr float rad_to_deg( float val ) {
        return val * ( 180.f / pi );
    }

    // angle mod ( shitty normalize ).
    __forceinline float angle_mod( float angle ) {
        return ( 360.f / 65536 ) * ( ( int )( angle * ( 65536.f / 360.f ) ) & 65535 );
    }

    void angle_matrix( const ang_t& ang, const vec3_t& pos, matrix3x4_t& out );

    // normalizes an angle.
    void normalize_angle( float &angle );

    float normalize_yaw(float angle);

    __forceinline float normalized_angle( float angle ) {
        normalize_angle( angle );
        return angle;
    }

    static float normalize_float(float angle)
    {
        auto revolutions = angle / 360.f;
        if (angle > 180.f || angle < -180.f)
        {
            revolutions = round(abs(revolutions));
            if (angle < 0.f)
                angle = (angle + 360.f * revolutions);
            else
                angle = (angle - 360.f * revolutions);
            return angle;
        }
        return angle;
    }

    float approach_angle( float target, float value, float speed );
    vec3_t calc_angle(const vec3_t& vecSource, const vec3_t& vecDestination);
    void  calculate_angle(const vec3_t src, const vec3_t dst, ang_t& angles);
    void  vector_angles( const vec3_t& forward, ang_t& angles, vec3_t* up = nullptr );
    void  angle_vectors( const ang_t& angles, vec3_t* forward, vec3_t* right = nullptr, vec3_t* up = nullptr );
    float get_fov( const ang_t &view_angles, const vec3_t &start, const vec3_t &end );
    void  vector_transform( const vec3_t& in, const matrix3x4_t& matrix, vec3_t& out );
    void  vector_i_transform( const vec3_t& in, const matrix3x4_t& matrix, vec3_t& out );
    void  matrix_angles( const matrix3x4_t& matrix, ang_t& angles );
    void  matrix_copy( const matrix3x4_t &in, matrix3x4_t &out );
    void  concat_transforms( const matrix3x4_t &in1, const matrix3x4_t &in2, matrix3x4_t &out );

    // computes the intersection of a ray with a box ( AABB ).
    bool intersect_ray_with_box( const vec3_t &start, const vec3_t &delta, const vec3_t &mins, const vec3_t &maxs, float tolerance, box_trace_info_t *out_info );
    bool intersect_ray_with_box( const vec3_t &start, const vec3_t &delta, const vec3_t &mins, const vec3_t &maxs, float tolerance, c_base_trace *out_tr, float *fraction_left_solid = nullptr );

    // computes the intersection of a ray with a oriented box ( OBB ).
    bool intersect_ray_with_obb( const vec3_t &start, const vec3_t &delta, const matrix3x4_t &obb_to_world, const vec3_t &mins, const vec3_t &maxs, float tolerance, c_base_trace *out_tr );
    bool intersect_ray_with_obb( const vec3_t &start, const vec3_t &delta, const vec3_t &box_origin, const ang_t &box_rotation, const vec3_t &mins, const vec3_t &maxs, float tolerance, c_base_trace *out_tr );

    // returns whether or not there was an intersection of a sphere against an infinitely extending ray. 
    // returns the two intersection points.
    bool intersect_infinite_ray_with_sphere( const vec3_t &start, const vec3_t &delta, const vec3_t &sphere_center, float radius, float *out_t1, float *out_t2 );

    // returns whether or not there was an intersection, also returns the two intersection points ( clamped 0.f to 1.f. ).
    // note: the point of closest approach can be found at the average t value.
    bool intersect_ray_with_sphere( const vec3_t &start, const vec3_t &delta, const vec3_t &sphere_center, float radius, float *out_t1, float *out_t2 );

	vec3_t interpolate( const vec3_t from, const vec3_t to, const float percent );

    template < typename t >
    __forceinline void clamp( t& n, const t& lower, const t& upper ) {
        n = std::max( lower, std::min( n, upper ) );
    }
}