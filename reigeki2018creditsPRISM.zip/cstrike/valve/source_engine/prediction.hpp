#pragma once

class c_move_data {
public:
	bool          m_bFirstRunOfFunctions : 1;
	bool          m_bGameCodeMovedPlayer : 1;
	bool          m_bNoAirControl : 1;
	c_base_handle m_nPlayerHandle;
	int           m_nImpulseCommand;
	ang_t         m_vecViewAngles;
	ang_t         m_vecAbsViewAngles;
	int           m_nButtons;
	int           m_nOldButtons;
	float         m_flForwardMove;
	float         m_flSideMove;
	float         m_flUpMove;
	float         m_flMaxSpeed;
	float         m_flClientMaxSpeed;
	vec3_t        m_vecVelocity;
	vec3_t        m_vecOldVelocity;
	float         m_unknown;
	ang_t         m_vecAngles;
	ang_t         m_vecOldAngles;
	float         m_outStepHeight;
	vec3_t        m_outWishVel;
	vec3_t        m_outJumpVel;
	vec3_t        m_vecConstraintCenter;
	float         m_flConstraintRadius;
	float         m_flConstraintWidth;
	float         m_flConstraintSpeedFactor;
	bool          m_bConstraintPastRadius;
	vec3_t        m_vecAbsOrigin;
};

class i_move_helper {
public:
	// indexes for virtuals and hooks.
	enum indices : size_t {
		SETHOST = 1,
	};

	__forceinline void set_host( entity_t* host ) {
		return util::get_method< void( __thiscall* )( decltype( this ), entity_t* ) >( this, SETHOST )( this, host );
	}
};

class c_prediciton {
public:
	// indexes for virtuals and hooks.
	enum indices : size_t {
		UPDATE                  = 3,
        POSTNETWORKDATARECEIVED = 6,
		SETLOCALVIEWANGLES      = 13,
		INPREDICTION            = 14,
		RUNCOMMAND              = 19,
		SETUPMOVE               = 20,
		FINISHMOVE              = 21
	};

public:
	PAD( 0x4 );
	int32_t m_last_ground;				// 0x0004
	bool    m_in_prediction;			// 0x0008
	bool    m_first_time_predicted;		// 0x0009
	bool    m_engine_paused;			// 0x000A
	bool    m_old_cl_predict_value;		// 0x000B
	int32_t m_previous_startframe;		// 0x000C
	int32_t m_commands_predicted;		// 0x0010
	PAD( 0x38 );						// 0x0014
	float   m_backup_realtime;			// 0x004C
	PAD( 0xC );							// 0x0050
	float   m_backup_curtime;			// 0x005C
	PAD( 0xC );							// 0x0060
	float   m_backup_interval;			// 0x006C

public:
	// virtual methods
	__forceinline void update( int startframe, bool validframe, int incoming_acknowledged, int outgoing_command ) {
		return util::get_method< void( __thiscall* )( void*, int, bool, int, int ) >( this, UPDATE )( this, startframe, validframe, incoming_acknowledged, outgoing_command );
	}

	__forceinline void set_local_view_angles( const ang_t& ang ) {
		return util::get_method< void( __thiscall* )( decltype( this ), const ang_t& ) >( this, SETLOCALVIEWANGLES )( this, ang );
	}

	__forceinline void setup_move( entity_t* player, c_user_cmd* cmd, i_move_helper* helper, c_move_data* data ) {
		return util::get_method< void( __thiscall* )( decltype( this ), entity_t*, c_user_cmd*, i_move_helper*, c_move_data* ) >( this, SETUPMOVE )( this, player, cmd, helper, data );
	}

	__forceinline void finish_move( entity_t* player, c_user_cmd* cmd, c_move_data* data ) {
		return util::get_method< void( __thiscall* )( decltype( this ), entity_t*, c_user_cmd*, c_move_data* ) >( this, FINISHMOVE )( this, player, cmd, data );
	}
};

class c_game_movement {
public:
	// indexes for virtuals and hooks
	enum indices : size_t {
		PROCESSMOVEMENT             = 1,
		STARTTRACKPREDICTIONERRORS  = 3,
		FINISHTRACKPREDICTIONERRORS = 4,
		ONLAND                      = 32,
	    GETPLAYERVIEWOFFSET			= 8
	};

	__forceinline void process_movement( entity_t* player, c_move_data* data ) {
		return util::get_method< void( __thiscall* )( decltype( this ), entity_t*, c_move_data* ) >( this, PROCESSMOVEMENT )( this, player, data );
	}

	__forceinline void start_track_prediction_errors( entity_t* player ) {
		return util::get_method< void( __thiscall* )( decltype( this ), entity_t* ) >( this, STARTTRACKPREDICTIONERRORS )( this, player );
	}

	__forceinline void finish_track_prediction_errors( entity_t* player ) {
		return util::get_method< void( __thiscall* )( decltype( this ), entity_t* ) >( this, FINISHTRACKPREDICTIONERRORS )( this, player );
	}

	__forceinline vec3_t const& get_player_view_offset(bool ducked) {
		return util::get_method< vec3_t const& (__thiscall*)(decltype(this), bool) >(this, GETPLAYERVIEWOFFSET)(this, ducked);
	}
};