#pragma once

class c_match_session_online_host {
public:
};

class c_match_framework {
public:
	enum indices : size_t {
		GETMATCHSESSION = 13,
	};
};