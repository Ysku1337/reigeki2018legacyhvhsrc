#pragma once

class entity_t;

#define NUM_ENT_ENTRY_BITS			(11 + 2)
#define NUM_ENT_ENTRIES				(1 << NUM_ENT_ENTRY_BITS)
#define INVALID_EHANDLE_INDEX		0xFFFFFFFF
#define NUM_SERIAL_NUM_BITS			16
#define NUM_SERIAL_NUM_SHIFT_BITS	(32 - NUM_SERIAL_NUM_BITS)
#define ENT_ENTRY_MASK				(( 1 << NUM_SERIAL_NUM_BITS) - 1)

class c_base_handle {
public:
	__forceinline c_base_handle( ) {
		m_Index = INVALID_EHANDLE_INDEX;
	}

	__forceinline c_base_handle( const c_base_handle& other ) {
		m_Index = other.m_Index;
	}

	__forceinline c_base_handle( ulong_t value ) {
		m_Index = value;
	}

	__forceinline c_base_handle( int iEntry, int iSerialNumber ) {
		init( iEntry, iSerialNumber );
	}

	__forceinline void init( int iEntry, int iSerialNumber ) {
		m_Index = iEntry | ( iSerialNumber << NUM_SERIAL_NUM_SHIFT_BITS );
	}

	__forceinline void term( ) {
		m_Index = INVALID_EHANDLE_INDEX;
	}

	__forceinline bool is_valid( ) const {
		return m_Index != INVALID_EHANDLE_INDEX;
	}

	__forceinline int get_entry_index( ) const {
		if( !is_valid( ) )
			return NUM_ENT_ENTRIES - 1;

		return m_Index & ENT_ENTRY_MASK;
	}

	__forceinline int get_serial_number( ) const {
		return m_Index >> NUM_SERIAL_NUM_SHIFT_BITS;
	}

	__forceinline int to_int( ) const {
		return ( int )( m_Index );
	}

	__forceinline bool operator !=( const c_base_handle& other ) const {
		return m_Index != other.m_Index;
	}

	__forceinline bool operator ==( const c_base_handle& other ) const {
		return m_Index == other.m_Index;
	}

	__forceinline bool operator ==( const void* pEnt ) const {
		return get( ) == pEnt;
	}

	__forceinline bool operator !=( const void* pEnt ) const {
		return get( ) != pEnt;
	}

	__forceinline const c_base_handle& operator=( const void* pEntity ) {
		return set( pEntity );
	}

	__forceinline const c_base_handle& set( const void* pEntity ) {
		if( !pEntity )
			m_Index = INVALID_EHANDLE_INDEX;

		return *this;
	}

	__forceinline void* c_base_handle::get( ) const {
		return nullptr;
	}

	ulong_t m_Index;
};

template< class t > class c_handle : public c_base_handle {
public:
	__forceinline c_handle( ) {}

	__forceinline c_handle( int iEntry, int iSerialNumber ) {
		init( iEntry, iSerialNumber );
	}

	__forceinline c_handle( const c_base_handle& handle ) : c_base_handle( handle ) {}

	__forceinline c_handle( t* pObj ) {
		term( );
		set( pObj );
	}

	__forceinline c_handle< t > from_index( int index ) {
		c_handle< t > ret;
		ret.m_Index = index;
		return ret;
	}

	__forceinline t* get( ) const {
		return ( t * )(c_base_handle::get( ) );
	}

	__forceinline operator t*( ) {
		return get( );
	}

	__forceinline operator t*( ) const {
		return get( );
	}

	__forceinline bool operator !( ) const {
		return !get( );
	}

	__forceinline bool operator==( t* val ) const {
		return get( ) == val;
	}

	__forceinline bool operator!=( t* val ) const {
		return get( ) != val;
	}

	__forceinline void set( const t* pVal ) {
		c_base_handle::set( ( const void * )( pVal ) );
	}

	__forceinline const c_base_handle& operator=( const t* val ) {
		set( val );
		return *this;
	}

	__forceinline t* operator->( ) const {
		return get( );
	}
};

using EHANDLE = c_handle< entity_t >;