#pragma once

class c_econ_item_view {
public:
};

class c_econ_item_schema {
public:
};

class c_econ_item_definition {
public:
	__forceinline const char* get_item_base_name( ) {
		return util::get_method< const char*( __thiscall* )( void* ) >( this, 2 )( this );
	}
};

class i_localize {
public:
	__forceinline const wchar_t* find( const char* token ) {
		return util::get_method< const wchar_t*( __thiscall* )( void*, const char* ) >( this, 12 )( this, token );
	}
};