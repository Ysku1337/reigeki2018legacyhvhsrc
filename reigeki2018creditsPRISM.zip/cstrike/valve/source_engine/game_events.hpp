#pragma once

enum cs_round_end_reason {
	UNKNOWN1 = 0,
	BOMB_DETONATED,			// terrorists planted bomb and it detonated.
	UNKNOWN2,
	UNKNOWN3,
	T_ESCAPED,				// dunno if used.
	CT_STOPPED_ESCAPE,		// dunno if used.
	T_STOPPED,				// dunno if used
	BOMB_DEFUSED,			// counter-terrorists defused the bomb.
	CT_WIN,					// counter-terrorists killed all terrorists.
	T_WIN,					// terrorists killed all counter-terrorists.
	ROUND_DRAW,				// draw ( likely due to time ).
	HOSTAGE_RESCUED,		// counter-terrorists rescued a hostage.
	CT_WIN_TIME,
	T_WIN_TIME,
	T_NOT_ESACPED,
	UNKNOWN4,
	GAME_START,
	T_SURRENDER,
	CT_SURRENDER,
};


class c_key_values_system {
public:
	virtual void		register_sizeof_key_values( int size ) = 0;
	virtual void*		alloc_key_values_memory( int size ) = 0;
	virtual void		free_key_values_memory( void *pMem ) = 0;
	virtual int			get_symbol_for_string( const char *name, bool bCreate = true ) = 0;
	virtual const char*	get_string_for_symbol( int symbol ) = 0;
	virtual void		add_key_values_to_memory_leak_list( void *pMem, int name ) = 0;
	virtual void		remove_key_values_to_memory_leak_list( void *pMem ) = 0;

	template< typename T = c_key_values_system* >
	static __forceinline T key_values_system( ) {
		static auto key_values_factory = PE::GetExport( PE::GetModule( HASH( "vstdlib.dll" ) ), HASH( "KeyValuesSystem" ) );
		return key_values_factory.as< T( *)( ) >( )( );
	}
};

class key_values {
protected:
	enum types_t {
		TYPE_NONE = 0,
		TYPE_STRING,
		TYPE_INT,
		TYPE_FLOAT,
		TYPE_PTR,
		TYPE_WSTRING,
		TYPE_COLOR,
		TYPE_UINT64,
		TYPE_NUMTYPES,
	};

public:
	__forceinline key_values* find_key( hash32_t hash ) {
		key_values          *dat;
		c_key_values_system *system;
		const char          *string;

		system = c_key_values_system::key_values_system( );

		if( !this || !hash || !system )
			return nullptr;

		for( dat = this->m_sub; dat != nullptr; dat = dat->m_peer ) {
			string = system->get_string_for_symbol( dat->m_key_name_id );

			if( string && FNV1a::get( string ) == hash )
				return dat;
		}

		return nullptr;
	}

	int __forceinline get_int( int default_value = 0 ) {
		int result{};

		switch( this->m_data_type ) {
		case TYPE_STRING:
			result = atoi( this->m_string );
			break;
		case TYPE_WSTRING:
			result = _wtoi( this->m_wide_string );
			break;
		case TYPE_FLOAT:
			result = ( signed int )floor( this->m_float_value );
			break;
		case TYPE_UINT64:
			result = 0;
			break;
		default:
			result = this->m_int_value;
			break;
		}

		return( result ? result : default_value );
	}

	bool __forceinline get_bool( ) {
		return !!get_int( );
	}

	float __forceinline get_float( float default_value = 0.f ) {
		switch( this->m_data_type ) {
		case TYPE_STRING:
			return ( float )atof( this->m_string );
		case TYPE_WSTRING:
			return ( float )_wtof( this->m_wide_string );
		case TYPE_FLOAT:
			return this->m_float_value;
		case TYPE_INT:
			return ( float )this->m_int_value;
		case TYPE_UINT64:
			return ( float )( *( ( uint64_t * )this->m_string ) );
		case TYPE_PTR:
		default:
			return 0.0f;
		};
	}

	uint32_t m_key_name_id : 24;
	uint32_t m_key_name_case_sensitive : 8;

	char    *m_string;
	wchar_t *m_wide_string;

	union {
		int           m_int_value;
		float         m_float_value;
		void         *m_ptr_value;
		unsigned char m_color_value[ 4 ];
	};

	char m_data_type;
	char m_has_escape_sequences;

	PAD( 0x2 );

	key_values *m_peer;
	key_values *m_sub;
	key_values *m_chain;
};

class c_game_event_callback {
public:
	void *m_callback;
	int   m_listener_type;
};

class c_game_event_descriptor {
public:
	char							     m_name[ 32 ];
	int								     m_id;
	key_values						    *m_keys;
	bool						    	 m_is_local;
	bool							     m_is_reliable;
	CUtlVector< c_game_event_callback* > m_listeners;
};

class i_game_event {
public:
	c_game_event_descriptor *m_descriptor;
	key_values			    *m_keys;

	virtual ~i_game_event( ) {};
	virtual const char *get_name( ) const = 0;
	virtual bool is_reliable( ) const = 0;
	virtual bool is_local( ) const = 0;
	virtual bool is_empty( const char *keyName = nullptr ) = 0;
	virtual bool get_bool( const char *keyName = nullptr, bool defaultValue = false ) = 0;
	virtual int get_int( const char *keyName = nullptr, int defaultValue = 0 ) = 0;
	virtual unsigned long long get_uint64( char const *keyName = nullptr, unsigned long long defaultValue = 0 ) = 0;
	virtual float get_float( const char *keyName = nullptr, float defaultValue = 0.0f ) = 0;
	virtual const char *get_string( const char *keyName = nullptr, const char *defaultValue = "" ) = 0;
	virtual const wchar_t * get_wstring( char const *keyName = nullptr, const wchar_t *defaultValue = L"" ) = 0;
	virtual void set_bool( const char *keyName, bool value ) = 0;
	virtual void set_int( const char *keyName, int value ) = 0;
	virtual void set_unit64( const char *keyName, unsigned long long value ) = 0;
	virtual void set_float( const char *keyName, float value ) = 0;
	virtual void set_string( const char *keyName, const char *value ) = 0;
	virtual void set_wstring( const char *keyName, const wchar_t *value ) = 0;
};

class i_game_event_listener2 {
public:
	virtual	~i_game_event_listener2( void ) {};
	virtual void fire_game_event( i_game_event *event ) = 0;
	virtual int get_event_debug_id( void ) {
		return m_debug_id;
	}
public:
	int	m_debug_id;
};

class i_game_event_manager2 {
public:
	CUtlVector< c_game_event_descriptor >    m_events;
	CUtlVector< c_game_event_callback* >     m_listeners;

	virtual	~i_game_event_manager2( void ) {};
	virtual int load_events_from_file( const char *filename ) = 0;
	virtual void reset( ) = 0;
	virtual bool add_listener( i_game_event_listener2 *listener, const char *name, bool bServerSide ) = 0;
	virtual bool find_listener( i_game_event_listener2 *listener, const char *name ) = 0;
	virtual void remove_listener( i_game_event_listener2 *listener ) = 0;

	/*bool __forceinline add_listener_internal( IGameEventListener2 *listener, CGameEventDescriptor *descriptor, bool serverside ) {
		// char __thiscall CGameEventManager::AddListener_Internal( void *this, int listener, int a3, bool serverside )
		// 55 8B EC 83 EC 08 8B C1 56 57

		// return GameEventManager::AddListener_Internal( this, listener, descriptor, serverside == false );
	}

	bool __forceinline add_listener_by_hash( IGameEventListener2 *listener, hash_t hash, bool serverside ) {
		CGameEventDescriptor *descriptor;

		for( int i{}; i < m_events.count( ); i++ ) {
			descriptor = &m_events.element( i );

			if( !descriptor )
				continue;

			if( hash::fnv1a( descriptor->m_name ) == hash )
				break;

			else
				descriptor = nullptr;
		}

		if( !descriptor )
			return false;

		return add_listener_internal( listener, descriptor, serverside );
	}*/
};