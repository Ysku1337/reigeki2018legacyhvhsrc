#pragma once

// pre-declare.
class entity_t;

class i_entity_listener {
public:
	virtual void on_entity_created( entity_t *ent ) = 0;
    // virtual void OnEntitySpawned( Entity *ent ) = 0; // note - dex; doesn't seem used on the client?
    virtual void on_entity_deleted( entity_t *ent ) = 0;
};

class c_ent_info {
public:
	entity_t*		m_pEntity;
	int			    m_SerialNumber;
	c_ent_info*   	m_pPrev;
	c_ent_info*	    m_pNext;
};

class i_client_entity_list {
public:
	enum indices : size_t {
		GETCLIENTENTITY = 3,
		GETCLIENTENTITYFROMHANDLE = 4,
		GETHIGHESTENTITYINDEX = 6,
	};

public:
	template< typename t = entity_t* >
	__forceinline t get_client_entity( int index ) {
		return util::get_method< t( __thiscall* )( decltype( this ), int ) >( this, GETCLIENTENTITY )( this, index );
	}

	template< typename t = entity_t* >
	__forceinline t get_client_entity_from_handle( EHANDLE handle ) {
		return util::get_method< t( __thiscall* )( decltype( this ), EHANDLE ) >( this, GETCLIENTENTITYFROMHANDLE )( this, handle );
	}

	template< typename t = entity_t* >
	__forceinline t get_client_entity_from_handle( ulong_t handle ) {
		return util::get_method< t( __thiscall* )( decltype( this ), ulong_t ) >( this, GETCLIENTENTITYFROMHANDLE )( this, handle );
	}

	__forceinline int get_highest_entity_index( ) {
		return util::get_method< int( __thiscall* )( decltype( this ) ) >( this, GETHIGHESTENTITYINDEX )( this );
	}
};