#pragma once

class i_network_string_table {
public:
    enum indices : size_t {
        FINDTABLE = 3        
	};

    __forceinline int add_string( bool is_server, const char *value, int len = -1, const void *userdata = nullptr ) {
        return util::get_method< int (__thiscall *)( void *, bool, const char *, int, const void * ) >( this, 8 )( this, is_server, value, len, userdata );
    }
};

class i_network_string_table_container {
public:
    enum indices : size_t {
        FINDTABLE = 3        
	};

    __forceinline i_network_string_table *find_table( const char *table_name ) {
        return util::get_method< i_network_string_table *(__thiscall *)( void *, const char * ) >( this, FINDTABLE )( this, table_name );
    }
};