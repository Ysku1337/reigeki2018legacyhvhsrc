#pragma once

// padding macro, please use, counts pads in class automaticly
#define CONCAT_IMPL( x, y ) x##y
#define MACRO_CONCAT( x, y ) CONCAT_IMPL( x, y )
#define PAD( size ) uint8_t MACRO_CONCAT( _pad, __COUNTER__ )[ size ];

// pre-declares.
class c_base_player;
class weapon_t;
class entity_t;
class c_weapon_info;
class matrix3x4_t;
class vec3_t;
class ang_t;

struct box_trace_info_t;
struct c_base_trace;

#include "source_engine/game_engine.hpp"
#include "source_engine/math.hpp"
#include "source_engine/vec2d.hpp"
#include "source_engine/vec3d.hpp"
#include "source_engine/angle.hpp"
#include "source_engine/matrix.hpp"
#include "source_engine/memalloc.hpp"
#include "source_engine/base_handle.hpp"
#include "source_engine/color.hpp"
#include "source_engine/utl_vector.hpp"
#include "source_engine/client_class.hpp"
#include "source_engine/datamap.hpp"
#include "source_engine/entity_list.hpp"
#include "source_engine/client_dll.hpp"
#include "source_engine/client_mode.hpp"
#include "source_engine/engine_client.hpp"
#include "source_engine/cvar_system.hpp"
#include "source_engine/global_vars.hpp"
#include "source_engine/input_system.hpp"
#include "source_engine/surface.hpp"
#include "source_engine/glow.hpp"
#include "source_engine/studio.hpp"
#include "source_engine/prediction.hpp"
#include "source_engine/trace.hpp"
#include "source_engine/studio_render.hpp"
#include "source_engine/game_events.hpp"
#include "source_engine/match_framework.hpp"
#include "source_engine/hud.hpp"
#include "source_engine/localize.hpp"
#include "source_engine/beams.hpp"
#include "source_engine/network_string_table.hpp"
#include "source_engine/sound.hpp"