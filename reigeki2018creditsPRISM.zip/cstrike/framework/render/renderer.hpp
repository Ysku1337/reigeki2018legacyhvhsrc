#pragma once

struct point_t {
	int x;
	int y;
};

struct rect_t {
	int x;
	int y;
	int w;
	int h;
};

namespace render {
	struct font_size_t {
		int m_width;
		int m_height;
	};

	enum string_flags_t {
		ALIGN_LEFT = 0,
		ALIGN_RIGHT,
		ALIGN_CENTER
	};

	struct SD3DVertex {
		float x, y, z, rhw;
		DWORD colour;
	};

	class c_font {
	public:
		ID3DXFont* m_handle;
		font_size_t m_size;

	public:
		__forceinline c_font() : m_handle{}, m_size{} {};

		// ctor.
		//__forceinline Font( const std::string& name, int s, int w, int flags ) {
		//	m_handle = g_csgo.m_surface->CreateFont( );
		//	g_csgo.m_surface->SetFontGlyphSet( m_handle, name.data( ), s, w, 0, 0, flags );
		//	m_size = size( XOR( "A" ) );
		//}

		// ctor.
		//__forceinline Font( HFont font ) {
		//	m_handle = font;
		//	m_size = size( XOR( "A" ) );
		//}

		void string(int x, int y, Color color, const std::string& text, string_flags_t flags = ALIGN_LEFT);
		void string(int x, int y, Color color, const std::stringstream& text, string_flags_t flags = ALIGN_LEFT);
		void wstring(int x, int y, Color color, char* text, string_flags_t flags = ALIGN_LEFT, bool outlined = true);
		render::font_size_t size(const std::string& text);
		font_size_t wsize(const std::wstring& text);
	};

	extern c_font esp;
	extern c_font pixel;
	extern c_font console;
	extern c_font hud;
	extern c_font cs;
	extern c_font indicator;

	void init();
	bool WorldToScreen(const vec3_t& world, vec2_t& screen);
	bool WorldToScreen3d(const vec3_t& world, vec3_t& screen);
	void line(vec2_t v0, vec2_t v1, Color color);
	void world_circle(vec3_t origin, float radius, Color color, bool thick = false);
	void filled_world_circle(vec3_t origin, float radius, Color color);
	void line(int x0, int y0, int x1, int y1, Color color);
	void rect(int x, int y, int w, int h, Color color);
	void rect_filled(int x, int y, int w, int h, Color color);
	void rect_filled_fade(int x, int y, int w, int h, Color color, int a1, int a2);
	void setup_render_state();
	void rect_outlined(int x, int y, int w, int h, Color color, Color color2);
	void circle(int x, int y, int radius, int segments, Color color);
	void gradient(int x, int y, int w, int h, Color color1, Color color2);
	void sphere(vec3_t origin, float radius, float angle, float scale, Color color);
	vertex RotateVertex(const vec2_t& p, const vertex& v, float angle);
	void triangle_filled(std::array<vec2_t, 4> points, Color color);
	void arrow(vec2_t pos, Color fill_clr, Color outline_clr);
}